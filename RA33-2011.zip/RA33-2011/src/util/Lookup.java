package util;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import db.DBConnection;

public class Lookup {
	public static String getDrzava(String sifraDrzave) throws SQLException {
		String naziv = "";
		if (sifraDrzave == "")
			return naziv;
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"SELECT DR_NAZIV FROM DRZAVA WHERE DR_SIFRA = ?");
		stmt.setString(1, sifraDrzave);
		ResultSet rset = stmt.executeQuery();
		while (rset.next()) {
			naziv = rset.getString("DR_NAZIV");
		}
		rset.close();
		stmt.close();
		return naziv;
	}

	public static String getMesto(String ptt) throws SQLException {
		String naziv = "";
		if (ptt == "")
			return naziv;
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"SELECT NAZIV FROM MESTO WHERE PTT_BROJ = ?");
		stmt.setString(1, ptt);
		ResultSet rset = stmt.executeQuery();
		while (rset.next()) {
			naziv = rset.getString("NAZIV");
		}
		rset.close();
		stmt.close();
		return naziv;
	}
	
	public static String getValuta(String sifra) throws SQLException {
		String naziv = "";
		if (sifra == "")
			return naziv;
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"SELECT VA_NAZIV FROM VALUTE WHERE VA_SIFRA = ?");
		stmt.setString(1, sifra);
		ResultSet rset = stmt.executeQuery();
		while (rset.next()) {
			naziv = rset.getString("VA_NAZIV");
		}
		rset.close();
		stmt.close();
		return naziv;
		
	}
	
	public static String getKursnaLista(String datum) throws SQLException {
		String broj = "";
		if (datum == "")
			return broj;
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"SELECT KL_BROJ FROM KURSNA_LISTA WHERE KL_DATUM = ?");
		stmt.setString(1, datum);
		ResultSet rset = stmt.executeQuery();
		while (rset.next()) {
			broj = rset.getString("KL_BROJ");
		}
		rset.close();
		stmt.close();
		return broj;
		
	}
}
