package util;

import java.text.NumberFormat;

import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

public class TextfieldDocumentFilter extends DocumentFilter {

	private int maxLength;
	private boolean isInteger;
	private boolean isMoney = false;

	public TextfieldDocumentFilter(int maxLength, boolean isInteger) {
		super();
		this.maxLength = maxLength;
		this.isInteger = isInteger;
	}

	public TextfieldDocumentFilter(int maxLength, boolean isInteger,
			boolean isDouble) {
		super();
		this.maxLength = maxLength;
		this.isInteger = isInteger;
		this.isMoney = isDouble;
	}

	@Override
	public void replace(DocumentFilter.FilterBypass fb, int offset, int length,
			String text, AttributeSet attrs) throws BadLocationException {
		int documentLength = fb.getDocument().getLength();
		if (documentLength - length + text.length() <= maxLength) {
			String str = fb.getDocument().getText(0,
					fb.getDocument().getLength() - length)
					+ text;

			if (!isInteger && !isMoney) {
				super.replace(fb, offset, length, text, attrs);
			} else if (isMoney && !text.toLowerCase().contains("d") && !text.toLowerCase().contains("f")) {
				try {
					Double.parseDouble(str);
					super.replace(fb, offset, length, text, attrs);
				} catch (NumberFormatException e) {
					return;
				}
			} else if (isInteger && isNumeric(text.toString().trim())) {
				super.replace(fb, offset, length, text, attrs);
			}
		}

	}

	public static boolean isNumeric(String text) {
		for (int iCount = 0; iCount < text.length(); iCount++) {
			if (!Character.isDigit(text.charAt(iCount))) {
				return false;
			}
		}
		return true;
	}

	
}
