package util;

import javax.swing.JComboBox;

public class ComboItem
{
    private String value;
    private String text;
    
    
    public ComboItem(){
    	value = "";
    	text = "-";
    }

    public ComboItem(String value, String text)
    {
        this.value = value;
        this.text = text;
    }

    public String getValue()
    {
        return value;
    }

    public String getText()
    {
        return text;
    }
    
    public String toString(){
    	return text;
    }
    
    public static void setSelectedItem(JComboBox<ComboItem> cb, String value){
    	for(int i = 0; i<cb.getItemCount(); i++){
    		if(cb.getItemAt(i).getValue().equals(value)){
    			cb.setSelectedIndex(i);
    			return;
    		}
    		
    	}
    }
}