package gui;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import actions.BankaAction;
import actions.DnevnoStanjeRacunaAction;
import actions.DrzaveAction;
import actions.FizickoLiceAction;
import actions.GasenjeRacunaAction;
import actions.IzvrsiClearingAction;
import actions.KursUValutiAction;
import actions.KursnaListaAction;
import actions.NalogZaTransakcijuAction;
import actions.NaseljenoMestoAction;
import actions.PravnoLiceAction;
import actions.PresekIzvodaAction;
import actions.RacunAction;
import actions.ValuteAction;
import db.DBConnection;

public class Main extends JFrame{
	private static final long serialVersionUID = 1L;
	private static final String CLEARING_QUEUE_FILE = "clearing_queue.dat";
	
	public static Main instance;
	private JMenuBar menuBar;
	
	
	
	
	public Main(){
		
		setSize(new Dimension(1000,800));
		setLocationRelativeTo(null);
		setTitle("Poslovna informatika: BANKA");
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setUpMenu();
		setExtendedState(NORMAL);
		slika();
	
		
		//System.out.println(DBConnection.getConnection().toString());
		//DBConnection.getConnection();
		
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				if (JOptionPane.showConfirmDialog(Main.getInstance(),
						"Da li ste sigurni?", "Pitanje",
						JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
					
					DBConnection.close();
					//saveClearingQueue();
					System.exit(0);
				}
			}
		});
		
		setJMenuBar(menuBar);

	}
	
	private void setUpMenu(){
		menuBar = new JMenuBar();
		JLabel lab = new JLabel(" ");
		
		JMenu orgSemaMenu = new JMenu("Organizaciona �ema");
		orgSemaMenu.setMnemonic(KeyEvent.VK_O);
		
		JMenuItem drzaveMI = new JMenuItem(new DrzaveAction());
		orgSemaMenu.add(drzaveMI);
		drzaveMI.setMnemonic(KeyEvent.VK_D);

		JMenuItem mestoMI = new JMenuItem(new NaseljenoMestoAction());
		orgSemaMenu.add(mestoMI);
		mestoMI.setMnemonic(KeyEvent.VK_N);
		
		orgSemaMenu.addSeparator();
		
		JMenuItem pravnaLicaMI = new JMenuItem(new PravnoLiceAction());
		orgSemaMenu.add(pravnaLicaMI);
		pravnaLicaMI.setMnemonic(KeyEvent.VK_F);
		
		JMenuItem fizickaLicaMI = new JMenuItem(new FizickoLiceAction());
		orgSemaMenu.add(fizickaLicaMI);
		fizickaLicaMI.setMnemonic(KeyEvent.VK_P);
		
		orgSemaMenu.addSeparator();
		
		JMenuItem bankaMI = new JMenuItem(new BankaAction());
		orgSemaMenu.add(bankaMI);
		bankaMI.setMnemonic(KeyEvent.VK_B);

		JMenuItem presekIzvodaMI = new JMenuItem(new PresekIzvodaAction());
		orgSemaMenu.add(presekIzvodaMI);
		presekIzvodaMI.setMnemonic(KeyEvent.VK_I);
		
		JMenuItem nalogZaTransakcijuMI = new JMenuItem(new NalogZaTransakcijuAction());
		orgSemaMenu.add(nalogZaTransakcijuMI);
		nalogZaTransakcijuMI.setMnemonic(KeyEvent.VK_T);
		
		orgSemaMenu.addSeparator();

		JMenuItem miRacun = new JMenuItem(new RacunAction());
		orgSemaMenu.add(miRacun);
		
		JMenuItem miGasenjeRacuna = new JMenuItem(new GasenjeRacunaAction());
		orgSemaMenu.add(miGasenjeRacuna);
		
		JMenuItem miDnevnoStanjeRacuna = new JMenuItem(new DnevnoStanjeRacunaAction());
		orgSemaMenu.add(miDnevnoStanjeRacuna);
		
		orgSemaMenu.addSeparator();
		
		JMenuItem kursnaListaMI = new JMenuItem(new KursnaListaAction());
		orgSemaMenu.add(kursnaListaMI);
		kursnaListaMI.setMnemonic(KeyEvent.VK_L);
		
		JMenuItem kursMI = new JMenuItem(new KursUValutiAction());
		orgSemaMenu.add(kursMI);
		kursMI.setMnemonic(KeyEvent.VK_K);
		
		JMenuItem valutaMI = new JMenuItem(new ValuteAction());
		orgSemaMenu.add(valutaMI);
		valutaMI.setMnemonic(KeyEvent.VK_V);
		
		menuBar.add(lab);
		menuBar.add(orgSemaMenu);
		
		JMenu akcije = new JMenu("Akcije");
		akcije.add(new IzvrsiClearingAction());
		menuBar.add(akcije);
	}

	
	public void slika()
	{
		
		Container con = getContentPane();
	    JPanel panelBgImg;
        //con.setLayout(null);
	    
		ImageIcon imh = new ImageIcon(getClass().getResource("/img/banka.jpg"));
        setSize(imh.getIconWidth(), imh.getIconHeight());
        
        panelBgImg = new JPanel()
        {
            /**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public void paintComponent(Graphics g) 
            {
                Image img = new ImageIcon(getClass().getResource("/img/banka.jpg")).getImage();
                Dimension size = new Dimension(img.getWidth(null), img.getHeight(null));
                setPreferredSize(size);
                setMinimumSize(size);
                setMaximumSize(size);
                setSize(size);
                //setLayout(null);
                g.drawImage(img, 0, 0, null);
            } 
        };
        
        con.add(panelBgImg);
        panelBgImg.setBounds(0, 0, imh.getIconWidth(), imh.getIconHeight());
        
        
	}
	public static Main getInstance(){
		if (instance==null)
			instance=new Main();
		return instance;

	}

}