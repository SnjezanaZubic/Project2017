package gui.dialogs;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import de.wannawork.jcalendar.JCalendarComboBox;

import model.DnevnoStanjeRacunaTableModel;
import net.miginfocom.swing.MigLayout;
import util.Column;
import util.ColumnList;
import actions.CommitAction;
import actions.RollbackAction;

@SuppressWarnings("serial")
public class DnevnoStanjeRacunaStandardForm extends FullGenStanForm {

	private JTextField txtBroj = new JTextField(18);
	private JCalendarComboBox ccbDatum = new JCalendarComboBox();
	private JTextField txtPrethodnoStanje = new JTextField(18);
	private JTextField txtPrometNaTeret = new JTextField(18);
	private JTextField txtPrometUKorist = new JTextField(18);

	public DnevnoStanjeRacunaStandardForm(ColumnList columnList, boolean isZoom) {
		super(new DnevnoStanjeRacunaTableModel(new String[] { "Broj racuna",
				"Datum", "Prethodno stanje", "Promet na teret",
				"Promet u korist" }, 0), null, columnList, isZoom);
		setTitle("Dnevno stanje racuna");
		initDetailsPanel();
	}

	@Override
	public void sync() {
		int index = tblGrid.getSelectedRow();

		if (index < 0) {
			txtBroj.setText("");
			ccbDatum.setDate(new Date());
			txtPrethodnoStanje.setText("");
			txtPrometNaTeret.setText("");
			txtPrometUKorist.setText("");
			return;
		}

		String broj = (String) tableModel.getValueAt(index, 0);
		String datum = (String) tableModel.getValueAt(index, 1);
		String prethodnoStanje = (String) tableModel.getValueAt(index, 2);
		String prometNaTeret = (String) tableModel.getValueAt(index, 3);
		String prometUKorist = (String) tableModel.getValueAt(index, 4);
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		txtBroj.setText(broj.trim());
		try {
			ccbDatum.setDate(dateFormat.parse(datum));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		txtPrethodnoStanje.setText(prethodnoStanje.trim());
		txtPrometNaTeret.setText(prometNaTeret.trim());
		txtPrometUKorist.setText(prometUKorist.trim());
	}

	@Override
	public void eraseFieldsAndRequestFocus() {
		txtBroj.setText("");
		ccbDatum.setDate(new Date());
		txtPrethodnoStanje.setText("");
		txtPrometNaTeret.setText("");
		txtPrometUKorist.setText("");

		txtBroj.requestFocus();
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[3];

		columns[0] = new Column();
		columns[0].setName("broj_racuna");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));

		columns[1] = new Column();
		columns[1].setName("datum");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));

		columns[2] = new Column();
		columns[2].setName("prethodno_stanje");
		columns[2].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 2));

		columns[3] = new Column();
		columns[3].setName("promet_na_teret");
		columns[3].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 3));

		columns[4] = new Column();
		columns[4].setName("promet_u_korist");
		columns[4].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 4));

		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		return new Column[] { new Column("broj_racuna",
				(String) tableModel.getValueAt(tblGrid.getSelectedRow(), 0)) };
	}

	@Override
	protected void initDetailsPanel() {
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout("gapx 15px"));

		JPanel buttonsPanel = new JPanel();
		JTextField[] textFields = new JTextField[] { txtBroj,
				txtPrethodnoStanje, txtPrometNaTeret, txtPrometUKorist };

		btnCommit = new JButton(new CommitAction(this, textFields, tblGrid));
		btnRollback = new JButton(new RollbackAction(this));

		dataPanel.add(new JLabel("Broj racuna:"));
		dataPanel.add(txtBroj, "wrap");
		dataPanel.add(new JLabel("Datum:"));
		dataPanel.add(ccbDatum, "wrap");
		dataPanel.add(new JLabel("Prethodno stanje:"));
		dataPanel.add(txtPrethodnoStanje, "wrap");
		dataPanel.add(new JLabel("Promet na teret:"));
		dataPanel.add(txtPrometNaTeret, "wrap");
		dataPanel.add(new JLabel("Promet u korist:"));
		dataPanel.add(txtPrometUKorist);
		bottomPanel.add(dataPanel);

		buttonsPanel.setLayout(new MigLayout("wrap"));
		buttonsPanel.add(btnCommit);
		buttonsPanel.add(btnRollback);
		bottomPanel.add(buttonsPanel, "dock east");

		add(bottomPanel, "grow, wrap");
	}

	@Override
	public String validateInput() {
		if (txtBroj.getText().length() == 0) {
			txtBroj.requestFocus();
			return "Broj racuna je obavezan!";
		}

		if (txtPrethodnoStanje.getText().length() == 0) {
			txtPrethodnoStanje.requestFocus();
			return "Prethodno stanje je obavezno!";
		}

		if (txtPrometNaTeret.getText().length() == 0) {
			txtPrometNaTeret.requestFocus();
			return "Promet na teret je obavezan!";
		}

		if (txtPrometUKorist.getText().length() == 0) {
			txtPrometUKorist.requestFocus();
			return "Promet u korist je obavezan!";
		}

		return null;
	}

}
