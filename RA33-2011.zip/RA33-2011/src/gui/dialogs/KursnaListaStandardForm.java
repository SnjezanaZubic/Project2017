package gui.dialogs;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.KursnaListaTableModel;
import net.miginfocom.swing.MigLayout;
import util.Column;
import util.ColumnList;
import actions.CommitAction;
import actions.RollbackAction;

@SuppressWarnings("serial")
public class KursnaListaStandardForm extends FullGenStanForm {
	
	private JTextField txtDatum = new JTextField(20);
	private JTextField txtBroj = new JTextField(18);
	private JTextField txtPrimenjujeSeOd = new JTextField(18);
//	private ColumnList columnList = new ColumnList();
	
	public KursnaListaStandardForm(ColumnList columnList, boolean isZoom) {
		super(new KursnaListaTableModel(new String[] {"Datum", "Broj kursne liste", "Primenjuje se od"}, 0), null, columnList, isZoom);
		setTitle("Kursna lista");
		initDetailsPanel();
		addActionHotkeys(false);
	}

	@Override
	public void sync() {
		int index = tblGrid.getSelectedRow();

		if (index < 0) {
			txtDatum.setText("");
			txtBroj.setText("");
			txtPrimenjujeSeOd.setText("");
			return;
		}
		
		String datum = (String)tableModel.getValueAt(index, 0);
		String broj = (String)tableModel.getValueAt(index, 1);
		String primenjujeSeOd = (String)tableModel.getValueAt(index, 2);
		
		txtDatum.setText(datum.trim());
		txtBroj.setText(broj.trim());
		if (txtPrimenjujeSeOd != null) txtPrimenjujeSeOd.setText(primenjujeSeOd.trim());
		
	}

	@Override
	public void eraseFieldsAndRequestFocus() {
		txtDatum.setText("");
		txtBroj.setText("");
		txtPrimenjujeSeOd.setText("");
		
		txtDatum.requestFocus();
		
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[3];
		
		columns[0] = new Column();
		columns[0].setName("KL_DATUM");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));

		columns[1] = new Column();
		columns[1].setName("KL_BROJ");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));
		
		columns[2] = new Column();
		columns[2].setName("KL_DATPR");
		columns[2].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 2));
		
		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		return new Column[] {
				new Column("KL_DATUM", (String)tableModel.getValueAt(tblGrid.getSelectedRow(), 0))
			};
	}

	@Override
	protected void initDetailsPanel() {
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout("gapx 15px"));

		JPanel buttonsPanel = new JPanel();
		JTextField[] textFields = new JTextField[] { txtDatum, txtBroj, txtPrimenjujeSeOd };
		
		btnCommit = new JButton(new CommitAction(this, textFields, tblGrid));
		btnRollback = new JButton(new RollbackAction(this));

		dataPanel.add(new JLabel("Datum:"));
		dataPanel.add(txtDatum, "wrap");
		dataPanel.add(new JLabel("Broj kursne liste:"));
		dataPanel.add(txtBroj, "wrap");
		dataPanel.add(new JLabel("Primenjuje se od:"));
		dataPanel.add(txtPrimenjujeSeOd);
		bottomPanel.add(dataPanel);

		buttonsPanel.setLayout(new MigLayout("wrap"));
		buttonsPanel.add(btnCommit);
		buttonsPanel.add(btnRollback);
		bottomPanel.add(buttonsPanel, "dock east");

		add(bottomPanel, "grow, wrap");
		
	}

	@Override
	public String validateInput() {
		if (txtDatum.getText().length() == 0) {
			txtDatum.requestFocus();
			return "Datum je obavezan!";
		}
		
		if (txtBroj.getText().length() == 0) {
			txtBroj.requestFocus();
			return "Broj kursne liste je obavezan!";	
		}
		
		return null;
	
	}

}
