package gui.dialogs;

import model.GenericTableModel;
import util.Column;
import util.ColumnList;

@SuppressWarnings("serial")
public abstract class FullGenStanForm extends GenericStandardForm{

	protected FullGenStanForm(GenericTableModel tableModel,
			Column[] sifraColumns, ColumnList columnList, boolean isZoom) {
		super(tableModel, sifraColumns, columnList, isZoom);
		
		switchMode(MODE_EDIT);
	}

	@Override
	public void switchMode(int nextMode) {
		if (nextMode == MODE_EDIT) {
			this.mode = nextMode;
			statusBar.setText("Izmena");
		} else if (nextMode == MODE_ADD) {
			this.mode = nextMode;
			statusBar.setText("Dodavanje");
		} else if (nextMode == MODE_SEARCH){
			this.mode = nextMode;
			statusBar.setText("Pretraživanje");
		}
	}

	// metoda sinhronizuje polja za unos sa trenutno selektovanim redom 
	// koristi se da bi u detaljima bio selektovani red
	public abstract void sync();

	// metoda treba da obrise sva polja za unos i prvo polje treba da dobije fokus
	public abstract void eraseFieldsAndRequestFocus();

	// metoda sluzi da sacuva parove { ime kolone, vrednost kolone u selektovanom redu } za sve kolone u redu
	// koristi se kod pickup mehanizma
	public abstract Column[] getCurrentRow();
	
	// metoda sluzi za dobijanje kolona koji su sifra
	// koristi se kod next form mehanizma
	public abstract Column[] getSifraColumns();
	
	protected abstract void initDetailsPanel();

	// metoda sluzi da proveri da li su sva obavezna polja uneta
	// vraca poruku o greski
	public abstract String validateInput();

}
