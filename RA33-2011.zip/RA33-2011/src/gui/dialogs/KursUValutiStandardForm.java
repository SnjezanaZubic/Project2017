package gui.dialogs;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;

import net.miginfocom.swing.MigLayout;
import actions.CommitAction;
import actions.RollbackAction;

import db.DBConnection;

import model.KursUValutiTableModel;
import util.Column;
import util.ColumnList;
import util.Lookup;
import util.TextfieldDocumentFilter;

public class KursUValutiStandardForm extends FullGenStanForm {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JTextField txtRedniBr = new JTextField(5);
	private JTextField txtKupovni = new JTextField(20);
	private JTextField txtSrednji = new JTextField(20);
	private JTextField txtProdajni = new JTextField(20);
	private JTextField txtDatum = new JTextField(10);
	private JTextField txtBrojKL = new JTextField(5);
	private JTextField txtSifra = new JTextField(5);
	private JTextField txtNaziv = new JTextField(20);

	private JButton btnZoom = new JButton("Kursna lista");
	private JButton btnZoom2 = new JButton("Valute");

	private String foreignKey = "";
	private String foreignName = "";
	
	public KursUValutiStandardForm(Column[] sifraColumns, ColumnList columnList, boolean isZoom) {
		super(new KursUValutiTableModel(new String[] {"Redni broj", "Kupovni", "Srednji", "Prodajni", 
				"Datum", "Sifra valute"}, 0), sifraColumns, columnList, isZoom);
		setTitle("Kurs u valuti");

	//	nextFormAction.addPopupItems(new String[] { "FizickoLiceAction",
	//			"PravnoLiceAction" });

		try {
			setForeignKeyName();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		initDetailsPanel();
		addActionHotkeys(false);
	}
	
	private void setForeignKeyName() throws SQLException {
		if (sifraColumns != null) {
			if (sifraColumns[0].getName().toLowerCase().equals("KL_DATUM")) {
				String upit = "SELECT KL_BROJ FROM KURSNA_LISTA WHERE KL_DATUM = ?";
				foreignKey = (String) sifraColumns[0].getValue();
				PreparedStatement stmt = DBConnection.getConnection()
						.prepareStatement(upit);
				stmt.setString(1, foreignKey);
				stmt.setMaxRows(1);
				ResultSet rset = stmt.executeQuery();
				if (rset.next()) {
					foreignName = rset.getString("KL_BROJ");
				}
				rset.close();
				stmt.close();
				System.out.println(foreignKey + " " + foreignName);
			}
			
			if(sifraColumns[0].getName().toLowerCase().equals("va_sifra")) {
				String upit = "SELECT VA_NAZIV FROM VALUTE WHERE va_sifra = ?";
				foreignKey = (String) sifraColumns[0].getValue();
				PreparedStatement stmt = DBConnection.getConnection().prepareStatement(upit);
				stmt.setString(1, foreignKey);
				stmt.setMaxRows(1);
				ResultSet rset = stmt.executeQuery();
				if(rset.next()) {
					foreignName = rset.getString("VA_NAZIV");
				}
				rset.close();
				stmt.close();
				System.out.println(foreignKey + " " + foreignName);
			}
		}
		
	}

	@Override
	public void sync() {
		int index = tblGrid.getSelectedRow();
		if (index < 0) {
			txtRedniBr.setText("");
			txtKupovni.setText("");
			txtSrednji.setText("");
			txtProdajni.setText("");
			return;
		}

		String redniBr = (String) tblGrid.getModel().getValueAt(index, 0);
		String kupovni = (String) tblGrid.getModel().getValueAt(index, 1);
		String srednji = (String) tblGrid.getModel().getValueAt(index, 2);
		String prodajni = (String) tblGrid.getModel().getValueAt(index, 3);
		String datum = (String) tblGrid.getModel().getValueAt(index, 4);
	//	String broj = (String) tblGrid.getModel().getValueAt(index, 5);
		String sifra = (String) tblGrid.getModel().getValueAt(index, 5);
	//	String naziv = (String) tblGrid.getModel().getValueAt(index, 7);
		
		txtRedniBr.setText(redniBr.trim());
		txtKupovni.setText(kupovni.trim());
		txtSrednji.setText(srednji.trim());
		txtProdajni.setText(prodajni.trim());
		txtDatum.setText(datum.trim());
	//	txtBrojKL.setText(broj.trim());
		txtSifra.setText(sifra.trim());
	//	txtNaziv.setText(naziv.trim());
	}
	
	public ColumnList getColumnList() {
		return columnList;
	}

	public void setColumnList(ColumnList columnList) {
		this.columnList = columnList;
	}
	
	@Override
	public void eraseFieldsAndRequestFocus() {
		txtRedniBr.requestFocus();
		txtRedniBr.setText("");
		txtKupovni.setText("");
		txtSrednji.setText("");
		txtProdajni.setText("");
		if (sifraColumns == null) {
			txtBrojKL.setText("");
			txtDatum.setText("");
		}
		if(sifraColumns == null) {
			txtNaziv.setText("");
			txtSifra.setText("");
		}
		
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[2];

		columns[0] = new Column();
		columns[0].setName("KLS_RBR");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));

		columns[1] = new Column();
		columns[1].setName("KLS_KUPOVNI");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));
		
		columns[2] = new Column();
		columns[2].setName("KLS_SREDNJI");
		columns[2].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 2));
		
		columns[3] = new Column();
		columns[3].setName("KLS_PRODAJNI");
		columns[3].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 3));

		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		Column[] sifraColumns = new Column[1];
		int index = tblGrid.getSelectedRow();
		String redniBr = (String) tableModel.getValueAt(index, 0);
		sifraColumns[0] = new Column("KLS_RBR", redniBr);
		return sifraColumns;
	}

	@Override
	protected void initDetailsPanel() {
			((AbstractDocument) txtRedniBr.getDocument())
			.setDocumentFilter(new TextfieldDocumentFilter(5, false));
			((AbstractDocument) txtKupovni.getDocument())
			.setDocumentFilter(new TextfieldDocumentFilter(20, false));
			((AbstractDocument) txtSrednji.getDocument())
			.setDocumentFilter(new TextfieldDocumentFilter(20, false));
			((AbstractDocument)txtProdajni.getDocument())
			.setDocumentFilter(new TextfieldDocumentFilter(20, false));
			((AbstractDocument)txtDatum.getDocument())
			.setDocumentFilter(new TextfieldDocumentFilter(10, false));
			((AbstractDocument)txtSifra.getDocument())
			.setDocumentFilter(new TextfieldDocumentFilter(5, false));
			
	
	JPanel bottomPanel = new JPanel();
	bottomPanel.setLayout(new MigLayout("fillx"));
	JPanel dataPanel = new JPanel();
	dataPanel.setLayout(new MigLayout());
	
	JPanel buttonsPanel = new JPanel();
	JTextField[] textFields = new JTextField[8];
	textFields[0] = txtRedniBr;
	textFields[1] = txtKupovni;
	textFields[2] = txtSrednji;
	textFields[3] = txtProdajni;
	textFields[4] = txtDatum;
	textFields[5] = txtBrojKL;
	textFields[6] = txtSifra;
	textFields[7] = txtNaziv;
	
	btnCommit = new JButton(new CommitAction(this, textFields, tblGrid));
	btnRollback = new JButton(new RollbackAction(this));
	
	JLabel lblRedniBr = new JLabel("Redni broj:");
	JLabel lblKupovni = new JLabel("Kupovni:");
	JLabel lblSrednji = new JLabel("Srednji:");
	JLabel lblProdajni = new JLabel("Prodajni:");
	JLabel lblDatum = new JLabel("Datum:");
	JLabel lblSifra = new JLabel("Šifra valute:");
	
	if (sifraColumns != null) {
		txtDatum.setEditable(false);
		btnZoom.setEnabled(false);
	//	btnZoom2.setEnabled(false);
	}
	
	// ako je child forma -> disable sifra valute za unos
	if (sifraColumns != null) {
		txtSifra.setEditable(false);
	//	btnZoom.setEnabled(false);
		btnZoom2.setEnabled(false);
	}
	
	dataPanel.add(lblRedniBr);
	dataPanel.add(txtRedniBr, "wrap, gapx 15px");
	dataPanel.add(lblKupovni);
	dataPanel.add(txtKupovni, "wrap, gapx 15px, span 3");
	dataPanel.add(lblSrednji);
	dataPanel.add(txtSrednji, "wrap, gapx 15px, span 3");
	dataPanel.add(lblProdajni);
	dataPanel.add(txtProdajni, "wrap, gapx 15px, span 3");
	dataPanel.add(lblDatum);
	dataPanel.add(txtDatum, "wrap, gapx 15px, span 3");
	dataPanel.add(lblSifra);
	dataPanel.add(txtSifra, "wrap, gapx 15px, span 3");
	
	dataPanel.add(btnZoom);
	
	dataPanel.add(txtBrojKL, "pushx");
	txtBrojKL.setEditable(false);
	bottomPanel.add(dataPanel);
	
	dataPanel.add(btnZoom2);
	
	dataPanel.add(txtNaziv, "pushx");
	txtNaziv.setEditable(false);
	bottomPanel.add(dataPanel);
	
	buttonsPanel.setLayout(new MigLayout("wrap"));
	buttonsPanel.add(btnCommit);
	buttonsPanel.add(btnRollback);
	bottomPanel.add(buttonsPanel, "dock east");
	
	add(bottomPanel, "grow, wrap");
	
	btnZoom.addActionListener(new ActionListener() {
	
		public void actionPerformed(ActionEvent arg0) {
			KursnaListaStandardForm form = new KursnaListaStandardForm(columnList,
					true);
			form.setVisible(true);
			if (columnList.getColumnCount() != 0) {
				txtBrojKL.setText(columnList.getValue("KL_BROJ")
						.toString());
				txtDatum.setText(columnList.getValue("KL_DATUM")
						.toString());
			}
		}
	});
	txtDatum.addFocusListener(new FocusAdapter() {
		public void focusLost(FocusEvent e) {
			String datum = txtDatum .getText().trim();
			try {
				txtBrojKL.setText(Lookup.getKursnaLista(datum));
				if (txtBrojKL.getText().equals(""))
					txtBrojKL.setText("Neispravan datum");
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
	});
	
	txtDatum.setText(foreignKey);
	txtBrojKL.setText(foreignName);
	
	btnZoom2.addActionListener(new ActionListener() {
		
		public void actionPerformed(ActionEvent arg0) {
				ValuteStandardForm form = new ValuteStandardForm(sifraColumns, columnList, isZoom);
				form.setVisible(true);
				if (columnList.getColumnCount() != 0) {
					txtNaziv.setText(columnList.getValue("VA_NAZIV")
							.toString());
					txtSifra.setText(columnList.getValue("VA_SIFRA")
							.toString());
				}
			}
		});
		txtSifra.addFocusListener(new FocusAdapter() {
			public void focusLost(FocusEvent e) {
				String sifra = txtDatum .getText().trim();
				try {
					txtNaziv.setText(Lookup.getValuta(sifra));
					if (txtNaziv.getText().equals(""))
						txtNaziv.setText("Neispravna sifra");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		
		txtSifra.setText(foreignKey);
		txtNaziv.setText(foreignName);
			
	}

	@Override
	public String validateInput() {
		if (txtRedniBr.getText().length() == 0) {
			txtRedniBr.requestFocus();
			return "Redni broj je obavezan!";
		}
		if (txtRedniBr.getText().length() < 2) {
			txtRedniBr.requestFocus();
			return "Redni broj je kratak";
		}
		if (txtRedniBr.getText().length() > 2) {
			txtRedniBr.requestFocus();
			return "Redni broj je dugacak";
		}
		if (txtKupovni.getText().length() == 0) {
			txtKupovni.requestFocus();
			return "Kupovni kurs je obavezan!";
		}
		if (txtSrednji.getText().length() == 0) {
			txtSrednji.requestFocus();
			return "Srednji kurs je obavezan!";
		}
		if (txtProdajni.getText().length() == 0) {
			txtProdajni.requestFocus();
			return "Prodajni kurs je obavezan!";
		}
		if (txtDatum.getText().length() == 0) {
			txtDatum.requestFocus();
			return "Datum kursne liste je obavezan!";
		}
		if (txtSifra.getText().length() == 0) {
			txtSifra.requestFocus();
			return "Sifra valute je obavezna!";
		}
		return null;
	}

}
