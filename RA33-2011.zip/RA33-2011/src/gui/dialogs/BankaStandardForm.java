package gui.dialogs;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;

import actions.CommitAction;
import actions.RollbackAction;
import db.DBConnection;
import model.BankaTableModel;
import net.miginfocom.swing.MigLayout;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.swing.JRViewer;
import util.Column;
import util.ColumnList;
import util.TextfieldDocumentFilter;

@SuppressWarnings("serial")

public class BankaStandardForm extends FullGenStanForm {

	private JButton btnReport;
	
	private JTextField txtSifra = new JTextField(5);
	private JTextField txtNaziv = new JTextField(20);
	private JTextField txtAdresa = new JTextField(20);
	private JTextField txtTelefon = new JTextField(15);
	private ColumnList columnList = new ColumnList();
	
	public BankaStandardForm(Column[] sifraColumns, ColumnList columnList, boolean isZoom) {
		super(new BankaTableModel(new String[] {"Sifra", "Naziv", "Adresa", "Telefon"}, 0), sifraColumns, columnList, isZoom);
		setTitle("Banka");
		
		initDetailsPanel();
		
		//nextFormAction.addPopupItems(new String[]{""});
		
		btnReport = new JButton("Report");
		btnReport.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Map params = new HashMap(2);
					int index = tblGrid.getSelectedRow();
					
					if (index < 0) return;
					
					DecimalFormat fmt = new DecimalFormat();
					fmt.setParseBigDecimal(true);
					params.put("SIFRA_BANKE", fmt.parse((String)tableModel.getValueAt(index, 0)));
					params.put("BANKA_NAZIV", (String) tableModel.getValueAt(index, 1));
					System.out.println(getClass().getResource(
							"/reports/SpisakRacunaBanke.jasper"));
					JasperPrint jp = JasperFillManager.fillReport(getClass()
							.getResource("/reports/SpisakRacunaBanke.jasper").openStream(),
							params, DBConnection.getConnection());
					JRViewer jrViewer = new JRViewer(jp);
					JDialog jrDialog = new JDialog();
					jrDialog.add(jrViewer);
					jrDialog.setModal(true);
					jrDialog.setSize(900, 500);
					jrDialog.setLocationRelativeTo(null);
					jrDialog.setVisible(true);
					
					
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		
		toolBar.add(btnReport);
		addActionHotkeys(false);
	}

	@Override
	public void sync() {
		int index = tblGrid.getSelectedRow();

		if (index < 0) {
			txtSifra.setText("");
			txtNaziv.setText("");
			txtAdresa.setText("");
			txtTelefon.setText("");
			return;
		}
		
		String sifra = (String) tableModel.getValueAt(index, 0);
		String naziv = (String) tableModel.getValueAt(index, 1);
		String adresa = (String) tableModel.getValueAt(index, 2);
		String telefon = (String) tableModel.getValueAt(index, 3);
		txtSifra.setText(sifra.trim());
		txtNaziv.setText(naziv.trim());
		txtAdresa.setText(adresa.trim());
		txtTelefon.setText(telefon.trim());
		
	}

	@Override
	public void eraseFieldsAndRequestFocus() {
		txtSifra.requestFocus();
		txtSifra.setText("");
		txtNaziv.setText("");
		txtAdresa.setText("");
		txtTelefon.setText("");
		
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[4];
		
		columns[0] = new Column();
		columns[0].setName("sifra_banke");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));

		columns[1] = new Column();
		columns[1].setName("naziv_banke");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));
		
		columns[2] = new Column();
		columns[2].setName("adresa");
		columns[2].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 2));
		
		columns[3] = new Column();
		columns[3].setName("telefon");
		columns[3].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 3));
		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		Column[] sifraColumns = new Column[1];
		int index = tblGrid.getSelectedRow();
		String sifra = (String) tableModel.getValueAt(index, 0);
		sifraColumns[0] = new Column("sifra_banke", sifra);
		return sifraColumns;
	}

	@Override
	protected void initDetailsPanel() {
		((AbstractDocument)txtSifra.getDocument()).setDocumentFilter(new TextfieldDocumentFilter(10, false));
		((AbstractDocument)txtNaziv.getDocument()).setDocumentFilter(new TextfieldDocumentFilter(20, false));
		((AbstractDocument)txtAdresa.getDocument()).setDocumentFilter(new TextfieldDocumentFilter(20, false));
		((AbstractDocument)txtTelefon.getDocument()).setDocumentFilter(new TextfieldDocumentFilter(20, false));
		
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout("gapx 15px"));

		JPanel buttonsPanel = new JPanel();
		JTextField[] textFields = new JTextField[4];
		textFields[0] = txtSifra;
		textFields[1] = txtNaziv;
		textFields[2] = txtAdresa;
		textFields[3] = txtTelefon;
		btnCommit = new JButton(new CommitAction(this, textFields,
				tblGrid));
		btnRollback = new JButton(new RollbackAction(this));

		JLabel lblSifra = new JLabel("Šifra banke:");
		JLabel lblNaziv = new JLabel("Naziv banke:");
		JLabel lblAdresa = new JLabel("Adresa banke: ");
		JLabel lblTelefon = new JLabel("Broj telefona banke:");

		dataPanel.add(lblSifra);
		dataPanel.add(txtSifra, "wrap, gapx 15px");
		dataPanel.add(lblNaziv);
		dataPanel.add(txtNaziv, "wrap, gapx 15px");
		dataPanel.add(lblAdresa);
		dataPanel.add(txtAdresa, "wrap, gapx 15px");
		dataPanel.add(lblTelefon);
		dataPanel.add(txtTelefon, "wrap, gapx 15px");
		bottomPanel.add(dataPanel);

		buttonsPanel.setLayout(new MigLayout("wrap"));
		buttonsPanel.add(btnCommit);
		buttonsPanel.add(btnRollback);
		bottomPanel.add(buttonsPanel, "dock east");

		add(bottomPanel, "grow, wrap");
		
	}

	public ColumnList getColumnList() {
		return columnList;
	}

	public void setColumnList(ColumnList columnList) {
		this.columnList = columnList;
	}
	
	@Override
	public String validateInput() {
		if (txtSifra.getText().length() == 0) {
			txtSifra.requestFocus();
			return "Šifra banke je obavezna!";
		}
		if (txtSifra.getText().length() < 3) {
			txtSifra.requestFocus();
			return "Šifra banke je previse kratka";
		} else if( txtSifra.getText().length() > 3) {
			txtSifra.requestFocus();
			return "Šifra banke je previse duga";
		}
		if (txtNaziv.getText().length() == 0) {
			txtNaziv.requestFocus();
			return "Naziv banke je obavezan!";	
		}
		return null;
	}

}
