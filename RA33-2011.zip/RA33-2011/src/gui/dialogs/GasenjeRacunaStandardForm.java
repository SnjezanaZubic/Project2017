package gui.dialogs;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.GasenjeRacunaTableModel;
import net.miginfocom.swing.MigLayout;
import util.Column;
import util.ColumnList;
import actions.CommitAction;
import actions.RollbackAction;

@SuppressWarnings("serial")
public class GasenjeRacunaStandardForm extends FullGenStanForm {
	
	private JTextField txtDatum = new JTextField(20);
	private JTextField txtBroj = new JTextField(18);
	private JTextField txtPrebacenoNa = new JTextField(18);
	private ColumnList columnList = new ColumnList();
	
	public GasenjeRacunaStandardForm(ColumnList columnList, boolean isZoom) {
		super(new GasenjeRacunaTableModel(new String[] { "Datum gasenja", "Broj racuna", "Prebaceno na racun" }, 0), null, columnList, isZoom);
		setTitle("Gasenje racuna");
		initDetailsPanel();
	}
	
	@Override
	public void sync() {
		int index = tblGrid.getSelectedRow();

		if (index < 0) {
			txtDatum.setText("");
			txtBroj.setText("");
			txtPrebacenoNa.setText("");
			return;
		}
		
		String datum = (String)tableModel.getValueAt(index, 0);
		String broj = (String)tableModel.getValueAt(index, 1);
		String prebacenoNa = (String)tableModel.getValueAt(index, 2);
		
		txtDatum.setText(datum.trim());
		txtBroj.setText(broj.trim());
		if (txtPrebacenoNa != null) txtPrebacenoNa.setText(prebacenoNa.trim());
	}

	@Override
	public void eraseFieldsAndRequestFocus() {
		txtDatum.setText("");
		txtBroj.setText("");
		txtPrebacenoNa.setText("");
		
		txtDatum.requestFocus();
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[3];
		
		columns[0] = new Column();
		columns[0].setName("datum_gasenja");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));

		columns[1] = new Column();
		columns[1].setName("broj_racuna");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));
		
		columns[2] = new Column();
		columns[2].setName("prebaceno_na_racun");
		columns[2].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 2));
		
		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		return new Column[] {
			new Column("datum_gasenja", (String)tableModel.getValueAt(tblGrid.getSelectedRow(), 0))
		};
	}

	@Override
	protected void initDetailsPanel() {
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout("gapx 15px"));

		JPanel buttonsPanel = new JPanel();
		JTextField[] textFields = new JTextField[] { txtDatum, txtBroj, txtPrebacenoNa };
		
		btnCommit = new JButton(new CommitAction(this, textFields, tblGrid));
		btnRollback = new JButton(new RollbackAction(this));

		dataPanel.add(new JLabel("Datum gasenja:"));
		dataPanel.add(txtDatum, "wrap");
		dataPanel.add(new JLabel("Broj racuna:"));
		dataPanel.add(txtBroj, "wrap");
		dataPanel.add(new JLabel("Prebaceno na racun:"));
		dataPanel.add(txtPrebacenoNa);
		bottomPanel.add(dataPanel);

		buttonsPanel.setLayout(new MigLayout("wrap"));
		buttonsPanel.add(btnCommit);
		buttonsPanel.add(btnRollback);
		bottomPanel.add(buttonsPanel, "dock east");

		add(bottomPanel, "grow, wrap");
	}

	@Override
	public String validateInput() {
		if (txtDatum.getText().length() == 0) {
			txtDatum.requestFocus();
			return "Datum je obavezan!";
		}
		
		if (txtBroj.getText().length() == 0) {
			txtBroj.requestFocus();
			return "Broj racuna je obavezan!";	
		}
		
		return null;
	}

}
