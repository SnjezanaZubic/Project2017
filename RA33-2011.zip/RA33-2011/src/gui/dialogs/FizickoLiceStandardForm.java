package gui.dialogs;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;

import model.FizickoLiceTableModel;
import net.miginfocom.swing.MigLayout;
import util.Column;
import util.ColumnList;
import util.Lookup;
import util.TextfieldDocumentFilter;
import actions.CommitAction;
import actions.RollbackAction;
import db.DBConnection;

@SuppressWarnings("serial")
public class FizickoLiceStandardForm extends FullGenStanForm {

	private JTextField txtSifra = new JTextField(5);
	private JTextField txtJMBG = new JTextField(13);
	private JTextField txtIme = new JTextField(20);
	private JTextField txtPrezime = new JTextField(20);
	private JTextField txtPTT = new JTextField(5);
	private JTextField txtGrad = new JTextField(20);
	private JTextField txtAdresa = new JTextField(20);
	private JTextField txtTelefon = new JTextField(20);
	private JTextField txtDelatnost = new JTextField(20);

	private JButton btnZoom = new JButton("...");
	private ColumnList columnList = new ColumnList();

	private String foreignKey = "";
	private String foreignName = "";

	public FizickoLiceStandardForm(Column[] sifraColumns,
			ColumnList columnList, boolean isZoom) {
		super(
				new FizickoLiceTableModel(new String[] { "Šifra", "JMBG",
						"Ime", "Prezime", "PTT", "Grad", "Adresa", "Telefon",
						"Delatnost" }, 0), sifraColumns, columnList, isZoom);
		setTitle("Fizička lica");

		try {
			setForeignKeyName();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		initDetailsPanel();
		addActionHotkeys(false);
	}

	protected void initDetailsPanel() {

		((AbstractDocument) txtSifra.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(5, true));
		((AbstractDocument) txtJMBG.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(13, true));
		((AbstractDocument) txtIme.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(20, false));
		((AbstractDocument) txtPrezime.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(20, false));
		((AbstractDocument) txtPTT.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(5, true));
		((AbstractDocument) txtAdresa.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(256, false));
		((AbstractDocument) txtTelefon.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(20, false)); // TODO:
																			// numeric
																			// ili
																			// ne?
		((AbstractDocument) txtDelatnost.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(30, false));

		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout());

		JPanel buttonsPanel = new JPanel();
		JTextField[] textFields = new JTextField[9];
		textFields[0] = txtSifra;
		textFields[1] = txtJMBG;
		textFields[2] = txtIme;
		textFields[3] = txtPrezime;
		textFields[4] = txtPTT;
		textFields[5] = txtGrad;
		textFields[6] = txtAdresa;
		textFields[7] = txtTelefon;
		textFields[8] = txtDelatnost;
		btnCommit = new JButton(new CommitAction(this, textFields, tblGrid));
		btnRollback = new JButton(new RollbackAction(this));

		JLabel lblSifra = new JLabel("Šifra:");
		JLabel lblJMBG = new JLabel("JMBG:");
		JLabel lblIme = new JLabel("Ime:");
		JLabel lblPrezime = new JLabel("Prezime:");
		JLabel lblPTT = new JLabel("Grad:");
		JLabel lblAdresa = new JLabel("Adresa:");
		JLabel lblTelefon = new JLabel("Telefon:");
		JLabel lblDelatnost = new JLabel("Delatnost:");

		// ako je child forma -> disable sifra drzave za unos
		if (sifraColumns != null) {
			txtPTT.setEditable(false);
			btnZoom.setEnabled(false);
		}

		dataPanel.add(lblSifra);
		dataPanel.add(txtSifra, "wrap, gapx 15px");
		dataPanel.add(lblJMBG);
		dataPanel.add(txtJMBG, "wrap,gapx 15px, span 3");
		dataPanel.add(lblIme);
		dataPanel.add(txtIme, "wrap, gapx 15px");
		dataPanel.add(lblPrezime);
		dataPanel.add(txtPrezime, "wrap, gapx 15px");

		dataPanel.add(lblPTT);
		dataPanel.add(txtPTT, "gapx 15px, shrink 0, split 3");
		dataPanel.add(btnZoom);
		dataPanel.add(txtGrad, "wrap, pushx");
		txtGrad.setEditable(false);

		dataPanel.add(lblAdresa);
		dataPanel.add(txtAdresa, "wrap, gapx 15px");
		dataPanel.add(lblTelefon);
		dataPanel.add(txtTelefon, "wrap, gapx 15px");
		dataPanel.add(lblDelatnost);
		dataPanel.add(txtDelatnost, "wrap, gapx 15px");

		bottomPanel.add(dataPanel);

		buttonsPanel.setLayout(new MigLayout("wrap"));
		buttonsPanel.add(btnCommit);
		buttonsPanel.add(btnRollback);
		bottomPanel.add(buttonsPanel, "dock east");

		add(bottomPanel, "grow, wrap");

		btnZoom.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				NaseljenoMestoStandardForm form = new NaseljenoMestoStandardForm(
						null, columnList, true);
				form.setVisible(true);
				if (columnList.getColumnCount() != 0) {
					txtGrad.setText(columnList.getValue("naziv").toString());
					txtPTT.setText(columnList.getValue("ptt_broj").toString());
				}
			}
		});
		txtPTT.addFocusListener(new FocusAdapter() {
			public void focusLost(FocusEvent e) {
				String ptt = txtPTT.getText().trim();
				try {
					txtGrad.setText(Lookup.getMesto(ptt));
					if (txtGrad.getText().equals(""))
						txtGrad.setText("Neispravna šifra");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});

		txtPTT.setText(foreignKey);
		txtGrad.setText(foreignName);
	}

	@Override
	public void sync() {
		int index = tblGrid.getSelectedRow();
		if (index < 0) {
			txtSifra.setText("");
			txtJMBG.setText("");
			txtIme.setText("");
			txtPrezime.setText("");
			// txtPTT.setText("");
			// txtGrad.setText("");
			txtAdresa.setText("");
			txtTelefon.setText("");
			txtDelatnost.setText("");
			return;
		}
		String sifra = (String) tblGrid.getModel().getValueAt(index, 0);
		String jmbg = (String) tblGrid.getModel().getValueAt(index, 1);
		String ime = (String) tblGrid.getModel().getValueAt(index, 2);
		String prezime = (String) tblGrid.getModel().getValueAt(index, 3);
		String ptt = (String) tblGrid.getModel().getValueAt(index, 4);
		String grad = (String) tblGrid.getModel().getValueAt(index, 5);
		String adresa = (String) tblGrid.getModel().getValueAt(index, 6);
		String telefon = (String) tblGrid.getModel().getValueAt(index, 7);
		String delatnost = (String) tblGrid.getModel().getValueAt(index, 8);

		txtSifra.setText(sifra.trim());
		txtJMBG.setText(jmbg.trim());
		txtIme.setText(ime.trim());
		txtPrezime.setText(prezime.trim());
		txtPTT.setText(ptt.trim());
		txtGrad.setText(grad.trim());
		txtAdresa.setText(adresa.trim());
		txtTelefon.setText(telefon.trim());
		txtDelatnost.setText(delatnost.trim());
	}

	@Override
	public void eraseFieldsAndRequestFocus() {
		txtSifra.requestFocus();
		txtSifra.setText("");
		txtJMBG.setText("");
		txtIme.setText("");
		txtPrezime.setText("");
		if (sifraColumns == null) {
			txtPTT.setText("");
			txtGrad.setText("");
		}
		txtAdresa.setText("");
		txtTelefon.setText("");
		txtDelatnost.setText("");
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[9];

		columns[0] = new Column();
		columns[0].setName("sifra_klijenta");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));

		columns[1] = new Column();
		columns[1].setName("jmbg");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));

		columns[2] = new Column();
		columns[2].setName("ime");
		columns[2].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 2));

		columns[3] = new Column();
		columns[3].setName("prezime");
		columns[3].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 3));

		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		Column[] sifraColumns = new Column[1];
		int index = tblGrid.getSelectedRow();
		String sifra = (String) tableModel.getValueAt(index, 0);

		sifraColumns[0] = new Column("sifra_klijenta", sifra);
		return sifraColumns;
	}

	public ColumnList getColumnList() {
		return columnList;
	}

	public void setColumnList(ColumnList columnList) {
		this.columnList = columnList;
	}

	@Override
	public String validateInput() {
		if (txtSifra.getText().length() == 0) {
			txtSifra.requestFocus();
			return "Šifra klijenta je obavezna!";
		}
		if (txtJMBG.getText().length() == 0) {
			txtJMBG.requestFocus();
			return "JMBG klijenta je obavezan!";
		} else if (txtJMBG.getText().length() < 13) {
			txtJMBG.selectAll();
			txtJMBG.requestFocus();
			return "JMBG klijenta mora imati tačno 13 cifara!";
		}
		if (txtIme.getText().length() == 0) {
			txtIme.requestFocus();
			return "Ime klijenta je obavezno!";
		}
		if (txtPrezime.getText().length() == 0) {
			txtPrezime.requestFocus();
			return "Prezime klijenta je obavezno!";
		}
		if (txtPTT.getText().length() == 0) {
			txtPTT.requestFocus();
			return "Poštanski broj grada je obavezan!";
		}
		if (txtGrad.getText().length() == 0) {
			txtGrad.requestFocus();
			return "Naziv grada je obavezan!";
		}
		if (txtSifra.getText().length() == 0) {
			txtSifra.requestFocus();
			return "Šifra države je obavezna!";
		}
		if (txtAdresa.getText().length() == 0) {
			txtAdresa.requestFocus();
			return "Adresa klijenta je obavezna!";
		}
		if (txtTelefon.getText().length() == 0) {
			txtTelefon.requestFocus();
			return "Telefonski broj klijenta je obavezan!";
		}
		if (txtDelatnost.getText().length() == 0) {
			txtDelatnost.requestFocus();
			return "Delatnost klijenta je obavezna!";
		}
		return null;
	}

	// ako je otvoreno sa next mehanizmom onda taj strani kljuc
	// mora UVEK da ima istu vrednost (kada se dodaje, pretrazuje itd)
	private void setForeignKeyName() throws SQLException {
		if (sifraColumns != null) {
			if (sifraColumns[0].getName().toLowerCase().equals("ptt_broj")) {
				String upit = "SELECT naziv FROM mesto WHERE ptt_broj = ?";
				foreignKey = (String) sifraColumns[0].getValue();
				PreparedStatement stmt = DBConnection.getConnection()
						.prepareStatement(upit);
				stmt.setString(1, foreignKey);
				stmt.setMaxRows(1);
				ResultSet rset = stmt.executeQuery();
				if (rset.next()) {
					foreignName = rset.getString("NAZIV");
				}
				rset.close();
				stmt.close();
				System.out.println(foreignKey + " " + foreignName);
			}
		}
	}

}
