package gui.dialogs;

import gui.MainFrame;
import gui.dialogs.elements.DialogStatusBar;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import model.GenericTableModel;
import net.miginfocom.swing.MigLayout;
import util.Column;
import util.ColumnList;
import actions.AddAction;
import actions.DeleteAction;
import actions.FirstAction;
import actions.GenerisanjeIzvodaAction;
import actions.HelpAction;
import actions.LastAction;
import actions.NextAction;
import actions.NextFormAction;
import actions.PickupAction;
import actions.PreviousAction;
import actions.RefreshAction;
import actions.SearchAction;

@SuppressWarnings("serial")
public abstract class GenericStandardForm extends JDialog {

	public static final int MODE_EDIT = 1;
	public static final int MODE_ADD = 2;
	public static final int MODE_SEARCH = 3;

	protected int mode;

	protected JToolBar toolBar;
	protected JButton btnAdd, btnCommit, btnDelete, btnFirst, btnLast, btnHelp,
			btnNext, btnNextForm, btnPickup, btnRefresh, btnRollback,
			btnSearch, btnPrevious;

	protected NextFormAction nextFormAction = new NextFormAction(this);

	protected DialogStatusBar statusBar = new DialogStatusBar();
	protected JTable tblGrid = new JTable();
	protected GenericTableModel tableModel;

	protected ColumnList columnList = new ColumnList();
	protected Column[] sifraColumns;
	protected boolean isZoom;

	protected Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	protected int width = (int)screenSize.getWidth();
	protected int height = (int)screenSize.getHeight();
	
	protected GenericStandardForm(GenericTableModel tableModel,
			Column[] sifraColumns, ColumnList columnList, boolean isZoom) {
		this.tableModel = tableModel;
		this.sifraColumns = sifraColumns;
		this.isZoom = isZoom;
		if (columnList != null)
			this.columnList = columnList;
		setLayout(new MigLayout("fill"));
		
		
		setSize(new Dimension(width*4/5, height*4/5));
		setLocationRelativeTo(MainFrame.getInstance());
		setModal(true);

		initToolbar();
		initTable();

		add(statusBar, "dock south");

	}

	private void initTable() {
		JScrollPane scrollPane = new JScrollPane(tblGrid);
		add(scrollPane, "grow, wrap");

		// Kreiranje TableModel-a, parametri: header-i kolona i broj redova
		tblGrid.setModel(tableModel);

		try {
			tableModel.open(sifraColumns);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		tblGrid.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tblGrid.getSelectionModel().addListSelectionListener(
				new ListSelectionListener() {
					public void valueChanged(ListSelectionEvent e) {
						if (e.getValueIsAdjusting())
							return;
						sync();
					}
				});

		// Dozvoljeno selektovanje redova
		tblGrid.setRowSelectionAllowed(true);
		// Ali ne i selektovanje kolona
		tblGrid.setColumnSelectionAllowed(false);

		// Dozvoljeno selektovanje samo jednog reda u jedinici vremena
		tblGrid.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	}

	private void initToolbar() {

		toolBar = new JToolBar();
		btnSearch = new JButton(new SearchAction(this));
		toolBar.add(btnSearch);

		btnRefresh = new JButton(new RefreshAction(this, tblGrid));
		toolBar.add(btnRefresh);

		btnPickup = new JButton(new PickupAction(this, tblGrid, columnList));
		toolBar.add(btnPickup);
		btnPickup.setEnabled(isZoom);

		btnHelp = new JButton(new HelpAction());
		toolBar.add(btnHelp);

		toolBar.addSeparator();

		btnFirst = new JButton(new FirstAction(this, tblGrid));
		toolBar.add(btnFirst);

		btnPrevious = new JButton(new PreviousAction(this, tblGrid));
		toolBar.add(btnPrevious);

		btnNext = new JButton(new NextAction(this, tblGrid));
		toolBar.add(btnNext);

		btnLast = new JButton(new LastAction(this, tblGrid));
		toolBar.add(btnLast);

		toolBar.addSeparator();

		btnAdd = new JButton(new AddAction(this));
		toolBar.add(btnAdd);

		btnDelete = new JButton(new DeleteAction(this, tblGrid));
		toolBar.add(btnDelete);

		toolBar.addSeparator();

		btnNextForm = new JButton(nextFormAction);
		toolBar.add(btnNextForm);

		add(toolBar, "dock north");
	}

	protected void addActionHotkeys(boolean onlySearch) {
		int c = JComponent.WHEN_IN_FOCUSED_WINDOW;

		// enter -> commit
		rootPane.setDefaultButton(btnCommit);

		// escape -> rollback
		KeyStroke ks = KeyStroke.getKeyStroke("ESCAPE");
		rootPane.getInputMap(c).put(ks, "ROLLBACK");
		rootPane.getActionMap().put("ROLLBACK", btnRollback.getAction());

		// ctrl+F -> search
		ks = KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_DOWN_MASK);
		rootPane.getInputMap(c).put(ks, "SEARCH");
		rootPane.getActionMap().put("SEARCH", btnSearch.getAction());

		// F5 -> refresh
		ks = KeyStroke.getKeyStroke("F5");
		rootPane.getInputMap(c).put(ks, "REFRESH");
		rootPane.getActionMap().put("REFRESH", btnRefresh.getAction());

		if (!onlySearch) {
			// delete -> delete
			ks = KeyStroke.getKeyStroke(KeyEvent.VK_E,
					InputEvent.CTRL_DOWN_MASK);
			rootPane.getInputMap(c).put(ks, "DELETE");
			rootPane.getActionMap().put("DELETE", btnDelete.getAction());

			// ctrl+D -> dodaj
			ks = KeyStroke.getKeyStroke(KeyEvent.VK_D,
					InputEvent.CTRL_DOWN_MASK);
			rootPane.getInputMap(c).put(ks, "ADD");
			rootPane.getActionMap().put("ADD", btnAdd.getAction());
		}
	}

	public int getMode() {
		return mode;
	}

	public JTable getTable() {
		return tblGrid;
	}

	public JButton getNextFormButton() {
		return btnNextForm;
	}
	public JToolBar getToolbar(){
		return toolBar;
	}

	public abstract void switchMode(int nextMode);

	// metoda sinhronizuje polja za unos sa trenutno selektovanim redom
	// koristi se da bi u detaljima bio selektovani red
	public abstract void sync();

	// metoda treba da obrise sva polja za unos i prvo polje treba da dobije
	// fokus
	public abstract void eraseFieldsAndRequestFocus();

	// metoda sluzi da sacuva parove { ime kolone, vrednost kolone u
	// selektovanom redu } za sve kolone u redu
	// koristi se kod pickup mehanizma
	public abstract Column[] getCurrentRow();

	// metoda sluzi za dobijanje kolona koji su sifra
	// koristi se kod next form mehanizma
	public abstract Column[] getSifraColumns();

	protected abstract void initDetailsPanel();

	// metoda sluzi da proveri da li su sva obavezna polja uneta
	// vraca poruku o greski
	public abstract String validateInput();

}
