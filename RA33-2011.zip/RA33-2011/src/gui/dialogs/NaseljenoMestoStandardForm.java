package gui.dialogs;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;

import model.NaseljenoMestoTableModel;
import net.miginfocom.swing.MigLayout;
import util.Column;
import util.ColumnList;
import util.Lookup;
import util.TextfieldDocumentFilter;
import actions.CommitAction;
import actions.RollbackAction;
import db.DBConnection;

@SuppressWarnings("serial")
public class NaseljenoMestoStandardForm extends FullGenStanForm {

	private JTextField txtSifra = new JTextField(5);
	private JTextField txtNaziv = new JTextField(20);
	private JTextField txtNazivDrzave = new JTextField(20);
	private JTextField txtSifraDrzave = new JTextField(5);

	private JButton btnZoom = new JButton("...");

	private String foreignKey = "";
	private String foreignName = "";

	public NaseljenoMestoStandardForm(Column[] sifraColumns,
			ColumnList columnList, boolean isZoom) {
		super(new NaseljenoMestoTableModel(new String[] { "PTT", "Naziv",
				"Šifra države", "Naziv države" }, 0), sifraColumns, columnList,
				isZoom);

		setTitle("Naseljena mesta");

		nextFormAction.addPopupItems(new String[] { "FizickoLiceAction",
				"PravnoLiceAction" });

		try {
			setForeignKeyName();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		initDetailsPanel();
		addActionHotkeys(false);
	}

	protected void initDetailsPanel() {

		((AbstractDocument) txtSifra.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(5, true));
		((AbstractDocument) txtNaziv.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(30, false));
		((AbstractDocument) txtSifraDrzave.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(2, false));

		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout());

		JPanel buttonsPanel = new JPanel();
		JTextField[] textFields = new JTextField[4];
		textFields[0] = txtSifra;
		textFields[1] = txtNaziv;
		textFields[2] = txtSifraDrzave;
		textFields[3] = txtNazivDrzave;
		btnCommit = new JButton(new CommitAction(this, textFields, tblGrid));
		btnRollback = new JButton(new RollbackAction(this));

		JLabel lblSifra = new JLabel("PTT mesta:");
		JLabel lblNaziv = new JLabel("Naziv mesta:");
		JLabel lblSifraDrzave = new JLabel("Šifra države:");

		// ako je child forma -> disable sifra drzave za unos
		if (sifraColumns != null) {
			txtSifraDrzave.setEditable(false);
			btnZoom.setEnabled(false);
		}

		dataPanel.add(lblSifra);
		dataPanel.add(txtSifra, "wrap, gapx 15px");
		dataPanel.add(lblNaziv);
		dataPanel.add(txtNaziv, "wrap,gapx 15px, span 3");
		dataPanel.add(lblSifraDrzave);
		dataPanel.add(txtSifraDrzave, "gapx 15px");
		dataPanel.add(btnZoom);

		dataPanel.add(txtNazivDrzave, "pushx");
		txtNazivDrzave.setEditable(false);
		bottomPanel.add(dataPanel);

		buttonsPanel.setLayout(new MigLayout("wrap"));
		buttonsPanel.add(btnCommit);
		buttonsPanel.add(btnRollback);
		bottomPanel.add(buttonsPanel, "dock east");

		add(bottomPanel, "grow, wrap");

		btnZoom.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				DrzavaStandardForm form = new DrzavaStandardForm(columnList,
						true);
				form.setVisible(true);
				if (columnList.getColumnCount() != 0) {
					txtNazivDrzave.setText(columnList.getValue("dr_naziv")
							.toString());
					txtSifraDrzave.setText(columnList.getValue("dr_sifra")
							.toString());
				}
			}
		});
		txtSifraDrzave.addFocusListener(new FocusAdapter() {
			public void focusLost(FocusEvent e) {
				String sifraDrzave = txtSifraDrzave.getText().trim();
				try {
					txtNazivDrzave.setText(Lookup.getDrzava(sifraDrzave));
					if (txtNazivDrzave.getText().equals(""))
						txtNazivDrzave.setText("Neispravna šifra");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});

		txtSifraDrzave.setText(foreignKey);
		txtNazivDrzave.setText(foreignName);
	}

	public void sync() {
		int index = tblGrid.getSelectedRow();
		if (index < 0) {
			txtSifra.setText("");
			txtNaziv.setText("");
			return;
		}

		String sifra = (String) tblGrid.getModel().getValueAt(index, 0);
		String naziv = (String) tblGrid.getModel().getValueAt(index, 1);
		String sifraDrzave = (String) tblGrid.getModel().getValueAt(index, 2);
		String nazivDrzave = (String) tblGrid.getModel().getValueAt(index, 3);
		txtSifra.setText(sifra.trim());
		txtNaziv.setText(naziv.trim());
		txtSifraDrzave.setText(sifraDrzave.trim());
		txtNazivDrzave.setText(nazivDrzave.trim());

	}

	public ColumnList getColumnList() {
		return columnList;
	}

	public void setColumnList(ColumnList columnList) {
		this.columnList = columnList;
	}

	@Override
	public void eraseFieldsAndRequestFocus() {
		txtSifra.requestFocus();
		txtSifra.setText("");
		txtNaziv.setText("");
		if (sifraColumns == null) {
			txtNazivDrzave.setText("");
			txtSifraDrzave.setText("");
		}
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[2];

		columns[0] = new Column();
		columns[0].setName("ptt_broj");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));

		columns[1] = new Column();
		columns[1].setName("naziv");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));

		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		Column[] sifraColumns = new Column[1];
		int index = tblGrid.getSelectedRow();
		String sifra = (String) tableModel.getValueAt(index, 0);
		sifraColumns[0] = new Column("ptt_broj", sifra);
		return sifraColumns;
	}

	@Override
	public String validateInput() {
		if (txtSifra.getText().length() == 0) {
			txtSifra.requestFocus();
			return "Poštanski broj grada je obavezan!";
		}
		if (txtNaziv.getText().length() == 0) {
			txtNaziv.requestFocus();
			return "Naziv grada je obavezan!";
		}
		if (txtSifraDrzave.getText().length() == 0) {
			txtSifraDrzave.requestFocus();
			return "Šifra države je obavezna!";
		}
		if (txtNazivDrzave.getText().length() == 0) {
			txtNazivDrzave.requestFocus();
			return "Naziv države je obavezan!";
		}
		return null;
	}

	// ako je otvoreno sa next mehanizmom onda taj strani kljuc
	// mora UVEK da ima istu vrednost (kada se dodaje, pretrazuje itd)
	private void setForeignKeyName() throws SQLException {
		if (sifraColumns != null) {
			if (sifraColumns[0].getName().toLowerCase().equals("dr_sifra")) {
				String upit = "SELECT dr_naziv FROM drzava WHERE dr_sifra = ?";
				foreignKey = (String) sifraColumns[0].getValue();
				PreparedStatement stmt = DBConnection.getConnection()
						.prepareStatement(upit);
				stmt.setString(1, foreignKey);
				stmt.setMaxRows(1);
				ResultSet rset = stmt.executeQuery();
				if (rset.next()) {
					foreignName = rset.getString("DR_NAZIV");
				}
				rset.close();
				stmt.close();
				System.out.println(foreignKey + " " + foreignName);
			}
		}
	}

}
