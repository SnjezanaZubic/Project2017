package gui.dialogs;

import gui.MainFrame;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import util.TextfieldDocumentFilter;
import model.PresekIzvodaTableModel;
import net.miginfocom.swing.MigLayout;
import db.DBConnection;
import de.wannawork.jcalendar.JCalendarComboBox;

@SuppressWarnings("serial")
public class GenerisiIzvodStandardForm extends JDialog {
	
	private JTextField txtBrojRacuna = new JTextField(15);
	private JCalendarComboBox dpDatumNaloga = new JCalendarComboBox();

	private JButton btnGenerisi = new JButton("Generisi izvod");
	private Object[] data;
	private boolean indikatorGreske = false;
	
	protected Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	protected int width = (int)screenSize.getWidth(); 
	protected int height = (int)screenSize.getHeight();
	
	private String basicQuery = "SELECT broj_racuna, "
			+ "datum, "
			+ "prethodno_stanje, "
			+ "promet_na_teret, "
			+ "promet_u_korist, "
			+ "novo_stanje "
			+ "FROM dnevno_stanje_racuna";
	private String orderBy = " ORDER BY broj_racuna";
	
	
	public GenerisiIzvodStandardForm() {
		super();
		setTitle("Za generisanje izvoda");
		
		setLayout(new MigLayout("fill"));
		setSize(new Dimension(width/4, height/4));
		setLocationRelativeTo(MainFrame.getInstance());
		setModal(true);
		
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout());
		
	
		initDetailsPanel();
	}
	
	protected void initDetailsPanel() {
	
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout());

		final Object[] fields = new Object[2];
		
		fields[0] = txtBrojRacuna;
		fields[1] = dpDatumNaloga;
		
		btnGenerisi.addActionListener(new ActionListener() { 
		    public void actionPerformed(ActionEvent e) { 
		        if (validateBrojRacuna(fields[0])) {
		        	JOptionPane.showMessageDialog(null, "Racun nije ispravan", "Poruka", JOptionPane.ERROR_MESSAGE);
		        	indikatorGreske = true;
		        } else {
		        	indikatorGreske = false;
		        }
		    	
		    	try {
		    		if (indikatorGreske) {
		    			return;
		    		} else {
		    			napraviPresek(fields);
		    		}
				} catch (SQLException e1) {
					System.out.println("exception u GenerisiIzvodStandardForm.java prilikom pravljenja preseka");
					e1.printStackTrace();
				}
		    } 
		});
		
		JLabel lblBrojRacuna = new JLabel("Broj racuna: ");
		JLabel lblDatumNaloga = new JLabel("Datum naloga: ");
		
		dataPanel.add(lblBrojRacuna);
		dataPanel.add(txtBrojRacuna, "wrap 15px");

		dpDatumNaloga.setPreferredSize(new Dimension(120, 0));
		dataPanel.add(lblDatumNaloga);
		dataPanel.add(dpDatumNaloga, "wrap 15px");
				
		dataPanel.add(btnGenerisi, "wrap 51px");
		
		bottomPanel.add(dataPanel);
		bottomPanel.setVisible(true);
		add(bottomPanel, "grow, wrap");
		
	}
	
	protected void napraviPresek(Object[] objData) throws SQLException {
		
		String formatedDate = "";
		data = new Object[objData.length];
		
		for (int i = 0; i < objData.length; i++) {
			if (objData[i] instanceof JTextField) {
				data[i] = ((JTextField) objData[i]).getText().trim();
				System.out.println("Broj racuna: (Data[0]) " + data[0]);
			} else if (objData[i] instanceof JCalendarComboBox) {
				Date datum = ((JCalendarComboBox) objData[i]).getDate();
				if(datum != null) {
					
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					formatedDate = sdf.format(datum);
					
					data[i] = formatedDate;
					System.out.println("Datum za koji pravimo izvod: (Data[1]) " + data[1]);
					
				} else {
					data[i]= "";
				}
			} else {
				System.out.println("Nesto ne valja! ");
			} 
		}
		
		String broj_racuna = (String) data[0];
		String za_datum = (String) data[1];		
		
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						basicQuery
						+ " WHERE BROJ_RACUNA LIKE ? "
						//+ " AND DATUM LIKE ? "
						+ orderBy);
	
		stmt.setString(1, broj_racuna + "%");
		//stmt.setString(2, za_datum + "%");
		
		Integer brojPromenaUKorist = 0;
		Double ukupnoUKorist = 0.0;
		Integer brojPromenaNaTeret = 0;
		Double ukupnoNaTeret = 0.0;
		Integer brojPogresnihStavkiUKorist = 0;
		Integer brojPogresnihStavkiNaTeret = 0;
		String statusNaloga = "F";
		
		Integer redniBrojPreseka = 1;
		Integer brojStavkiUPresekuIzvoda = 0;
		
		ResultSet rowsAffected = stmt.executeQuery();
		while (rowsAffected.next()) {
				
			System.out.println("trazeni broj racuna je: " + broj_racuna);
			System.out.println("broj racuna iz baze je: " + rowsAffected.getString("BROJ_RACUNA"));
			System.out.println("datum u bazi je: " + rowsAffected.getString("DATUM"));
			
			String b_racuna = broj_racuna.trim();
			String br_racuna = rowsAffected.getString("BROJ_RACUNA").trim();
			String datumIzBaze = rowsAffected.getString("DATUM");
			
			//ovo moram ovako porediti jer prave problem "space-ovi" u bazi...
			if (b_racuna.equals(br_racuna)) {
				System.out.println("identicni brojevi racuna");
				String[] datumVreme = datumIzBaze.split(" ");
				
				if (datumVreme[0].trim().equals(za_datum)) {
					System.out.println("DATUM JE ISTI");
					
					brojStavkiUPresekuIzvoda++;
					
					if (Float.valueOf(rowsAffected.getString("PROMET_U_KORIST")) != 0) {
						brojPromenaUKorist++;
						ukupnoUKorist += (Float.valueOf(rowsAffected.getString("PROMET_U_KORIST")));
					}
					
					if (Float.valueOf(rowsAffected.getString("PROMET_NA_TERET")) != 0) {
						brojPromenaNaTeret++;
						ukupnoNaTeret += (Float.valueOf(rowsAffected.getString("PROMET_NA_TERET")));
					}
					
					if (brojStavkiUPresekuIzvoda == 2) {
						
						PresekIzvodaTableModel pitm = new PresekIzvodaTableModel(new String[] {
								"<html><center>Broj<br>racuna",
								"<html><center>Sifra<br>klijenta", 
								"DATUM NALOGA", 
								"<html><center>Broj<br>preseka",
								"DNEBROJRACUNA", 
								"DATUM", 
								"<html><center>Broj promena<br>u korist",
								"<html><center>Ukupno<br>u korist", 
								"<html><center>Broj promena<br> na teret", 
								"<html><center>Ukupno<br>na teret", 
								"<html><center>Broj pogresnih<br>stavki u korist", 
								"<html><center>Broj pogresnih<br>stavki na teret", 
								"<html><center>Status<br>naloga"}, 0);
						
						Object[] noviPresekIzvoda = new Object[13];
						noviPresekIzvoda[0] = broj_racuna; //broj racuna za koji se pravi izvod?
						noviPresekIzvoda[1] = "2"; //sifra klijenta
						noviPresekIzvoda[2] = formatedDate; //za koji datum pravimo izvod
						noviPresekIzvoda[3] = redniBrojPreseka.toString(); //redni broj preseka
						
						//Ovaj deo mislim da se moze (treba?) izbaciti?
						noviPresekIzvoda[4] = broj_racuna; //broj racuna za koji se pravi izvod? OPET?
						noviPresekIzvoda[5] = formatedDate; //neki datum OPET?
						
						noviPresekIzvoda[6] = brojPromenaUKorist.toString();
						noviPresekIzvoda[7] = ukupnoUKorist.toString();
						noviPresekIzvoda[8] = brojPromenaNaTeret.toString();
						noviPresekIzvoda[9] = ukupnoNaTeret.toString();
						noviPresekIzvoda[10] = brojPogresnihStavkiUKorist.toString();
						noviPresekIzvoda[11] = brojPogresnihStavkiNaTeret.toString();
						noviPresekIzvoda[12] = statusNaloga;
						
						pitm.insertRow(noviPresekIzvoda);
					
						formirajPresekIzvoda(noviPresekIzvoda);
						
						brojPromenaUKorist = 0;
						ukupnoUKorist = 0.0;
						brojPromenaNaTeret = 0;
						ukupnoNaTeret = 0.0;
						
						redniBrojPreseka++;
						brojStavkiUPresekuIzvoda = 0;
					}
					
				} else {
					System.out.println("datum nije isti!");
				}
			} else {
				System.out.println("Broj racuna nije identican trazenom");
			}
			
		}
		
		/*System.out.println("  brojpromena u korist: " + brojPromenaUKorist +
							" ukupno u korist " + ukupnoUKorist + 
							" brojPromena na teret: " + brojPromenaNaTeret + 
							" ukupno na teret: " + ukupnoNaTeret);*/

		PresekIzvodaTableModel pitm = new PresekIzvodaTableModel(new String[] {
				"<html><center>Broj<br>racuna",
				"<html><center>Sifra<br>klijenta", 
				"DATUM NALOGA", 
				"<html><center>Broj<br>preseka",
				"DNEBROJRACUNA", 
				"DATUM", 
				"<html><center>Broj promena<br>u korist",
				"<html><center>Ukupno<br>u korist", 
				"<html><center>Broj promena<br> na teret", 
				"<html><center>Ukupno<br>na teret", 
				"<html><center>Broj pogresnih<br>stavki u korist", 
				"<html><center>Broj pogresnih<br>stavki na teret", 
				"<html><center>Status<br>naloga"}, 0);
		
		Object[] noviPresekIzvoda = new Object[13];
		noviPresekIzvoda[0] = broj_racuna; //broj racuna za koji se pravi izvod?
		noviPresekIzvoda[1] = "2"; //sifra klijenta
		noviPresekIzvoda[2] = formatedDate; //za koji datum pravimo izvod
		noviPresekIzvoda[3] = redniBrojPreseka.toString(); //redni broj preseka
		
		//Ovaj deo mislim da se moze (treba?) izbaciti?
		noviPresekIzvoda[4] = broj_racuna; //broj racuna za koji se pravi izvod? OPET?
		noviPresekIzvoda[5] = formatedDate; //neki datum OPET?
		
		noviPresekIzvoda[6] = brojPromenaUKorist.toString();
		noviPresekIzvoda[7] = ukupnoUKorist.toString();
		noviPresekIzvoda[8] = brojPromenaNaTeret.toString();
		noviPresekIzvoda[9] = ukupnoNaTeret.toString();
		noviPresekIzvoda[10] = brojPogresnihStavkiUKorist.toString();
		noviPresekIzvoda[11] = brojPogresnihStavkiNaTeret.toString();
		noviPresekIzvoda[12] = statusNaloga;
		
		pitm.insertRow(noviPresekIzvoda);
		
		formirajPresekIzvoda(noviPresekIzvoda);
		
		
		stmt.close();

	}
	
	public void formirajPresekIzvoda(Object[] data) {
		
		String broj_racuna = (String) data[0];
		String sifra_klijenta = (String) data[1];
		String formatedDate = (String) data[2];
		String redniBrojPreseka = (String) data[3];
		String dne_broj_racuna = (String) data[4];
		String datum = (String) data[5];
		String brojPromenaUKorist = (String) data[6];
		String ukupnoUKorist = (String) data[7];
		String brojPromenaNaTeret = (String) data[8];
		String ukupnoNaTeret = (String) data[9];
		String brojPogresnihStavkiUKorist = (String) data[10];
		String brojPogresnihStavkiNaTeret = (String) data[11];
		String statusNaloga = (String) data[12];
		
		try {
			File presekIzvoda = new File("export/PI-"+(redniBrojPreseka.toString())+"-d-"+formatedDate+"-"+broj_racuna+".xml");
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder;
			
			docBuilder = docFactory.newDocumentBuilder();
		
			Document doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("presek_izvoda");
			doc.appendChild(rootElement);
			
			Element broj_racunaa = doc.createElement("broj_racuna");
			broj_racunaa.appendChild(doc.createTextNode(broj_racuna.toString()));
			rootElement.appendChild(broj_racunaa);
			
			Element sifra_klijentaa = doc.createElement("sifra_klijenta");
			sifra_klijentaa.appendChild(doc.createTextNode(sifra_klijenta));
			rootElement.appendChild(sifra_klijentaa);
			
			Element formatedDatee = doc.createElement("izvod_za_dan");
			formatedDatee.appendChild(doc.createTextNode(formatedDate));
			rootElement.appendChild(formatedDatee);
			
			Element redni_broj_preseka = doc.createElement("redni_broj_preseka");
			redni_broj_preseka.appendChild(doc.createTextNode(redniBrojPreseka.toString()));
			rootElement.appendChild(redni_broj_preseka);
			
			/*Element opet_datum = doc.createElement("opet_datum");
			opet_datum.appendChild(doc.createTextNode("2"));
			rootElement.appendChild(opet_datum);
			
			Element opet_racun = doc.createElement("opet_racun");
			opet_racun.appendChild(doc.createTextNode("2"));
			rootElement.appendChild(opet_racun);*/
			
			Element broj_promena_u_korist = doc.createElement("broj_promena_u_korist");
			broj_promena_u_korist.appendChild(doc.createTextNode(brojPromenaUKorist.toString()));
			rootElement.appendChild(broj_promena_u_korist);
			
			Element ukupno_u_korist = doc.createElement("ukupno_u_korist");
			ukupno_u_korist.appendChild(doc.createTextNode(ukupnoUKorist.toString()));
			rootElement.appendChild(ukupno_u_korist);
			
			Element broj_promena_na_teret = doc.createElement("broj_promena_na_teret");
			broj_promena_na_teret.appendChild(doc.createTextNode(brojPromenaNaTeret.toString()));
			rootElement.appendChild(broj_promena_na_teret);
			
			Element ukupno_na_teret = doc.createElement("ukupno_na_teret");
			ukupno_na_teret.appendChild(doc.createTextNode(ukupnoNaTeret.toString()));
			rootElement.appendChild(ukupno_na_teret);
			
			Element broj_pogresnih_stavki_u_korist = doc.createElement("broj_pogresnih_stavki_u_korist");
			broj_pogresnih_stavki_u_korist.appendChild(doc.createTextNode(brojPogresnihStavkiUKorist.toString()));
			rootElement.appendChild(broj_pogresnih_stavki_u_korist);
			
			Element broj_pogresnih_stavki_na_teret = doc.createElement("broj_pogresnih_stavki_na_teret");
			broj_pogresnih_stavki_na_teret.appendChild(doc.createTextNode(brojPogresnihStavkiNaTeret.toString()));
			rootElement.appendChild(broj_pogresnih_stavki_na_teret);
			
			Element status_naloga = doc.createElement("status_naloga");
			status_naloga.appendChild(doc.createTextNode(statusNaloga.toString()));
			rootElement.appendChild(status_naloga);
			
			
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			transformerFactory.setAttribute("indent-number", 2);
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(presekIzvoda);
			transformer.transform(source, result);
			
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
		
	public boolean validateBrojRacuna(Object object) {
		
		String temp = null;
		if (object instanceof JTextField) {
			temp = ((JTextField) object).getText().trim();
		} 

		String ceoRacun = temp;
		if (!(ceoRacun.matches("\\d{3}\\-\\d{3,13}\\-\\d{2}"))) {
			return true;
		} else {
			return false;
		}

	}
	
}