package gui.dialogs;



import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.File;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.AbstractDocument;

import model.NalogZaTransakcijuTableModel;
import net.miginfocom.swing.MigLayout;
import util.Column;
import util.ColumnList;
import util.ComboItem;
import util.Lookup;
import util.TextfieldDocumentFilter;
import actions.CommitAction;
import actions.IzvrsiNalogAction;
import actions.RollbackAction;
import de.wannawork.jcalendar.JCalendarComboBox;

@SuppressWarnings("serial")
public class NalogZaTransakcijuStandardForm extends PretragaGenStanForm {

	
	private JTextField txtBrojStavke = new JTextField(8);
	private JTextField txtValuta = new JTextField(3);
	private JTextField txtNazivValute = new JTextField(10);
	private JTextField txtSvrha = new JTextField(20);
	private JTextField txtIznos = new JTextField(20);
	private JTextField txtDuznik = new JTextField(20);
	private JTextField txtRacunDuznika = new JTextField(20);
	private JTextField txtModelZaduzenja = new JTextField(2);
	private JTextField txtPozivNaBrojZaduzenja = new JTextField(20);	
	private JTextField txtPoverilac = new JTextField(20);
	private JTextField txtRacunPoverioca = new JTextField(20);
	private JTextField txtModelOdobrenja = new JTextField(2);
	private JTextField txtPozivNaBrojOdobrenja = new JTextField(20);
	private JComboBox<ComboItem> cbTipNaloga = new JComboBox<ComboItem>();
	private JComboBox<ComboItem> cbTipGreske = new JComboBox<ComboItem>();
	private JComboBox<ComboItem> cbStatus = new JComboBox<ComboItem>();
	private JComboBox<ComboItem> cbHitno = new JComboBox<ComboItem>();
	private JCalendarComboBox dpDatum = new JCalendarComboBox();
	private JCalendarComboBox dpDatumValute = new JCalendarComboBox();
	private JButton btnZoom = new JButton("...");
	private JButton btnImport = new JButton("Import");
	private JFileChooser jfc = new JFileChooser();
	private File importFile = new File("import");
	private JButton btnExecute = new JButton("Izvrsi");
	
	
	public NalogZaTransakcijuStandardForm(Column[] sifraColumns, ColumnList columnList, boolean isZoom){
		
		super(
				new NalogZaTransakcijuTableModel(new String[] { "Broj racuna", "Datum",
						"Broj stavke", "Sifra valute", "Tip naloga", "Duznik", "Svrha", "Poverilac",
						"Datum valute", "Racun duznika", "Model zaduzenja", "Poziv na broj zaduzenja",
						"Racun poverioca", "Model odobrenja", "Poziv na broj odobrenja", 
						"Hitno", "Iznos", "Tip greske", "Status"}, 0), sifraColumns, columnList, isZoom);
		setTitle("Transakcije");

		initDetailsPanel();
		addActionHotkeys(true);
	}

	@Override
	public void sync() {
		int index = tblGrid.getSelectedRow();
		if (index < 0) {
			txtBrojStavke.setText("");
			txtSvrha.setText("");
			txtIznos.setText("");
			txtDuznik.setText("");
			txtRacunDuznika.setText("");
			txtModelZaduzenja.setText("");
			txtPozivNaBrojZaduzenja.setText("");
			txtIznos.setText("");
			txtNazivValute.setText("");
			txtPoverilac.setText("");
			txtModelOdobrenja.setText("");
			txtPozivNaBrojOdobrenja.setText("");
			txtValuta.setText("");
			cbTipNaloga.setSelectedIndex(0);
			cbStatus.setSelectedIndex(0);
			cbTipGreske.setSelectedIndex(0);
			cbHitno.setSelectedIndex(0);
			dpDatum.setDate(null);
			dpDatumValute.setDate(null);
			txtNazivValute.setText("");
			
			return;
		}
		String datum = (String) tblGrid.getModel().getValueAt(index, 1);
		String brojStavke = tblGrid.getModel().getValueAt(index, 2).toString();
		String sifraValute = (String) tblGrid.getModel().getValueAt(index, 3);
		String tipNaloga =  tblGrid.getModel().getValueAt(index, 4).toString();
		String duznik = isNullThenEmpty((String) tblGrid.getModel().getValueAt(index, 5));
		String svrha = isNullThenEmpty((String) tblGrid.getModel().getValueAt(index, 6));
		String poverilac = isNullThenEmpty((String) tblGrid.getModel().getValueAt(index, 7));
		String datumValute = (String) tblGrid.getModel().getValueAt(index, 8);
		
		String racunDuznika = isNullThenEmpty((String) tblGrid.getModel().getValueAt(index, 9));
		String modelZaduzenja = isNullThenEmpty((String) tblGrid.getModel().getValueAt(index, 10));
		String pozivNaBrojZaduzenja = isNullThenEmpty((String) tblGrid.getModel().getValueAt(index, 11));
		
		String racunPoverioca = isNullThenEmpty((String) tblGrid.getModel().getValueAt(index, 12));
		String modelOdobrenja = isNullThenEmpty((String) tblGrid.getModel().getValueAt(index, 13));
		String pozivNaBrojOdobrenja = isNullThenEmpty((String) tblGrid.getModel().getValueAt(index, 14));
		
		String hitno = (String) tblGrid.getModel().getValueAt(index,15);
		String iznos = (String) tblGrid.getModel().getValueAt(index, 16);
		System.out.println("Iznos: "+iznos);
		String tipGreske = (String) tblGrid.getModel().getValueAt(index, 17);
		String status = (String) tblGrid.getModel().getValueAt(index, 18);

		txtBrojStavke.setText(brojStavke.trim());
		txtSvrha.setText(svrha.trim());
		txtIznos.setText(iznos.trim());
		txtDuznik.setText(duznik.trim());
		txtRacunDuznika.setText(racunDuznika.trim());
		txtModelZaduzenja.setText(modelZaduzenja.trim());
		txtPozivNaBrojZaduzenja.setText(pozivNaBrojZaduzenja.trim());
		txtPoverilac.setText(poverilac.trim());
		txtRacunPoverioca.setText(racunPoverioca.trim());
		txtModelOdobrenja.setText(modelOdobrenja.trim());
		txtPozivNaBrojOdobrenja.setText(pozivNaBrojOdobrenja.trim());
		txtValuta.setText(sifraValute.trim());
		ComboItem.setSelectedItem(cbTipNaloga, tipNaloga);
		ComboItem.setSelectedItem(cbStatus, status);
		ComboItem.setSelectedItem(cbTipGreske, tipGreske);
		ComboItem.setSelectedItem(cbHitno, hitno);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		if(!sifraValute.equals(""))
			try {
				txtNazivValute.setText(Lookup.getValuta(sifraValute));
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		Date date = new Date();
		Date vDate = new Date();
		try {
			date = sdf.parse(datum);
			vDate = sdf.parse(datumValute);
		} catch (ParseException e) {
			System.out.println("datum nije isparsiran");
			e.printStackTrace();
		}
		dpDatum.setDate(date);
		dpDatumValute.setDate(vDate);
		
	}

	@Override
	public void eraseFieldsAndRequestFocus() {
		txtBrojStavke.requestFocus();
		txtBrojStavke.setText("");
		txtSvrha.setText("");
		txtIznos.setText("");
		txtDuznik.setText("");
		txtNazivValute.setText("");
		txtRacunDuznika.setText("");
		txtModelZaduzenja.setText("");
		txtPozivNaBrojZaduzenja.setText("");
		txtPoverilac.setText("");
		txtModelOdobrenja.setText("");
		txtPozivNaBrojOdobrenja.setText("");
		txtValuta.setText("");
		txtIznos.setText("");
		txtRacunPoverioca.setText("");
		cbTipNaloga.setSelectedIndex(0);
		cbStatus.setSelectedIndex(0);
		cbTipGreske.setSelectedIndex(0);
		cbHitno.setSelectedIndex(0);
		dpDatum.setDate(null);
		dpDatumValute.setDate(null);
		
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[19];
		columns[0] = new Column();
		columns[0].setName("broj_racuna");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));
		
		columns[1] = new Column();
		columns[1].setName("datum");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));
		
		columns[2] = new Column();
		columns[2].setName("asi_brojstavke");
		columns[2].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 2));
		
		columns[3] = new Column();
		columns[3].setName("va_sifra");
		columns[3].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 3));
		
		columns[4] = new Column();
		columns[4].setName("tip_naloga");
		columns[4].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 4));
		
		columns[5] = new Column();
		columns[5].setName("asi_duznik");
		columns[5].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 5));
		
		columns[6] = new Column();
		columns[6].setName("asi_svrha");
		columns[6].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 6));
		
		columns[7] = new Column();
		columns[7].setName("asi_poverilac");
		columns[7].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 7));
		
		columns[8] = new Column();
		columns[8].setName("asi_datval");
		columns[8].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 8));
		
		columns[9] = new Column();
		columns[9].setName("asi_racduz");
		columns[9].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 9));
		
		columns[10] = new Column();
		columns[10].setName("asi_modzad");
		columns[10].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 10));
		
		columns[11] = new Column();
		columns[11].setName("asi_pbzad");
		columns[11].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 11));
		
		columns[12] = new Column();
		columns[12].setName("asi_racpov");
		columns[12].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 12));
		
		columns[13] = new Column();
		columns[13].setName("asi_mododob");
		columns[13].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 13));
		
		columns[14] = new Column();
		columns[14].setName("asi_pbodo");
		columns[14].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 14));
		
		columns[15] = new Column();
		columns[15].setName("asi_hitno");
		columns[15].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 15));
		
		columns[16] = new Column();
		columns[16].setName("asi_iznos");
		columns[16].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 16));
		
		columns[17] = new Column();
		columns[17].setName("asi_tipgreske");
		columns[17].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 17));
		
		columns[18] = new Column();
		columns[18].setName("asi_status");
		columns[18].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 18));
		
		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		Column[] sifraColumns = new Column[3];
		int index = tblGrid.getSelectedRow();
		String sifraRacun = (String) tableModel.getValueAt(index, 0);
		String sifraDatum = (String) tableModel.getValueAt(index, 1);
		String sifraBroj = (String) tableModel.getValueAt(index, 2);
		
		sifraColumns[0] = new Column("broj_racuna", sifraRacun);
		sifraColumns[1] = new Column("datum", sifraDatum);
		sifraColumns[2] = new Column("asi_brojstavke", sifraBroj);

		
		return sifraColumns;
	}


	@Override
	protected void initDetailsPanel() {
		
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout());
		JPanel buttonsPanel = new JPanel();
		btnImport = new JButton("Import");

	    btnImport.addActionListener(new ActionListener() {
	        //Handle open button action.
	        public void actionPerformed(ActionEvent e) {
	            final JFileChooser fc = new JFileChooser(); 
	            fc.setFileFilter(new FileNameExtensionFilter("xml files (*.xml)", "xml"));
	            int returnVal = fc.showOpenDialog(new JFrame());
	            if (returnVal == JFileChooser.APPROVE_OPTION) {
	                importFile = fc.getSelectedFile();
	                ((NalogZaTransakcijuTableModel)tableModel).importFile(importFile);
	            }
	        }
	    });
		super.getToolbar().add(btnImport);
	    btnExecute = new JButton(new IzvrsiNalogAction(this, tableModel));
		super.getToolbar().add(btnExecute);
		
		cbTipNaloga.addItem(new ComboItem());
		cbTipNaloga.addItem(new ComboItem("1", "Uplata"));
		cbTipNaloga.addItem(new ComboItem("2", "Isplata"));
		cbTipNaloga.addItem(new ComboItem("3", "Prenos"));
		
		cbHitno.addItem(new ComboItem());
		cbHitno.addItem(new ComboItem("1", "Hitno"));
		cbHitno.addItem(new ComboItem("0", "Nije hitno"));
		
		cbTipGreske.addItem(new ComboItem());
		cbTipGreske.addItem(new ComboItem("1","Izvrsen"));
		cbTipGreske.addItem(new ComboItem("2", "Neizvrsen zbog nelikvidnost podracuna korisnika"));
		cbTipGreske.addItem(new ComboItem("3", "Neizvrsen zbog nelikvidnosti racuna nosioca u NJB"));
		cbTipGreske.addItem(new ComboItem("8", "Pogresan nalog"));
		cbTipGreske.addItem(new ComboItem("9", "Nalog stopiran za izvrsenje"));
		cbTipGreske.setPrototypeDisplayValue(new ComboItem("x", "Prototip duzine teksta........................."));
		
		cbStatus.addItem(new ComboItem());
		cbStatus.addItem(new ComboItem("E", "Evidentiran"));
		cbStatus.addItem(new ComboItem("P", "Poslat"));

		
		
		Object[] fields = new Object[19];
		
		fields[0] = new JTextField(1);
		fields[1] = dpDatum;
		fields[2] = txtBrojStavke;
		fields[3] = txtValuta;
		fields[4] = cbTipNaloga;
		fields[5] = txtDuznik;
		fields[6] = txtSvrha;
		fields[7] = txtPoverilac;
		fields[8] = dpDatumValute;
		fields[9] = txtRacunDuznika;
		fields[10] = txtModelZaduzenja;
		fields[11] = txtPozivNaBrojZaduzenja;
		fields[12] = txtRacunPoverioca;
		fields[13] = txtModelOdobrenja;
		fields[14] = txtPozivNaBrojOdobrenja;
		fields[15] = cbHitno;
		fields[16] = txtIznos;
		fields[17] = cbTipGreske;
		fields[18] = cbStatus;

		
		((AbstractDocument) txtBrojStavke.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(255, true));
		((AbstractDocument) txtSvrha.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(255, false));
		((AbstractDocument) txtIznos.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(15, true, true));
		((AbstractDocument) txtDuznik.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(255, false));
		((AbstractDocument) txtRacunDuznika.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(20, false));
		((AbstractDocument) txtModelZaduzenja.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(2, true));
		((AbstractDocument) txtPozivNaBrojZaduzenja.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(20, false));
		((AbstractDocument) txtPoverilac.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(255, false));
		((AbstractDocument) txtRacunPoverioca.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(20, false));
		((AbstractDocument) txtModelOdobrenja.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(2, true));
		((AbstractDocument) txtPozivNaBrojOdobrenja.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(20, false));
		((AbstractDocument) txtValuta.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(3, false));
		
		btnZoom.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				ValuteStandardForm form = new ValuteStandardForm(null, columnList,
						true);
				form.setVisible(true);
				if (columnList.getColumnCount() != 0) {
					txtNazivValute.setText(columnList.getValue("VA_NAZIV")
							.toString());
					txtValuta.setText(columnList.getValue("VA_SIFRA")
							.toString());
				}
			}
		});
		txtValuta.addFocusListener(new FocusAdapter() {
			public void focusLost(FocusEvent e) {
				String sifraValute = txtValuta.getText().trim();
				try {
					txtNazivValute.setText(Lookup.getValuta(sifraValute));
					if (txtNazivValute.getText().equals(""))
						txtNazivValute.setText("Neispravna šifra");
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		

		
		
		btnCommit = new JButton(new CommitAction(this, fields, tblGrid));
		btnRollback = new JButton(new RollbackAction(this));
		
		JLabel lblBrojStavke = new JLabel("Broj stavke:");
		JLabel lblSvrha = new JLabel("Svrha:");
		JLabel lblIznos = new JLabel("Iznos:");
		JLabel lblDuznik = new JLabel("Duznik:");
		JLabel lblRacunDuznika = new JLabel("Racun duznika:");
		JLabel lblModelZaduzenja = new JLabel("Model:");
		JLabel lblPozivNaBrojZaduzenja = new JLabel("Poziv na broj zaduzenja:");
		JLabel lblPoverilac = new JLabel("Poverilac:");
		JLabel lblRacunPoverioca = new JLabel("Racun poverioca:");
		JLabel lblModelOdobrenja = new JLabel("Model:");
		JLabel lblPozivNaBrojOdobrenja = new JLabel("Poziv na broj odobrenja:");
		JLabel lblSifraValute = new JLabel("Valuta:");
		JLabel lblTipNaloga = new JLabel("Tip naloga:");
		JLabel lblTipGreske = new JLabel("Tip greske:");
		JLabel lblStatus = new JLabel("Status:");
		JLabel lblHitno = new JLabel("Hitno:");
		JLabel lblDatum = new JLabel("Datum");
		JLabel lblDatumValute = new JLabel("Datum valute:");

		
		dpDatum.setPreferredSize(new Dimension(120, 0));
		dpDatumValute.setPreferredSize(new Dimension(120, 0));
		
		dataPanel.add(lblTipNaloga);
		dataPanel.add(cbTipNaloga, "gapx 15px");
		dataPanel.add(lblSifraValute);
		dataPanel.add(txtValuta, "gapx 15px, split 3");
		dataPanel.add(btnZoom);
		dataPanel.add(txtNazivValute, "pushx, wrap");
		txtNazivValute.setEditable(false);
		
		dataPanel.add(lblBrojStavke);
		dataPanel.add(txtBrojStavke, "gapx 15px");
		dataPanel.add(lblDatumValute);
		dataPanel.add(dpDatumValute, "wrap, gapx 15px");
		
		dataPanel.add(lblDatum);
		dataPanel.add(dpDatum, "gapx 15px");
		dataPanel.add(lblIznos);
		dataPanel.add(txtIznos, "wrap, gapx 15px");
		
		dataPanel.add(lblStatus);
		dataPanel.add(cbStatus, "gapx 15px");
		dataPanel.add(lblSvrha);
		dataPanel.add(txtSvrha, "wrap, gapx 15px");
		
		dataPanel.add(lblTipGreske);
		dataPanel.add(cbTipGreske, "gapx 15px");
		dataPanel.add(lblHitno);
		dataPanel.add(cbHitno, "wrap, gapx 15px");
		
		dataPanel.add(lblDuznik);
		dataPanel.add(txtDuznik, "gapx 15px");
		dataPanel.add(lblPoverilac);
		dataPanel.add(txtPoverilac, "wrap, gapx 15px");
		
		dataPanel.add(lblRacunDuznika);
		dataPanel.add(txtRacunDuznika, "gapx 15px");
		dataPanel.add(lblRacunPoverioca);
		dataPanel.add(txtRacunPoverioca, "wrap, gapx 15px");
		
		dataPanel.add(lblModelZaduzenja);
		dataPanel.add(txtModelZaduzenja, "gapx 15px");
		dataPanel.add(lblModelOdobrenja);
		dataPanel.add(txtModelOdobrenja, "wrap, gapx 15px");
		
		dataPanel.add(lblPozivNaBrojZaduzenja);
		dataPanel.add(txtPozivNaBrojZaduzenja, "gapx 15px");
		dataPanel.add(lblPozivNaBrojOdobrenja);
		dataPanel.add(txtPozivNaBrojOdobrenja, "wrap, gapx 15px");

		
		bottomPanel.add(dataPanel);
		
		buttonsPanel.setLayout(new MigLayout("wrap"));
		buttonsPanel.add(btnCommit);
		buttonsPanel.add(btnRollback);
		bottomPanel.add(buttonsPanel, "dock east");

		add(bottomPanel, "grow, wrap");
	}

	@Override
	public String validateInput() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public static String isNullThenEmpty(String str) {
		String retVal = "";
		if (str != null)
			retVal = str;
		return retVal;
	}

}
