package gui.dialogs;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.RacunTableModel;
import net.miginfocom.swing.MigLayout;
import util.Column;
import util.ColumnList;
import actions.CommitAction;
import actions.RollbackAction;
import actions.ZatvoriRacunAction;

@SuppressWarnings("serial")
public class RacunStandardForm extends FullGenStanForm {

	private JTextField txtBroj = new JTextField(18);
	private JTextField txtSifraKlijenta = new JTextField(5);
	private JTextField txtSifraBanke = new JTextField(3);
	private JTextField txtSifraVA = new JTextField(3);
	private JCheckBox cbZatvoren = new JCheckBox();
	private ColumnList columnList = new ColumnList();

	public RacunStandardForm(ColumnList columnList, boolean isZoom) {
		super(new RacunTableModel(new String[] { "Broj racuna",
				"Sifra klijenta", "Sifra banke", "VA sifra", "Zatvoren",
				"Datum otvaranja" }, 0), null, columnList, isZoom);
		setTitle("Racuni");
		initDetailsPanel();
	}

	@Override
	public void sync() {
		int index = tblGrid.getSelectedRow();

		if (index < 0) {
			txtBroj.setText("");
			txtSifraKlijenta.setText("");
			txtSifraBanke.setText("");
			txtSifraVA.setText("");
			cbZatvoren.setSelected(false);
			return;
		}

		String broj = (String) tableModel.getValueAt(index, 0);
		String sifraKlijenta = (String) tableModel.getValueAt(index, 1);
		String sifraBanke = (String) tableModel.getValueAt(index, 2);
		String sifraVa = (String) tableModel.getValueAt(index, 3);
		String zatvoren = (String) tableModel.getValueAt(index, 4);

		txtBroj.setText(broj.trim());
		txtSifraKlijenta.setText(sifraKlijenta.trim());
		txtSifraBanke.setText(sifraBanke.trim());
		txtSifraVA.setText(sifraVa.trim());
		cbZatvoren.setSelected(zatvoren.equals("1"));
	}

	@Override
	public void eraseFieldsAndRequestFocus() {
		txtBroj.setText("");
		txtSifraKlijenta.setText("");
		txtSifraBanke.setText("");
		txtSifraVA.setText("");
		cbZatvoren.setSelected(false);

		txtBroj.requestFocus();
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[5];

		columns[0] = new Column();
		columns[0].setName("broj_racuna");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));

		columns[1] = new Column();
		columns[1].setName("sifra_klijenta");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));

		columns[2] = new Column();
		columns[2].setName("sifra_banke");
		columns[2].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 2));

		columns[3] = new Column();
		columns[3].setName("va_sifra");
		columns[3].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 3));

		columns[4] = new Column();
		columns[4].setName("zatvoren");
		columns[4].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 4));

		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		try {
			return new Column[] { new Column("broj_racuna",
					(String) tableModel.getValueAt(tblGrid.getSelectedRow(), 0)) };
		} catch (Exception e) {
			return null;
		}
	}

	@Override
	protected void initDetailsPanel() {
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout("gapx 15px"));

		JPanel buttonsPanel = new JPanel();
		JTextField[] textFields = new JTextField[] { txtBroj, txtSifraKlijenta,
				txtSifraBanke, txtSifraVA };

		btnCommit = new JButton(new CommitAction(this, textFields, tblGrid));
		btnRollback = new JButton(new RollbackAction(this));
		JButton btnZatvori = new JButton(new ZatvoriRacunAction(this));

		dataPanel.add(new JLabel("Broj racuna:"));
		dataPanel.add(txtBroj, "wrap");
		dataPanel.add(new JLabel("Sifra klijenta:"));
		dataPanel.add(txtSifraKlijenta, "wrap");
		dataPanel.add(new JLabel("Sifra banke:"));
		dataPanel.add(txtSifraBanke, "wrap");
		dataPanel.add(new JLabel("Sifra VA:"));
		dataPanel.add(txtSifraVA, "wrap");
		dataPanel.add(new JLabel("Zatvoren:"));
		cbZatvoren.setEnabled(false);
		dataPanel.add(cbZatvoren);
		bottomPanel.add(dataPanel);

		buttonsPanel.setLayout(new MigLayout("wrap"));
		buttonsPanel.add(btnCommit);
		buttonsPanel.add(btnRollback);
		buttonsPanel.add(btnZatvori);
		bottomPanel.add(buttonsPanel, "dock east");

		add(bottomPanel, "grow, wrap");
	}

	@Override
	public String validateInput() {
		if (txtBroj.getText().length() == 0) {
			txtBroj.requestFocus();
			return "Broj racuna je obavezan!";
		}

		if (txtSifraKlijenta.getText().length() == 0) {
			txtSifraKlijenta.requestFocus();
			return "Sifra klijenta je obavezna!";
		}

		if (txtSifraBanke.getText().length() == 0) {
			txtSifraBanke.requestFocus();
			return "Sifra klijenta je obavezna!";
		}

		if (txtSifraVA.getText().length() == 0) {
			txtSifraVA.requestFocus();
			return "Sifra VA je obavezna!";
		}

		return null;
	}

}
