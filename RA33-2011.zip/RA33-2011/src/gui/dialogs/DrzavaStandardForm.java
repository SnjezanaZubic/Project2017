package gui.dialogs;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;

import model.DrzaveTableModel;
import net.miginfocom.swing.MigLayout;
import util.Column;
import util.ColumnList;
import util.TextfieldDocumentFilter;
import actions.CommitAction;
import actions.RollbackAction;

@SuppressWarnings("serial")
public class DrzavaStandardForm extends FullGenStanForm {

	private JTextField txtSifra = new JTextField(5);
	private JTextField txtNaziv = new JTextField(20);
	private ColumnList columnList = new ColumnList();

	public DrzavaStandardForm(ColumnList columnList, boolean isZoom) {
		super(new DrzaveTableModel(new String[] { "Šifra", "Naziv" }, 0), null,
				columnList, isZoom);
		setTitle("Države");

		initDetailsPanel();

		nextFormAction.addPopupItems(new String[] { "NaseljenoMestoAction" });
		
		addActionHotkeys(false);
	}

	public void sync() {
		int index = tblGrid.getSelectedRow();

		if (index < 0) {
			txtSifra.setText("");
			txtNaziv.setText("");
			return;
		}

		String sifra = (String) tableModel.getValueAt(index, 0);
		String naziv = (String) tableModel.getValueAt(index, 1);
		txtSifra.setText(sifra.trim());
		txtNaziv.setText(naziv.trim());
	}

	protected void initDetailsPanel() {

		((AbstractDocument) txtSifra.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(2, false));
		((AbstractDocument) txtNaziv.getDocument())
				.setDocumentFilter(new TextfieldDocumentFilter(40, false));

		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout("gapx 15px"));

		JPanel buttonsPanel = new JPanel();
		JTextField[] textFields = new JTextField[2];
		textFields[0] = txtSifra;
		textFields[1] = txtNaziv;
		btnCommit = new JButton(new CommitAction(this, textFields, tblGrid));
		btnRollback = new JButton(new RollbackAction(this));

		JLabel lblSifra = new JLabel("Šifra države:");
		JLabel lblNaziv = new JLabel("Naziv države:");

		dataPanel.add(lblSifra);
		dataPanel.add(txtSifra, "wrap");
		dataPanel.add(lblNaziv);
		dataPanel.add(txtNaziv);
		bottomPanel.add(dataPanel);

		buttonsPanel.setLayout(new MigLayout("wrap"));
		buttonsPanel.add(btnCommit);
		buttonsPanel.add(btnRollback);
		bottomPanel.add(buttonsPanel, "dock east");

		add(bottomPanel, "grow, wrap");
		
	}

	@Override
	public void eraseFieldsAndRequestFocus() {
		txtSifra.requestFocus();
		txtSifra.setText("");
		txtNaziv.setText("");
	}

	public ColumnList getColumnList() {
		return columnList;
	}

	public void setColumnList(ColumnList columnList) {
		this.columnList = columnList;
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[2];

		columns[0] = new Column();
		columns[0].setName("dr_sifra");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));

		columns[1] = new Column();
		columns[1].setName("dr_naziv");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));

		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		Column[] sifraColumns = new Column[1];
		int index = tblGrid.getSelectedRow();
		String sifra = (String) tableModel.getValueAt(index, 0);
		sifraColumns[0] = new Column("dr_sifra", sifra);
		return sifraColumns;
	}

	@Override
	public String validateInput() {
		if (txtSifra.getText().length() == 0) {
			txtSifra.requestFocus();
			return "Šifra države je obavezna!";
		}
		if (txtNaziv.getText().length() == 0) {
			txtNaziv.requestFocus();
			return "Naziv države je obavezan!";
		}
		return null;
	}

}
