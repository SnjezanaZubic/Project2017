package gui.dialogs;

import java.awt.Dimension;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.text.AbstractDocument;

import model.PresekIzvodaTableModel;
import net.miginfocom.swing.MigLayout;
import util.Column;
import util.ColumnList;
import util.TextfieldDocumentFilter;
import actions.CommitAction;
import actions.GenerisanjeIzvodaAction;
import actions.IzvrsiNalogAction;
import actions.RollbackAction;
import de.wannawork.jcalendar.JCalendarComboBox;

@SuppressWarnings("serial")
public class PresekIzvodaStandardForm extends PretragaGenStanForm {

	private JTextField txtBrojPreseka = new JTextField(2);
	private JCalendarComboBox dpDatumNaloga = new JCalendarComboBox();
	private JTextField txtBrojRacuna = new JTextField(15);
	private JTextField txtSifraKlijenta = new JTextField(6);
	private JTextField txtdnebrojracuna = new JTextField(15);
	private JCalendarComboBox dpDatum = new JCalendarComboBox();
	private JTextField txtBrojPromenaUKorist = new JTextField(6);
	private JTextField txtUkupnoUKorist = new JTextField(15);
	private JTextField txtBrojPromenatNaTeret = new JTextField(6);
	private JTextField txtUkupnoNaTeret = new JTextField(15);
	private JTextField txtBrojPogresnihStavkiUKorist = new JTextField(6);
	private JTextField txtBrojPogresnihStavkiNaTeret = new JTextField(6);
	private JTextField txtStatusNaloga = new JTextField(2);
	private JButton btnGenerisiIzvod = new JButton("Izvrsi");

	private JButton btnZoom = new JButton("...");
	
	public PresekIzvodaStandardForm(Column[] sifraColumns,
			ColumnList columnList, boolean isZoom) {
		super(new PresekIzvodaTableModel(new String[] {
				"<html><center>Broj<br>racuna",
				"<html><center>Sifra<br>klijenta", 
				"DATUM NALOGA", 
				"<html><center>Broj<br>preseka",
				"DNEBROJRACUNA", 
				"DATUM", 
				"<html><center>Broj promena<br>u korist",
				"<html><center>Ukupno<br>u korist", 
				"<html><center>Broj promena<br> na teret", 
				"<html><center>Ukupno<br>na teret", 
				"<html><center>Broj pogresnih<br>stavki u korist", 
				"<html><center>Broj pogresnih<br>stavki na teret", 
				"<html><center>Status<br>naloga"}, 0), 
				sifraColumns, columnList, isZoom);

		setTitle("Presek izvoda");

		initDetailsPanel();
		
//		nextFormAction.addPopupItems(new String[]{"FizickoLiceAction", "PravnoLiceAction"});
	}

	protected void initDetailsPanel() {
		
		((AbstractDocument)txtBrojRacuna.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(20, false));
		((AbstractDocument)txtSifraKlijenta.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(5, true));
		((AbstractDocument)txtBrojPreseka.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(2, true));
		((AbstractDocument)txtdnebrojracuna.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(20, false));
		((AbstractDocument)txtBrojPromenaUKorist.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(6, true));
		((AbstractDocument)txtUkupnoUKorist.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(15, true, true)); //NECE da izbrise vrednost iz polja ako ovde stoji true!
		((AbstractDocument)txtBrojPromenatNaTeret.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(6, true));
		((AbstractDocument)txtUkupnoNaTeret.getDocument()) 
		.setDocumentFilter(new TextfieldDocumentFilter(15, true, true)); //NECE da izbrise vrednost iz polja ako ovde stoji true!
																		 //A ako NE stavim true onda nece da prikazuje double vrednosti
		((AbstractDocument)txtBrojPogresnihStavkiUKorist.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(6, true));
		((AbstractDocument)txtBrojPogresnihStavkiNaTeret.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(6, true));
		((AbstractDocument)txtStatusNaloga.getDocument())
		.setDocumentFilter(new TextfieldDocumentFilter(1, false));
		
		btnGenerisiIzvod = new JButton(new GenerisanjeIzvodaAction());
		super.getToolbar().add(btnGenerisiIzvod);
		
		JPanel bottomPanel = new JPanel();
		bottomPanel.setLayout(new MigLayout("fillx"));
		JPanel dataPanel = new JPanel();
		dataPanel.setLayout(new MigLayout());

		Object[] fields = new Object[13];
		
		JPanel buttonsPanel = new JPanel();
		fields[0] = txtBrojRacuna;
		fields[1] = txtSifraKlijenta;
		fields[2] = dpDatumNaloga;
		fields[3] = txtBrojPreseka;
		fields[4] = txtdnebrojracuna;
		fields[5] = dpDatum;
		fields[6] = txtBrojPromenaUKorist;
		fields[7] = txtUkupnoUKorist;
		fields[8] = txtBrojPromenatNaTeret;
		fields[9] = txtUkupnoNaTeret;
		fields[10] = txtBrojPogresnihStavkiUKorist;
		fields[11] = txtBrojPogresnihStavkiNaTeret;
		fields[12] = txtStatusNaloga;
		
		btnCommit = new JButton(new CommitAction(this, fields, tblGrid));
		btnRollback = new JButton(new RollbackAction(this));

		JLabel lblBrojRacuna = new JLabel("Broj racuna:");
		JLabel lblSifraKlijenta = new JLabel("Sifra klijenta");
		JLabel lblDatumNaloga = new JLabel("Datum naloga");
		JLabel lblBrojPreseka = new JLabel("Broj preseka:");
		JLabel lblDnebrojracuna = new JLabel("dnebrojracuna:");
		JLabel lblDatum = new JLabel("datum:");
		JLabel lblBrojPromenaUKorist = new JLabel("Broj promena u korist:");
		JLabel lblUkupnoUKorist = new JLabel("Ukupno u korist:");
		JLabel lblBrojPromenaNaTeret = new JLabel("Broj promena na teret:");
		JLabel lblUkupnoNaTeret = new JLabel("Ukupno na teret:");
		JLabel lblBrojPogresnihStavkiUKorist = new JLabel("Broj pogresnih stavki u korist:");
		JLabel lblBrojPogresnihStavkiNaTeret = new JLabel("Broj pogresnih stavki na teret:");
		JLabel lblStatusNaloga = new JLabel("Status naloga");

		
		// ako je child forma -> disable sifra drzave za unos
	/*	if (sifraColumns != null) {
			txtSifraDrzave.setEditable(false);
			btnZoom.setEnabled(false);
		}*/
		dpDatumNaloga.setPreferredSize(new Dimension(120, 0));
		dpDatum.setPreferredSize(new Dimension(120, 0));

		dataPanel.add(lblBrojRacuna);
		dataPanel.add(txtBrojRacuna, "gapx 15px");
		dataPanel.add(lblSifraKlijenta);
		dataPanel.add(txtSifraKlijenta, "wrap 15px");
		dataPanel.add(lblDatumNaloga);
		dataPanel.add(dpDatumNaloga, "gapx 15px");
		dataPanel.add(lblBrojPreseka);
		dataPanel.add(txtBrojPreseka, "wrap 15px");
		dataPanel.add(lblDnebrojracuna);
		dataPanel.add(txtdnebrojracuna, "gapx 15px");
		dataPanel.add(lblDatum);
		dataPanel.add(dpDatum, "wrap 15px");
		dataPanel.add(lblBrojPromenaUKorist);
		dataPanel.add(txtBrojPromenaUKorist, "gapx 15px");
		dataPanel.add(lblBrojPromenaNaTeret);
		dataPanel.add(txtBrojPromenatNaTeret, "wrap 15px");
		dataPanel.add(lblUkupnoUKorist);
		dataPanel.add(txtUkupnoUKorist, "gapx 15px");
		dataPanel.add(lblUkupnoNaTeret);
		dataPanel.add(txtUkupnoNaTeret, "wrap 15px");
		dataPanel.add(lblBrojPogresnihStavkiUKorist);
		dataPanel.add(txtBrojPogresnihStavkiUKorist, "gapx 15px");
		dataPanel.add(lblBrojPogresnihStavkiNaTeret);
		dataPanel.add(txtBrojPogresnihStavkiNaTeret, "wrap 15px");
		dataPanel.add(lblStatusNaloga);
		dataPanel.add(txtStatusNaloga, "gapx 15px");

	
		bottomPanel.add(dataPanel);

		buttonsPanel.setLayout(new MigLayout("wrap"));
		buttonsPanel.add(btnCommit);
		buttonsPanel.add(btnRollback);
		bottomPanel.add(buttonsPanel, "dock east");

		add(bottomPanel, "grow, wrap");


	}

	public void sync() {
		int index = tblGrid.getSelectedRow();
		if (index < 0) {
			txtBrojRacuna.setText("");
			txtSifraKlijenta.setText("");
			dpDatumNaloga.setDate(null);
			txtBrojPreseka.setText("");
			txtdnebrojracuna.setText("");
			dpDatum.setDate(null);
			txtBrojPromenaUKorist.setText("");
			txtBrojPromenatNaTeret.setText("");
			txtUkupnoUKorist.setText("");
			txtUkupnoNaTeret.setText("");
			txtBrojPogresnihStavkiUKorist.setText("");
			txtBrojPogresnihStavkiNaTeret.setText("");
			txtStatusNaloga.setText("");
			return;
		}
		String brojRacuna = (String) tblGrid.getModel().getValueAt(index, 0);
		String sifraKlijenta = (String) tblGrid.getModel().getValueAt(index, 1);
		String datumNaloga = (String) tblGrid.getModel().getValueAt(index, 2);
		String brojPreseka = (String) tblGrid.getModel().getValueAt(index, 3);
		String dnebrojracuna = (String) tblGrid.getModel().getValueAt(index, 4);
		String datum = (String) tblGrid.getModel().getValueAt(index, 5);
		String brojPromenaUKorist = (String) tblGrid.getModel().getValueAt(index, 6);
		String ukupnoUKorist = (String) tblGrid.getModel().getValueAt(index, 7);
		String brojPromenaNaTeret = (String) tblGrid.getModel().getValueAt(index, 8);
		String ukupnoNaTeret = (String) tblGrid.getModel().getValueAt(index, 9);
		String brojPogresnihStavkiUKorist = (String) tblGrid.getModel().getValueAt(index, 10);
		String brojPogresnihStavkiNaTeret = (String) tblGrid.getModel().getValueAt(index, 11);
		String statusNaloga = (String) tblGrid.getModel().getValueAt(index, 12);
		
		txtBrojRacuna.setText(brojRacuna.trim());
		txtSifraKlijenta.setText(sifraKlijenta.trim());
		//dpDatumNaloga;
		txtBrojPreseka.setText(brojPreseka.trim());
		txtdnebrojracuna.setText(dnebrojracuna.trim());
		//dpDatum;
		txtBrojPromenaUKorist.setText(brojPromenaUKorist.trim());
		txtUkupnoUKorist.setText(ukupnoUKorist.trim());
		txtBrojPromenatNaTeret.setText(brojPromenaNaTeret.trim());
		txtUkupnoNaTeret.setText(ukupnoNaTeret.trim());
		txtBrojPogresnihStavkiUKorist.setText(brojPogresnihStavkiUKorist.trim());
		txtBrojPogresnihStavkiNaTeret.setText(brojPogresnihStavkiNaTeret.trim());
		txtStatusNaloga.setText(statusNaloga.trim());
	
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date dNaloga = new Date();
		Date d = new Date();
		try {
			dNaloga = sdf.parse(datumNaloga);
			d = sdf.parse(datum);
		} catch (ParseException e) {
			System.out.println("datum nije isparsiran");
			e.printStackTrace();
		}
		dpDatumNaloga.setDate(dNaloga);
		dpDatum.setDate(d);
	}

	public ColumnList getColumnList() {
		return columnList;
	}

	public void setColumnList(ColumnList columnList) {
		this.columnList = columnList;
	}

	@Override
	public void eraseFieldsAndRequestFocus() {
		txtBrojRacuna.requestFocus();
		txtBrojRacuna.setText("");
		txtSifraKlijenta.setText("");
		dpDatumNaloga.setDate(null);
		txtBrojPreseka.setText("");
		txtdnebrojracuna.setText("");
		dpDatum.setDate(null);
		txtBrojPromenaUKorist.setText("");
		txtBrojPromenatNaTeret.setText("");
		txtUkupnoUKorist.setText("");
		txtUkupnoNaTeret.setText("");
		txtBrojPogresnihStavkiUKorist.setText("");
		txtBrojPogresnihStavkiNaTeret.setText("");
		txtStatusNaloga.setText("");
	}

	@Override
	public Column[] getCurrentRow() {
		Column[] columns = new Column[2];

		/*columns[0] = new Column();
		columns[0].setName("brojRacuna");
		columns[0].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 0));

		columns[1] = new Column();
		columns[1].setName("sifraKlijenta");
		columns[1].setValue(tableModel.getValueAt(tblGrid.getSelectedRow(), 1));*/

		return columns;
	}

	@Override
	public Column[] getSifraColumns() {
		Column[] sifraColumns = new Column[1];
		/*int index = tblGrid.getSelectedRow();
		String sifra = (String) tableModel.getValueAt(index, 0);
		// TODO: mora "klijent.ptt_broj" jer ako stavim samo "ptt_broj" onda bude ambiguous
		sifraColumns[0] = new Column("klijent.ptt_broj", sifra);*/
		return sifraColumns;
	}

	@Override
	public String validateInput() {
	/*		txtBrojPreseka.requestFocus();
			return "Broj preseka je obavezan!";
		}
		if (txtBrojRacuna.getText().length() == 0) {
			txtBrojRacuna.requestFocus();
			return "Broj racuna je obavezan!";	
		}
		if (txtSifraKlijenta.getText().length() == 0) {
			txtSifraKlijenta.requestFocus();
			return "Šifra klijenta je obavezna!";
		} */
		return null;
	}

}