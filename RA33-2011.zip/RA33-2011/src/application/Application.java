package application;

import gui.Main;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class Application {
	
	public static void main (String[] args){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				UIManager.put("OptionPane.yesButtonText", "Da");
				UIManager.put("OptionPane.noButtonText", "Ne");
				UIManager.put("OptionPane.cancelButtonText", "Otka�i");
					
				Main.getInstance().setVisible(true);
			}
		});
	}

}