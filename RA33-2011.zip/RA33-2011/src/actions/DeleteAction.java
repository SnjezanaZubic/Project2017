package actions;

import java.awt.event.ActionEvent;
import java.sql.SQLException;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTable;

import model.GenericTableModel;

public class DeleteAction extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private JDialog standardForm;
	private JTable tblGrid;

	public DeleteAction(JDialog standardForm, JTable grid) {
		putValue(SMALL_ICON,
				new ImageIcon(getClass().getResource("/img/remove.gif")));
		putValue(SHORT_DESCRIPTION, "Brisanje");
		this.standardForm = standardForm;
		tblGrid = grid;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		int index = tblGrid.getSelectedRow();
		if (index == -1)
			return;

		int reply = JOptionPane.showConfirmDialog(null,
				"Da li ste sigurni da želite da obrišete?", "Delete",
				JOptionPane.YES_NO_OPTION);
		if (reply == JOptionPane.YES_OPTION) {
			removeRow();
		} else {

		}

	}

	private void removeRow() {
		int index = tblGrid.getSelectedRow();
		// kada obrisemo tekuci red, selektovacemo sledeci (newindex):
		int newIndex = index;
		// sem ako se obrise poslednji red, tada selektujemo prethodni
		if (index == tblGrid.getModel().getRowCount() - 1)
			newIndex--;
		try {
			GenericTableModel gtm = (GenericTableModel) tblGrid.getModel();
			gtm.deleteRow(index);
			if (tblGrid.getModel().getRowCount() > 0)
				tblGrid.setRowSelectionInterval(newIndex, newIndex);
		} catch (SQLException ex) {
			// TODO: prevescemo error na srpski u trigeru u skripti za generisanje tabele
			JOptionPane.showMessageDialog(standardForm, ex.getMessage(),
					"Greska", JOptionPane.ERROR_MESSAGE);
		}
	}
}
