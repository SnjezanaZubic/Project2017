package actions;

import gui.dialogs.RacunStandardForm;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.KeyStroke;

public class RacunAction extends AbstractAction {
	public RacunAction() {
		putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(KeyEvent.VK_R,	ActionEvent.CTRL_MASK));
		putValue(MNEMONIC_KEY, KeyEvent.VK_R);
		putValue(SHORT_DESCRIPTION, "Pregled svih racuna");
		putValue(NAME, "Racuni");
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		RacunStandardForm form = new RacunStandardForm(null, false);
		form.setVisible(true);
	}
}
