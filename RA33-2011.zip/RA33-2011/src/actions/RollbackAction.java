package actions;

import gui.dialogs.GenericStandardForm;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JDialog;

public class RollbackAction extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private GenericStandardForm standardForm;

	public RollbackAction(JDialog standardForm) {
		putValue(SMALL_ICON,
				new ImageIcon(getClass().getResource("/img/remove.gif")));
		putValue(SHORT_DESCRIPTION, "Poništi");
		this.standardForm = (GenericStandardForm)standardForm;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (standardForm.getMode() == GenericStandardForm.MODE_SEARCH) {
			// TODO: fill tabele kada se pritisne rollback u search rezimu?
//			DrzaveTableModel dtm = (DrzaveTableModel) tblGrid.getModel();
//			dtm.findData("", "");
		}
		standardForm.switchMode(GenericStandardForm.MODE_EDIT);
		standardForm.sync();
	}
}
