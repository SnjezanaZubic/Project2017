package actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JTable;

public class LastAction extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private JDialog standardForm;
	private JTable tblGrid;

	public LastAction(JDialog standardForm, JTable grid) {
		putValue(SMALL_ICON, new ImageIcon(getClass().getResource("/img/last.gif")));
		putValue(SHORT_DESCRIPTION, "Poslednji");
		this.standardForm=standardForm;
		tblGrid=grid;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		goLast();
	}
	private void goLast() {
	    int rowCount = tblGrid.getModel().getRowCount(); 
	    if (rowCount > 0)
	      tblGrid.setRowSelectionInterval(rowCount - 1, rowCount - 1);
	  }
}
