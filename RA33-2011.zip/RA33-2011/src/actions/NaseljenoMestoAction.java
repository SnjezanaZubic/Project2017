package actions;

import gui.dialogs.GenericStandardForm;
import gui.dialogs.NaseljenoMestoStandardForm;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.KeyStroke;

public class NaseljenoMestoAction extends AbstractAction {
	private static final long serialVersionUID = 1L;

	private GenericStandardForm parentForm;
	private boolean isNext = false;

	public NaseljenoMestoAction() {
		KeyStroke keyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_N,
				ActionEvent.CTRL_MASK);
		putValue(ACCELERATOR_KEY, keyStroke);
		putValue(SHORT_DESCRIPTION, "Naseljena mesta");
		putValue(NAME, "Naseljena mesta");
	}

	public NaseljenoMestoAction(GenericStandardForm parentForm) {
		this.parentForm = parentForm;
		isNext = true;
		putValue(NAME, "Naseljena mesta");
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		NaseljenoMestoStandardForm form;
		if (isNext) {
			form = new NaseljenoMestoStandardForm(parentForm.getSifraColumns(),
					null, false);
		} else {
			form = new NaseljenoMestoStandardForm(null, null, false);
		}
		form.setVisible(true);

	}
}
