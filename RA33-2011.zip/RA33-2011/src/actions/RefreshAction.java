package actions;

import gui.dialogs.GenericStandardForm;

import java.awt.event.ActionEvent;
import java.sql.SQLException;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JTable;

import model.GenericTableModel;

public class RefreshAction extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private JTable tblGrid;
	private GenericStandardForm standardForm;

	public RefreshAction(JDialog standardForm, JTable grid) {
		putValue(SMALL_ICON,
				new ImageIcon(getClass().getResource("/img/refresh.gif")));
		putValue(SHORT_DESCRIPTION, "Refresh");
		tblGrid = grid;
		this.standardForm = (GenericStandardForm) standardForm;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		refresh();
	}

	private void refresh() {
		GenericTableModel dtm = (GenericTableModel) tblGrid.getModel();
		try {
			dtm.refresh();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		standardForm.switchMode(GenericStandardForm.MODE_EDIT);
	}
}
