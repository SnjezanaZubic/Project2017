package actions;

import gui.dialogs.GenericStandardForm;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JTable;

import util.Column;
import util.ColumnList;

public class PickupAction extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private GenericStandardForm standardForm;
	private ColumnList list;

	public PickupAction(JDialog standardForm, JTable grid, ColumnList lista) {
		putValue(SMALL_ICON,
				new ImageIcon(getClass().getResource("/img/zoom-pickup.gif")));
		putValue(SHORT_DESCRIPTION, "Zoom pickup");
		this.standardForm = (GenericStandardForm) standardForm;
		list = lista;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		list.clearList();

		Column[] columns = standardForm.getCurrentRow();
		for (int i = 0; i < columns.length; i++) {
			list.add(columns[i]);
		}

		standardForm.setVisible(false);
	}
}
