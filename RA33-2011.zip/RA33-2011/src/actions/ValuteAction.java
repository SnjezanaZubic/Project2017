package actions;

import gui.dialogs.GenericStandardForm;
import gui.dialogs.KursUValutiStandardForm;
import gui.dialogs.ValuteStandardForm;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.KeyStroke;

public class ValuteAction extends AbstractAction {

	private GenericStandardForm parentForm;
	private boolean isNext = false;
	
	public ValuteAction() {
		KeyStroke keyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_V,
				ActionEvent.CTRL_MASK);
		putValue(ACCELERATOR_KEY, keyStroke);
		putValue(SHORT_DESCRIPTION, "Valute");
		putValue(NAME, "Valute");
	}

	public ValuteAction(GenericStandardForm parentForm) {
		this.parentForm = parentForm;
		isNext = true;
		putValue(NAME, "Valute");
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		ValuteStandardForm form;
		if (isNext) {
			form = new ValuteStandardForm(parentForm.getSifraColumns(),
					null, false);
		} else {
			form = new ValuteStandardForm(null, null, false);
		}
		form.setVisible(true);
		
	}

}
