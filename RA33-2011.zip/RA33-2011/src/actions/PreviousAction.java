package actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JTable;

public class PreviousAction extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private JDialog standardForm;
	private JTable tblGrid;
	
	public PreviousAction(JDialog standardForm, JTable grid) {
		putValue(SMALL_ICON, new ImageIcon(getClass().getResource("/img/prev.gif")));
		putValue(SHORT_DESCRIPTION, "Prethodni");
		this.standardForm=standardForm;
		tblGrid=grid;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		goPrevious() ;
	}
	private void goPrevious() {
	    int selected = tblGrid.getSelectedRow();
	  //  System.out.println(rowCount);
	    if (0 < selected)
	    	selected--;
	    else selected = tblGrid.getModel().getRowCount()-1; 
	      tblGrid.setRowSelectionInterval(selected, selected);
	  }
}
