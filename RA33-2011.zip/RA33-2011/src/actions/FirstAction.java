package actions;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JTable;


public class FirstAction extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private JDialog standardForm;
	private JTable tblGrid;

	public FirstAction(JDialog standardForm, JTable grid) {
		putValue(SMALL_ICON, new ImageIcon(getClass().getResource("/img/first.gif")));
		putValue(SHORT_DESCRIPTION, "Pocetak");
		this.standardForm=standardForm;
		tblGrid = grid;
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		goFirst();
	}
	private void goFirst() {
	    int rowCount = tblGrid.getModel().getRowCount(); 
	    if (rowCount > 0)
	      tblGrid.setRowSelectionInterval(0, 0);
	  }
}
