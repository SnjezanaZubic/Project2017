package actions;

import gui.dialogs.GenericStandardForm;

import java.awt.event.ActionEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import model.GenericTableModel;
import util.ComboItem;
import de.wannawork.jcalendar.JCalendarComboBox;

public class CommitAction extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private GenericStandardForm standardForm;
	private Object[] objData;
	private Object[] data;
	private JTable tblGrid;

	public CommitAction(JDialog standardForm, Object[] objData, JTable grid) {
		putValue(SMALL_ICON,
				new ImageIcon(getClass().getResource("/img/commit.gif")));
		putValue(SHORT_DESCRIPTION, "Commit");
		this.standardForm = (GenericStandardForm) standardForm;
		this.objData = objData;
		data = new Object[objData.length];
		tblGrid = grid;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		fillDataArray();

		if (standardForm.getMode() == GenericStandardForm.MODE_ADD) {
			addRow();
		} else if (standardForm.getMode() == GenericStandardForm.MODE_SEARCH) {
			findRows();
		} else if (standardForm.getMode() == GenericStandardForm.MODE_EDIT) {
			updateRow();
		}
	}

	private void fillDataArray() {
			boolean value;
		for (int i = 0; i < objData.length; i++) {
			if (objData[i] instanceof JTextField) {
				data[i] = ((JTextField) objData[i]).getText().trim();
			} else if (objData[i] instanceof JCheckBox) {
				if(((JCheckBox) objData[i]).isSelected())
					data[i] = "1";
				else
					data[i] = "0";
			} else if (objData[i] instanceof JComboBox) {
				if (((JComboBox) objData[i]).getSelectedItem() instanceof ComboItem)
					 data[i] = ((ComboItem) ((JComboBox) objData[i]).getSelectedItem()).getValue();		
			} else if (objData[i] instanceof JCalendarComboBox) {
				Date datum = ((JCalendarComboBox) objData[i]).getDate();
				if(datum != null) {
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					String datumStr = sdf.format(datum);
					data[i] = datumStr;
				}
				else
					data[i]= "";
			}
			// TODO: Ako fali nesto
			else {
				System.out.println(data[i].getClass());
				System.out
						.println("Dodati instanceof za taj input objekat (ako treba) na liniji --> (CommitAction.java:76)");
			}
		}
	}

	private void findRows() {
		try {
			GenericTableModel gtm = (GenericTableModel) tblGrid.getModel();
			gtm.findData(data);
		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(standardForm, ex.getMessage(),
					"Greska", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void addRow() {
		String message = standardForm.validateInput();
		if (message != null) {
			JOptionPane.showMessageDialog(standardForm, message, "Greška",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		try {
			GenericTableModel gtm = (GenericTableModel) tblGrid.getModel();
			int index = gtm.insertRow(data);
			tblGrid.setRowSelectionInterval(index, index);
			// TODO: standardForm.switchMode(GenericStandardForm.MODE_EDIT);
			// TODO:
		} catch (SQLException ex) {
			if (ex.getMessage().startsWith("Violation of PRIMARY KEY")) {
				JOptionPane.showMessageDialog(standardForm,
						"Već postoji torka sa šifrom \'" + data[0] + "\'.",
						"Greška", JOptionPane.ERROR_MESSAGE);
			} else if (ex.getMessage().startsWith("Data truncation")) {
				JOptionPane
						.showMessageDialog(
								standardForm,
								"Ovaj error treba da se obradi u kodu da se zabrani da polja imaju veci broj karaktera od onog koji je zadat u bazi",
								"Greška", JOptionPane.ERROR_MESSAGE);
			} else {
				ex.printStackTrace();
			}
		}
	}

	private void updateRow() {
		if (tblGrid.getSelectedRow() < 0)
			return;
		String message = standardForm.validateInput();
		if (message != null) {
			JOptionPane.showMessageDialog(standardForm, message, "Greška",
					JOptionPane.ERROR_MESSAGE);
			return;
		}

		try {
			GenericTableModel gtm = (GenericTableModel) tblGrid.getModel();
			// TODO: trenutno sifra MORA da bude u prvoj koloni
			int index = gtm.updateRow(tblGrid.getSelectedRow(), data, gtm
					.getValueAt(tblGrid.getSelectedRow(), 0).toString());
			tblGrid.setRowSelectionInterval(index, index);

		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(standardForm, ex.getMessage(),
					"Greska", JOptionPane.ERROR_MESSAGE);
			System.out.println(ex.getMessage());
		}
	}
}
