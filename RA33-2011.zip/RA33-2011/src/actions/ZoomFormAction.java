package actions;

import gui.dialogs.DrzavaStandardForm;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;


public class ZoomFormAction extends AbstractAction {

	private static final long serialVersionUID = 1L;

	
	public ZoomFormAction() {
		putValue(SHORT_DESCRIPTION, "Zoom");
		putValue(NAME, "...");

	}

	@Override
	public void actionPerformed(ActionEvent event) {		
		DrzavaStandardForm form = new DrzavaStandardForm(null, true);
		form.setVisible(true);
	}
	
}
