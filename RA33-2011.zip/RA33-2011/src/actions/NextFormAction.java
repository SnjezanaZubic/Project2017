package actions;

import gui.dialogs.GenericStandardForm;

import java.awt.event.ActionEvent;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

public class NextFormAction extends AbstractAction {

	private static final long serialVersionUID = 1L;
	private GenericStandardForm standardForm;
	private JButton btnNextForm;
	private JPopupMenu nextPopupMenu = new JPopupMenu();

	public NextFormAction(JDialog standardForm) {
		putValue(SMALL_ICON,
				new ImageIcon(getClass().getResource("/img/nextform.gif")));
		putValue(SHORT_DESCRIPTION, "Sledeća forma");
		this.standardForm = (GenericStandardForm) standardForm;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (standardForm.getTable().getSelectedRow() < 0) {
			return;
		}
		if (nextPopupMenu.getComponentCount() == 0) {
			return;
		} else if (nextPopupMenu.getComponentCount() == 1) {
			((JMenuItem)nextPopupMenu.getComponent(0)).doClick();
		} else {
			nextPopupMenu.show(btnNextForm, 0, btnNextForm.getBounds().y
					+ btnNextForm.getBounds().height);
		}
	}

	public void addPopupItems(String[] nextForme) {
		this.btnNextForm = standardForm.getNextFormButton();
		for (int i = 0; i < nextForme.length; i++) {
			Class<?> c;
			try {
				c = Class.forName("actions." + nextForme[i]);
				Constructor<?> cons = c
						.getConstructor(GenericStandardForm.class);
				nextPopupMenu.add(new JMenuItem((AbstractAction) cons
						.newInstance(standardForm)));
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			} catch (SecurityException e) {
				e.printStackTrace();
			}
		}
	}
}
