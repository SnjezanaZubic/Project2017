package actions;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.KeyStroke;

import gui.dialogs.BankaStandardForm;
import gui.dialogs.GenericStandardForm;

public class BankaAction extends AbstractAction {

	private GenericStandardForm parentForm;
	private boolean isNext = false;
	
	public BankaAction() {
		KeyStroke ctrlDKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_B, ActionEvent.CTRL_MASK);
		putValue(ACCELERATOR_KEY,ctrlDKeyStroke);
		putValue(SHORT_DESCRIPTION, "Banka");
		putValue(NAME, "Banka");
	}
	
	public BankaAction(GenericStandardForm parentForm) {
		this.parentForm = parentForm;
		isNext = true;
		putValue(NAME, "Banka");
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		BankaStandardForm form;
		if (isNext) {
			form = new BankaStandardForm(parentForm.getSifraColumns(), null, false);
		} else {
			form = new BankaStandardForm(null, null, false);
		}
		form.setVisible(true);
	}

}
