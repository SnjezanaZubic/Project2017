package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.Column;
import util.SortUtils;
import db.DBConnection;

public class NaseljenoMestoTableModel extends GenericTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String basicQuery = "SELECT ptt_broj, naziv, mesto.dr_sifra, dr_naziv FROM mesto JOIN drzava on mesto.dr_sifra = drzava.dr_sifra";
	private String orderBy = " ORDER BY ptt_broj";
	private String whereStmt = "";

	public NaseljenoMestoTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}

	// Otvaranje upita
	public void open(Column[] sifraColumns) throws SQLException {
		// fillData(basicQuery + orderBy + whereStmt);
		if (sifraColumns == null)
			fillData("SELECT ptt_broj, naziv, mesto.dr_sifra, dr_naziv FROM mesto JOIN drzava ON mesto.dr_sifra = drzava.dr_sifra ORDER BY ptt_broj");
		else {
			fillData(basicQuery + " WHERE mesto." + sifraColumns[0].getName() + " = '" + sifraColumns[0].getValue() + "' "  + orderBy);
		}
	}

	private void fillData(String sql) throws SQLException {
		setRowCount(0);
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		while (rset.next()) {
			String sifra = rset.getString("PTT_BROJ");
			String naziv = rset.getString("NAZIV");
			String sifraDrzave = rset.getString("DR_SIFRA");
			String nazivDrzave = rset.getString("DR_NAZIV");
			addRow(new String[] { sifra, naziv, sifraDrzave, nazivDrzave });
		}
		rset.close();
		stmt.close();
		fireTableDataChanged();
	}

	protected void checkRow(int index) throws SQLException {

		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection()
				.prepareStatement(basicQuery + " where PTT_BROJ = ?");

		String sifra = (String) getValueAt(index, 0);
		selectStmt.setString(1, sifra);

		ResultSet rset = selectStmt.executeQuery();

		String sifraNm = "", nazivNm = "", sifraDr = "";
		Boolean postoji = false;
		String errorMsg = "";
		while (rset.next()) {
			sifraNm = rset.getString("ptt_broj").trim();
			nazivNm = rset.getString("naziv").trim();
			sifraDr = rset.getString("dr_sifra").trim();
			postoji = true;
		}
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(sifraNm,
				((String) getValueAt(index, 0)).trim()) != 0)
				|| (SortUtils.getLatCyrCollator().compare(nazivNm,
						(String) getValueAt(index, 1)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(sifraDr,
						(String) getValueAt(index, 2)) != 0)) {
			setValueAt(sifraNm, index, 0);
			setValueAt(nazivNm, index, 1);
			setValueAt(sifraDr, index, 2);
			fireTableDataChanged();
		}
		rset.close();
		selectStmt.close();
		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_READ_COMMITTED);
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
	}

	@Override
	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		String pttBroj = (String)data[0];
		String naziv = (String)data[1];
		String dr_sifra = (String)data[2];
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"INSERT INTO mesto (ptt_broj, naziv, dr_sifra) VALUES (?, ?, ?)");
		stmt.setString(1, pttBroj);
		stmt.setString(2, naziv);
		stmt.setString(3, dr_sifra);
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i unos u TableModel
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void findData(Object[] data) throws SQLException {
		setRowCount(0);
		String ptt = (String)data[0];
		String naziv = (String)data[1];
		String sifraDr = (String)data[2];
		String nazivDr = (String)data[3];
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(basicQuery
						+ " WHERE ptt_broj LIKE ? AND naziv LIKE ? AND mesto.dr_sifra LIKE ? AND dr_naziv LIKE ? "
						+ orderBy);

		stmt.setString(1, "%" + ptt + "%");
		stmt.setString(2, "%" + naziv + "%");
		stmt.setString(3, "%" + sifraDr + "%");
		stmt.setString(4, "%" + nazivDr + "%");
		ResultSet rowsAffected = stmt.executeQuery();
		while (rowsAffected.next()) {
			ptt = rowsAffected.getString("PTT_BROJ");
			naziv = rowsAffected.getString("NAZIV");
			sifraDr = rowsAffected.getString("DR_SIFRA");
			nazivDr = rowsAffected.getString("DR_NAZIV");
			addRow(new String[] { ptt, naziv, sifraDr, nazivDr });
		}
		stmt.close();
	}

	@Override
	public int updateRow(int index, Object[] data, String stariPtt)
			throws SQLException {
		checkRow(index); // Provera i zakljucavanje tekuceg sloga pre izmene
		String pttBroj = (String)data[0];
		String naziv = (String)data[1];
		String sifraDr = (String)data[2];
		int retVal = 0;
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"UPDATE mesto SET ptt_broj = ?, naziv = ?, dr_sifra = ? WHERE ptt_broj = ?");
		stmt.setString(1, pttBroj);
		stmt.setString(2, naziv);
		stmt.setString(3, sifraDr);
		stmt.setString(4, stariPtt);

		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// TableModel update
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] { "", "", "", "" });
	}

	@Override
	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"DELETE FROM mesto WHERE ptt_broj = ?");
		String sifra = (String) getValueAt(index, 0);
		stmt.setString(1, sifra);
		// Brisanje iz baze
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i brisanje iz TableModel-a
			removeRow(index);
			fireTableDataChanged();
		}
	}

}
