package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.Column;
import util.SortUtils;
import db.DBConnection;

public class RacunTableModel extends GenericTableModel {

	private String basicQuery = "SELECT broj_racuna, sifra_klijenta, sifra_banke, va_sifra, zatvoren, datum_otvaranja FROM racun";
	private String orderBy = " ORDER BY broj_racuna";

	public RacunTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}

	public void open(Column[] sifraColumns) throws SQLException {
		fillData(basicQuery + orderBy);
	}

	public void fillData(String sql) throws SQLException {
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		setRowCount(0);
		
		while (rset.next()) {
			addRow(new String[] {
				rset.getString("broj_racuna"),
				rset.getString("sifra_klijenta"),
				rset.getString("sifra_banke"),
				rset.getString("va_sifra"),
				rset.getString("zatvoren"),
				rset.getString("datum_otvaranja")
			});
		}
		
		rset.close();
		stmt.close();
		fireTableDataChanged();
	}

	public void findData(Object[] data) throws SQLException {
		String brojRacuna = (String)data[0];
		String sifraKlijenta = (String)data[1];
		String sifraBanke = (String)data[2];
		String vaSifra = (String)data[3];
		Boolean zatvoren = (Boolean)data[4];
		String datumOtvaranja = (String)data[5];
		
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			basicQuery
			+ " WHERE broj_racuna LIKE ? AND sifra_klijenta LIKE ? AND sifra_banke LIKE ?"
			+ " AND va_sifra LIKE ? AND zatvoren = ? AND datum_otvaranja LIKE ?"
		);

		stmt.setString(1, "%" + brojRacuna + "%");
		stmt.setString(2, "%" + sifraKlijenta + "%");
		stmt.setString(3, "%" + sifraBanke + "%");
		stmt.setString(4, "%" + vaSifra + "%");
		stmt.setBoolean(5, zatvoren);
		stmt.setString(6, "%" + datumOtvaranja + "%");
		
		ResultSet rowsAffected = stmt.executeQuery();
		setRowCount(0);
		
		while (rowsAffected.next()) {
			addRow(new String[] {
				rowsAffected.getString("broj_racuna"),
				rowsAffected.getString("sifra_klijenta"),
				rowsAffected.getString("sifra_banke"),
				rowsAffected.getString("va_sifra"),
				rowsAffected.getString("zatvoren"),
				rowsAffected.getString("datum_otvaranja")
			});
		}
		
		stmt.close();
	}

	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		String brojRacuna = (String)data[0];
		String sifraKlijenta = (String)data[1];
		String sifraBanke = (String)data[2];
		String vaSifra = (String)data[3];
		Boolean zatvoren = (Boolean)data[4];
		String datumOtvaranja = (String)data[5];
		
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"INSERT INTO racun"
			+ " (broj_racuna, sifra_klijenta, sifra_banke, va_sifra, zatvoren, datum_otvaranja)"
			+ " VALUES (?, ?, ?, ?, ?, ?)"
		);
		
		stmt.setString(1, brojRacuna);
		stmt.setString(2, sifraKlijenta);
		stmt.setString(3, sifraBanke);
		stmt.setString(4, vaSifra);
		stmt.setBoolean(5, zatvoren);
		stmt.setString(6, datumOtvaranja);
		
		int rowsAffected = stmt.executeUpdate();
		stmt.close();

		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		
		return retVal;
	}

	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"DELETE FROM racun WHERE broj_racuna = ?"
		);
		
		stmt.setString(1, (String)getValueAt(index, 0));
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			removeRow(index);
			fireTableDataChanged();
		}
	}

	protected void checkRow(int index) throws SQLException {
		DBConnection.getConnection().setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection().prepareStatement(
			basicQuery + " WHERE broj_racuna = ?"
		);

		String sifra = (String) getValueAt(index, 0);
		selectStmt.setString(1, sifra);

		ResultSet rset = selectStmt.executeQuery();

		String brojRacuna = "", sifraKlijenta = "", sifraBanke = "", vaSifra = "", datumOtvaranja = "";
		boolean zatvoren = false;
		boolean postoji = false;
		String errorMsg = "";
		
		while (rset.next()) {
			brojRacuna = rset.getString("broj_racuna").trim();
			sifraKlijenta = rset.getString("sifra_klijenta").trim();
			sifraBanke = rset.getString("sifra_banke").trim();
			vaSifra = rset.getString("va_sifra").trim();
			zatvoren = rset.getBoolean("zatvoren");
			datumOtvaranja = rset.getString("datum_otvaranja").trim();
			postoji = true;
		}
		
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(brojRacuna, ((String)getValueAt(index, 0)).trim()) != 0)
				   || (SortUtils.getLatCyrCollator().compare(sifraKlijenta, (String)getValueAt(index, 1)) != 0)
				   || (SortUtils.getLatCyrCollator().compare(sifraBanke, (String)getValueAt(index, 2)) != 0)
				   || (SortUtils.getLatCyrCollator().compare(vaSifra, ((String)getValueAt(index, 3)).trim()) != 0)
				   || (zatvoren != (Boolean)getValueAt(index, 4))
				   || (SortUtils.getLatCyrCollator().compare(datumOtvaranja, (String)getValueAt(index, 5)) != 0)) {
			setValueAt(brojRacuna, index, 0);
			setValueAt(sifraKlijenta, index, 1);
			setValueAt(sifraBanke, index, 2);
			setValueAt(vaSifra, index, 3);
			setValueAt(zatvoren, index, 4);
			setValueAt(datumOtvaranja, index, 5);
			fireTableDataChanged();
		}
		
		rset.close();
		selectStmt.close();
		
		DBConnection.getConnection().setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
		
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
	}

	public int updateRow(int index, Object[] data, String stariBrojRacuna) throws SQLException {
		checkRow(index);
		String brojRacuna = (String)data[0];
		String sifraKlijenta = (String)data[1];
		String sifraBanke = (String)data[2];
		String vaSifra = (String)data[3];
		Boolean zatvoren = (Boolean)data[4];
		String datumOtvaranja = (String)data[5];
		
		int retVal = 0;
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"UPDATE racun SET broj_racuna = ?, sifra_klijenta = ?, sifra_banke = ?"
			+ " va_sifra = ? zatvoren = ? datum_otvaranja = ? WHERE broj_racuna = ?"
		);
		
		stmt.setString(1, brojRacuna);
		stmt.setString(2, sifraKlijenta);
		stmt.setString(3, sifraBanke);
		stmt.setString(4, vaSifra);
		stmt.setBoolean(5, zatvoren);
		stmt.setString(6, datumOtvaranja);
		stmt.setString(7, stariBrojRacuna);
		
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] { "", "", "", "", "", "" });
	}
}
