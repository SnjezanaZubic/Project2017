package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import db.DBConnection;

import util.Column;
import util.SortUtils;

public class ValuteTableModel extends GenericTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String basicQuery = "SELECT VALUTE.VA_SIFRA, VALUTE.DR_SIFRA, VALUTE.VA_NAZIV, VALUTE.VA_DOMICILNA FROM VALUTE";
	private String orderBy = "ORDER BY VALUTE.VA_SIFRA";
	private String whereStmt = "";

	public ValuteTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}
	
	public void fillData(String sql) throws SQLException {
		setRowCount(0);
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		while (rset.next()) {
			addRow(new String[]{
			rset.getString("VA_SIFRA"),
			rset.getString("DR_SIFRA"),
			rset.getString("VA_NAZIV"),	
			rset.getString("VA_DOMICILNA")
			});
		}
		rset.close();
		stmt.close();
		fireTableDataChanged();
	}
	
	@Override
	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		String sifra = (String)data[0];
		String drzava = (String)data[1];
		String naziv = (String)data[2];
		String domicilna = String.valueOf(data[3]);
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"INSERT INTO VALUTE (VA_SIFRA, DR_SIFRA, VA_NAZIV, VA_DOMICILNA) VALUES (?, ?, ?, ?)");
		stmt.setString(1, sifra);
		stmt.setString(2, drzava);
		stmt.setString(3, naziv);
		System.out.println("akcija32");
		stmt.setObject(4, domicilna);
		System.out.println("akcija3");
		int rowsAffected = stmt.executeUpdate();
		System.out.println("akcija4");
		stmt.close();
		System.out.println("akcija5");
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		System.out.println("akcija6");
		if (rowsAffected > 0) {
			System.out.println("akcija7");
			// i unos u TableModel
			retVal = sortedInsert(data);
			System.out.println("akcija8");
			fireTableDataChanged();
			System.out.println("akcija9");
		}
		System.out.println("akcija10");
		return retVal;
	}

	@Override
	public void findData(Object[] data) throws SQLException {
		setRowCount(0);
		String sifra = (String)data[0];
		String drzava = (String)data[1];
		String naziv = (String)data[2];
		String domicilna = (String)data[3];
		String statement =	"SELECT VALUTE.VA_SIFRA, VALUTE.DR_SIFRA, VALUTE.VA_NAZIV, VALUTE.VA_DOMICILNA FROM VALUTE WHERE VA_SIFRA LIKE ? AND DR_SIFRA LIKE ? AND VA_NAZIV LIKE ? AND VA_DOMICILNA LIKE ? ORDER BY VALUTE.VA_SIFRA";
		
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(statement);
		System.out.println(stmt);
	
		stmt.setString(1, "%" + sifra + "%");
		stmt.setString(2, "%" + drzava + "%");
		stmt.setString(3, "%" + naziv + "%");
		stmt.setString(4, "%" + domicilna + "%");
		
		System.out.println(statement);
			

		ResultSet rowsAffected = stmt.executeQuery();
		System.out.println("izvrsen upit");
		while (rowsAffected.next()) {
			System.out.println("u while petlji");
			sifra = rowsAffected.getString("VA_SIFRA");
			drzava = rowsAffected.getString("DR_SIFRA");
			naziv = rowsAffected.getString("VA_NAZIV");
			domicilna = rowsAffected.getString("VA_DOMICILNA");
			addRow(new String[] { sifra, drzava, naziv});
		}
		stmt.close();
		
	}

	@Override
	public int updateRow(int index, Object[] data, String staraSifra)
			throws SQLException {
		checkRow(index);

		String sifra = (String)data[0];
		String drzava = (String)data[1];
		String naziv = (String)data[2];
		String domicilna = (String)data[3];
		
		int retVal = 0;
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"UPDATE valute SET VA_SIFRA = ?,  DR_SIFRA = ?,  VA_NAZIV = ?,  VA_DOMICILNA = ? WHERE VA_SIFRA = ?");
		stmt.setString(1, sifra);
		stmt.setString(2, drzava);
		stmt.setString(3, naziv);
		stmt.setString(4, domicilna);
		stmt.setString(5, staraSifra);

		int rowsAffected = stmt.executeUpdate();
		
		stmt.close();
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// TableModel update
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] {"", "", "", ""});
		
	}

	@Override
	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"DELETE FROM VALUTE WHERE VA_SIFRA = ?");
		String sifra = (String) getValueAt(index, 2);
		stmt.setString(1, sifra);
		// Brisanje iz baze
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i brisanje iz TableModel-a
			removeRow(index);
			fireTableDataChanged();
		}
		
	}

	@Override
	public void open(Column[] sifraColumns) throws SQLException {
		if (sifraColumns == null)
			fillData("SELECT VALUTE.VA_SIFRA, VALUTE.DR_SIFRA, VALUTE.VA_NAZIV, VALUTE.VA_DOMICILNA FROM VALUTE ORDER BY VA_SIFRA");
		else if (sifraColumns.length == 1)
			fillData("SELECT VALUTE.VA_SIFRA, VALUTE.DR_SIFRA, VALUTE.VA_NAZIV, VALUTE.VA_DOMICILNA FROM VALUTE"
					+ " WHERE " + sifraColumns[0].getName() + " = " + sifraColumns[0].getValue() 
					+ "  ORDER BY VA_SIFRA");
		else
			System.out.println("Ima vise od jedne kolone");
		
	}

	@Override
	protected void checkRow(int index) throws SQLException {
		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection()
				.prepareStatement(
						"SELECT VALUTE.VA_SIFRA, VALUTE.DR_SIFRA, VALUTE.VA_NAZIV, VALUTE.VA_DOMICILNA FROM VALUTE WHERE valute.VA_SIFRA = ?");

		String sifra = (String) getValueAt(index, 2);
		selectStmt.setString(1, sifra);

		ResultSet rset = selectStmt.executeQuery();
		String sifraVa = "", drzava = "", naziv = "";
		String domicilna = "";
		Boolean postoji = false;
		String errorMsg = "";
		
		while (rset.next()) {
			sifraVa = rset.getString("VA_SIFRA");
			drzava = rset.getString("DR_SIFRA");
			naziv = rset.getString("VA_NAZIV");
			domicilna = rset.getString("VA_DOMICILNA");
			postoji = true;
		}
		
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(sifraVa,
				((String) getValueAt(index, 0)).trim()) != 0)
				|| (SortUtils.getLatCyrCollator().compare(drzava,
						(String) getValueAt(index, 1)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(naziv,
						(String) getValueAt(index, 2)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(domicilna,
						(String) getValueAt(index, 3)) != 0)
						) {
			setValueAt(sifraVa, index, 0);
			setValueAt(drzava, index, 1);
			setValueAt(naziv, index, 2);
			setValueAt(domicilna, index, 3);
			fireTableDataChanged();
		}
		rset.close();
		selectStmt.close();
		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_READ_COMMITTED);
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
	}
		

}
