package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.Column;
import util.SortUtils;
import db.DBConnection;

public class BankaTableModel extends GenericTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String basicQuery = "SELECT SIFRA_BANKE, NAZIV_BANKE, ADRESA, TELEFON FROM BANKA";
	private String orderBy = "ORDER BY SIFRA_BANKE";
	private String whereStmt = "";

	public BankaTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}
	
	//Otvaranje upita
	
	public void open(Column[] sifraColumns) throws SQLException {
		fillData("SELECT SIFRA_BANKE, NAZIV_BANKE, ADRESA, TELEFON FROM BANKA ORDER BY SIFRA_BANKE");	
	}
	
	//Popunjavanje tabele podacima

	private void fillData(String sql) throws SQLException {
		setRowCount(0);
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		
		while(rset.next()) {
			
			String sifra = rset.getString("SIFRA_BANKE");
			String naziv = rset.getString("NAZIV_BANKE");
			String adresa = rset.getString("ADRESA");
			String telefon = rset.getString("TELEFON");
			addRow(new String[] {sifra, naziv, adresa, telefon});
		}
		
		rset.close();
		stmt.close();
		fireTableDataChanged();
	}

	@Override
	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		 String sifra = (String) data[0];
		 String naziv = (String) data[1];
		 String adresa = (String) data[2];
		 String telefon = (String) data[3];
		 PreparedStatement stmt = DBConnection.
				 getConnection().
				 prepareStatement("INSERT INTO banka (sifra_banke, naziv_banke, adresa, telefon) VALUES (?, ?, ?, ?)");
		 stmt.setString(1, sifra);
		 stmt.setString(2, naziv);
		 stmt.setString(3, adresa);
		 stmt.setString(4, telefon);
		 int rowsAffected = stmt.executeUpdate();
		 stmt.close();
		 //unos sloga u bazu
		 DBConnection.getConnection().commit();
		 if(rowsAffected > 0) {
			//unos u TableModel
			 retVal = sortedInsert(data);
			 fireTableDataChanged();
		 }
		 
		return retVal;
	}

	@Override
	public void findData(Object[] data) throws SQLException {
		setRowCount(0);
		String sifra = (String) data[0];
		String naziv = (String) data[1];
		String adresa = (String) data[2];
		String telefon = (String) data[3];
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement("SELECT SIFRA_BANKE, NAZIV_BANKE, ADRESA, TELEFON FROM BANKA WHERE sifra_banke LIKE ? AND naziv_banke LIKE ? AND adresa LIKE ? AND telefon LIKE ? ORDER BY SIFRA_BANKE");
		stmt.setString(1, "%" + sifra + "%");
		stmt.setString(2, "%" + naziv + "%");
		stmt.setString(3, "%" + adresa + "%");
		stmt.setString(4, "%" + telefon +"%");
		
		ResultSet rowsAffected = stmt.executeQuery();
		while(rowsAffected.next()) {
			sifra = rowsAffected.getString("SIFRA_BANKE");
			naziv = rowsAffected.getString("NAZIV_BANKE");
			adresa = rowsAffected.getString("ADRESA");
			telefon = rowsAffected.getString("TELEFON");
			addRow(new String[] {sifra, naziv, adresa, telefon});
			}
		stmt.close();
	}

	@Override
	public int updateRow(int index, Object[] data, String staraSifra)
			throws SQLException {
		checkRow(index); //proverava i zakljucava tekuci slog pre izmene
		String sifra = (String) data[0];
		String naziv = (String) data[1];
		String adresa = (String) data[2];
		String telefon = (String) data[3];
		int retVal = 0;
		PreparedStatement stmt = DBConnection.
				getConnection().
				prepareStatement("UPDATE banka SET sifra_banke = ?, naziv_banke = ?, adresa = ?, telefon = ? WHERE sifra_banke = ?");
		stmt.setString(1, sifra);
		stmt.setString(2, naziv);
		stmt.setString(3, adresa);
		stmt.setString(4, telefon);
		stmt.setString(5, staraSifra);
		
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		//unos sloga u bazu
		DBConnection.getConnection().commit();
		if(rowsAffected > 0) {
			//TableModel update
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] {"", "", "", ""});
		
	}

	@Override
	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.
				getConnection().
				prepareStatement("DELETE FROM banka WHERE sifra_banke = ?");
		String sifra = (String) getValueAt(index, 0);
		stmt.setString(1, sifra);
		//brisanje iz baze
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		DBConnection.getConnection().commit();
		if(rowsAffected > 0) {
			//brisanje iz TableModel-a
			removeRow(index);
			fireTableDataChanged();
		}
		
	}

	
	@Override
	protected void checkRow(int index) throws SQLException {
		DBConnection.getConnection().setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.
				getConnection().
				prepareStatement("SELECT SIFRA_BANKE, NAZIV_BANKE, ADRESA, TELEFON FROM BANKA WHERE SIFRA_BANKE = ?");
		String sifra = (String) getValueAt(index, 0);
		selectStmt.setString(1, sifra);
		
		ResultSet rset = selectStmt.executeQuery();
		String sifraB = "", naziv = "", adresa = "", telefon = "";
		Boolean postoji = false;
		String errMsg = "";
		while(rset.next()) {
			sifraB = rset.getString("SIFRA_BANKE").trim();
			naziv = rset.getString("NAZIV_BANKE").trim();
			adresa = rset.getString("ADRESA").trim();
			telefon = rset.getString("TELEFON").trim();
			postoji = true;
		}
		
		if(!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(sifraB,
				((String) getValueAt(index, 0)).trim()) != 0)
				|| (SortUtils.getLatCyrCollator().compare(naziv,
						(String) getValueAt(index, 1)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(adresa,
						(String) getValueAt(index, 2)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(telefon,
						(String) getValueAt(index, 3)) != 0)) {
			setValueAt(sifraB, index, 0);
			setValueAt(naziv, index, 1);
			setValueAt(adresa, index, 2);
			setValueAt(telefon, index, 3);
			fireTableDataChanged();
		}
		rset.close();
		selectStmt.close();
		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_READ_COMMITTED);
		if (errMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errMsg, "");
		}
	}

}
