package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import util.Column;
import util.SortUtils;
import db.DBConnection;

public class PresekIzvodaTableModel extends GenericTableModel {

	/**
 * 
 */
	private static final long serialVersionUID = 1L;
	//private String basicQuery = "SELECT ptt_broj, naziv, mesto.dr_sifra, dr_naziv FROM mesto JOIN drzava on mesto.dr_sifra = drzava.dr_sifra";
	private String basicQuery = "SELECT broj_racuna, "
									+ "sifra_klijenta, "
									+ "bnp_datum, "
									+ "bnp_presek, "
									+ "dne_broj_racuna, "
									+ "datum, "
									+ "bnp_brukorist , "
									+ "bnp_u_korist, " 
									+ "bnp_brnateret, "
									+ "bnp_ukteret, "
									+ "bnp_brpogk, "
									+ "bnp_brpogt, "
									+ "bnp_status "
								+ "FROM presek_izvoda";
	
	private String orderBy = " ORDER BY bnp_presek";
	private String whereStmt = "";

	public PresekIzvodaTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}

	// Otvaranje upita
	public void open(Column[] sifraColumns) throws SQLException {
		// fillData(basicQuery + orderBy + whereStmt);
		if (sifraColumns == null)
			//fillData("SELECT ptt_broj, naziv, mesto.dr_sifra, dr_naziv FROM mesto JOIN drzava ON mesto.dr_sifra = drzava.dr_sifra ORDER BY ptt_broj");
			fillData("SELECT broj_racuna, "
						+ "sifra_klijenta, "
						+ "bnp_datum, "
						+ "bnp_presek, "
						+ "dne_broj_racuna, "
						+ "datum, "
						+ "bnp_brukorist, "
						+ "bnp_u_korist, "
						+ "bnp_brnateret, "
						+ "bnp_ukteret, "
						+ "bnp_brpogk, "
						+ "bnp_brpogt, "
						+ "bnp_status "
					+ "FROM presek_izvoda");
		else {
			fillData(basicQuery + " WHERE " + sifraColumns[0].getName()
					+ " = '" + sifraColumns[0].getValue() + "' " + orderBy);
		}
	}

	private void fillData(String sql) throws SQLException {
		setRowCount(0);
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		while (rset.next()) {
			String brojRacuna = rset.getString("BROJ_RACUNA");
			String sifraKlijenta = rset.getString("SIFRA_KLIJENTA");
			String datumNaloga = rset.getString("BNP_DATUM");
			String brojPreseka = rset.getString("BNP_PRESEK");
			String dneBrojRacuna = rset.getString("DNE_BROJ_RACUNA");
			String datum = rset.getString("DATUM");
			String bnp_brukorist = rset.getString("BNP_BRUKORIST");
			String bnp_u_korist = rset.getString("BNP_U_KORIST");
			String bnp_brnateret = rset.getString("BNP_BRNATERET");
			String bnp_ukteret = rset.getString("BNP_UKTERET");
			String bnp_brpogk = rset.getString("BNP_BRPOGK");
			String bnp_pogt = rset.getString("BNP_BRPOGT");
			String bnp_status = rset.getString("BNP_STATUS");
			
			addRow(new String[] { 	brojRacuna, 
									sifraKlijenta, 
									datumNaloga, 
									brojPreseka, 
									dneBrojRacuna, 
									datum, 
									bnp_brukorist, 
									bnp_u_korist,
									bnp_brnateret, 
									bnp_ukteret, 
									bnp_brpogk,
									bnp_pogt, 
									bnp_status
								});
		}
		rset.close();
		stmt.close();
		fireTableDataChanged();
	}

	protected void checkRow(int index) throws SQLException {

		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection()
				.prepareStatement(basicQuery + " where BNP_PRESEK = ?");

		String sifra = (String) getValueAt(index, 3);
		selectStmt.setString(1, sifra);

		ResultSet rset = selectStmt.executeQuery();

		String broj_racuna = "", sifra_klijenta = "", bnp_datum = "", bnp_presek = "";
		String dne_broj_racuna = "", datum = "", bnp_brukorist = "", bnp_u_korist = "";
		String bnp_brnateret = "", bnp_ukteret = "", bnp_brpogk = "", bnp_brpogt = "", bnp_status = "";
		
		Boolean postoji = false;
		String errorMsg = "";
		while (rset.next()) {
			broj_racuna = rset.getString("broj_racuna").trim();
			sifra_klijenta = rset.getString("sifra_klijenta").trim();
			bnp_datum = rset.getString("bnp_datum").trim();
			bnp_presek = rset.getString("bnp_presek").trim();
			dne_broj_racuna = rset.getString("dne_broj_racuna").trim();
			datum = rset.getString("datum").trim();
			bnp_brukorist = rset.getString("bnp_brukorist").trim();
			bnp_u_korist = rset.getString("bnp_u_korist").trim();
			bnp_brnateret = rset.getString("bnp_brnateret").trim();
			bnp_ukteret = rset.getString("bnp_ukteret").trim();
			bnp_brpogk = rset.getString("bnp_brpogk").trim();
			bnp_brpogt = rset.getString("bnp_brpogt").trim();
			bnp_status = rset.getString("bnp_status").trim();
			postoji = true;
		}
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(broj_racuna,
				((String) getValueAt(index, 2)).trim()) != 0)
				|| (SortUtils.getLatCyrCollator().compare(sifra_klijenta,
						(String) getValueAt(index, 3)) != 0)) {
			setValueAt(broj_racuna, index, 0);
			setValueAt(sifra_klijenta, index, 1);
			setValueAt(bnp_datum, index, 2);
			setValueAt(bnp_presek, index, 3);
			setValueAt(dne_broj_racuna, index, 4);
			setValueAt(datum, index, 5);
			setValueAt(bnp_brukorist, index, 6);
			setValueAt(bnp_u_korist, index, 7);
			setValueAt(bnp_brnateret, index, 8);
			setValueAt(bnp_ukteret, index, 9);
			setValueAt(bnp_brpogk, index, 10);
			setValueAt(bnp_brpogt, index, 11);
			setValueAt(bnp_status, index, 12);
			
			fireTableDataChanged();
		}
		rset.close();
		selectStmt.close();
		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_READ_COMMITTED);
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
	}

	//ne treba dodavanje novog izvoda vec generisanje na osnovu unetih podataka
	@Override
	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;

		String broj_racuna = (String) data[0];
		String sifra_klijenta = (String) data[1];
		String bnp_datum = (String) data[2];
		String bnp_presek = (String) data[3];
		String dne_broj_racuna = (String) data[4];
		String datum = (String) data[5];
		String bnp_brukorist = (String) data[6];
		String bnp_u_korist = (String) data[7];
		String bnp_brnateret = (String) data[8];
		String bnp_ukteret = (String) data[9];
		String bnp_brpogk = (String) data[10];
		String bnp_brpogt = (String) data[11];
		String bnp_status = (String) data[12];
		
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"INSERT INTO presek_izvoda (broj_racuna, sifra_klijenta, bnp_datum, bnp_presek, "
				+ "dne_broj_racuna, datum, bnp_brukorist, bnp_u_korist, bnp_brnateret, bnp_ukteret, "
				+ "bnp_brpogk, bnp_brpogt, bnp_status) VALUES (? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,?)");
		stmt.setString(1, broj_racuna);
		System.out.println(broj_racuna);
		stmt.setString(2, sifra_klijenta);
		System.out.println(sifra_klijenta);
		stmt.setString(3, bnp_datum);
		System.out.println(bnp_datum);
		stmt.setString(4, bnp_presek);
		System.out.println(bnp_presek);
		stmt.setString(5, dne_broj_racuna);
		System.out.println(dne_broj_racuna);
		stmt.setString(6, datum );
		System.out.println(datum);
		stmt.setString(7, bnp_brukorist);
		stmt.setString(8, bnp_u_korist);
		stmt.setString(9, bnp_brnateret);
		stmt.setString(10, bnp_ukteret);
		stmt.setString(11, bnp_brpogk);
		stmt.setString(12, bnp_brpogt);
		stmt.setString(13, bnp_status);
		
		int rowsAffected = 0;
		try {
			rowsAffected = stmt.executeUpdate();
			refresh();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Ne postoji racun za koji trazite izvod", "Poruka", JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
		}
		stmt.close();
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i unos u TableModel
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void findData(Object[] data) throws SQLException {

 		setRowCount(0);
		String broj_racuna = (String) data[0];
		String sifra_klijenta = (String) data[1];
		String bnp_datum = (String) data[2];
		String bnp_presek = (String) data[3];
		String dne_broj_racuna = (String) data[4];
		String datum = (String) data[5];
		String bnp_brukorist = (String) data[6];
		String bnp_u_korist = (String) data[7];
		String bnp_brnateret = (String) data[8];
		String bnp_ukteret = (String) data[9];
		String bnp_brpogk = (String) data[10];
		String bnp_brpogt = (String) data[11];
		String bnp_status = (String) data[12];
		
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						basicQuery
						+ " WHERE BROJ_RACUNA LIKE ? AND SIFRA_KLIJENTA LIKE ? "
								+ " AND BNP_DATUM LIKE ? AND BNP_PRESEK LIKE ? "
								+ " AND DNE_BROJ_RACUNA LIKE ? AND DATUM LIKE ? "
								+ " AND BNP_BRUKORIST LIKE ? AND BNP_U_KORIST LIKE ? "
								+ " AND BNP_BRNATERET LIKE ? AND BNP_UKTERET LIKE ? "
								+ " AND BNP_BRPOGK LIKE ? AND BNP_BRPOGT LIKE ? "
								+ " AND BNP_STATUS LIKE ? "
								+ orderBy);

		stmt.setString(1, "%" + broj_racuna + "%");
		stmt.setString(2, "%" + sifra_klijenta + "%");
		stmt.setString(3, "%" + bnp_datum + "%");
		stmt.setString(4, "%" + bnp_presek + "%");
		stmt.setString(5, "%" + dne_broj_racuna + "%");
		stmt.setString(6, "%" + datum + "%");
		stmt.setString(7, "%" + bnp_brukorist + "%");
		stmt.setString(8, "%" + bnp_u_korist + "%");
		stmt.setString(9, "%" + bnp_brnateret + "%");
		stmt.setString(10, "%" + bnp_ukteret + "%");
		stmt.setString(11, "%" + bnp_brpogk + "%");
		stmt.setString(12, "%" + bnp_brpogt + "%");
		stmt.setString(13, "%" + bnp_status + "%");

		ResultSet rowsAffected = stmt.executeQuery();
		while (rowsAffected.next()) {
			broj_racuna = rowsAffected.getString("BROJ_RACUNA");
			sifra_klijenta = rowsAffected.getString("SIFRA_KLIJENTA");
			bnp_datum = rowsAffected.getString("BNP_DATUM");
			bnp_presek = rowsAffected.getString("BNP_PRESEK");
			dne_broj_racuna = rowsAffected.getString("DNE_BROJ_RACUNA");
			datum = rowsAffected.getString("DATUM");
			bnp_brukorist = rowsAffected.getString("BNP_BRUKORIST");
			bnp_u_korist = rowsAffected.getString("BNP_U_KORIST");
			bnp_brnateret = rowsAffected.getString("BNP_BRNATERET");
			bnp_ukteret = rowsAffected.getString("BNP_UKTERET");
			bnp_brpogk = rowsAffected.getString("BNP_BRPOGK");
			bnp_brpogt = rowsAffected.getString("BNP_BRPOGT");
			bnp_status = rowsAffected.getString("BNP_STATUS");

			addRow(new String[] { broj_racuna, sifra_klijenta, bnp_datum, bnp_presek,
					dne_broj_racuna, datum, bnp_brukorist, bnp_u_korist, bnp_brnateret,
					bnp_ukteret, bnp_brpogk, bnp_brpogt, bnp_status });
		}
		stmt.close();
	}

	//ne treba da postoji opcija izmene izvoda
	@Override
	public int updateRow(int index, Object[] data, String stariPtt)
			throws SQLException {

		int retVal = 0;
		
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] { "", "", "", "", "", "", "", "", "", "", "", "", "" });
	}
	
	//ne treba da postoji opcija brisanja preseka izvoda
	@Override
	public void deleteRow(int index) throws SQLException {
	/*	checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"DELETE FROM presek_izvoda WHERE bnp_presek = ? ");
		String sifra = (String) getValueAt(index, 3); //sifra je ustvari bnp_presek u tabeli
		stmt.setString(1, sifra);
		// Brisanje iz baze
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i brisanje iz TableModel-a
			removeRow(index);
			fireTableDataChanged();
		}*/
	}

}