package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.Column;
import util.SortUtils;
import db.DBConnection;

public class KursnaListaTableModel extends GenericTableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String basicQuery = "SELECT KL_DATUM, KL_BROJ, KL_DATPR";
	String orderBy = "ORDER BY KL_DATUM";
	String whereStmt = "";
	
	public KursnaListaTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}

	@Override
	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		String datum = (String)data[0];
		String broj = (String)data[1];
		String primenjujeSeOd = (String)data[2];
		
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"INSERT INTO KURSNA_LISTA (KL_DATUM, KL_BROJ, KL_DATPR) VALUES (? ,?, ?)"
		);
		
		stmt.setString(1, datum);
		stmt.setString(2, broj);
		stmt.setString(3,  primenjujeSeOd);
		
		int rowsAffected = stmt.executeUpdate();
		stmt.close();

		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		
		return retVal;
	}

	@Override
	public void findData(Object[] data) throws SQLException {
		String datum = (String)data[0];
		String broj = (String)data[1];
		String primenjujeSeOd = (String)data[2];
		
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"SELECT KL_DATUM, KL_BROJ, KL_DATPR FROM KURSNA_LISTA WHERE KL_DATUM LIKE ? AND KL_BROJ LIKE ? AND KL_DATPR LIKE ?"
		);

		stmt.setString(1, "%" + datum + "%");
		stmt.setString(2, "%" + broj + "%");
		stmt.setString(3, "%" + primenjujeSeOd + "%");
		
		ResultSet rowsAffected = stmt.executeQuery();
		setRowCount(0);
		
		while (rowsAffected.next()) {
			addRow(new String[] {
				rowsAffected.getString("KL_DATUM"),
				rowsAffected.getString("KL_BROJ"),
				rowsAffected.getString("KL_DATPR")
			});
		}
		
		stmt.close();
		
	}

	@Override
	public int updateRow(int index, Object[] data, String staraSifra)
			throws SQLException {
		checkRow(index);
		String datum = (String)data[0];
		String broj = (String)data[1];
		String primenjujeSeOd = (String) data[2];
		
		int retVal = 0;
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"UPDATE KURSNA_LISTA SET KL_DATUM = ?, KL_BROJ = ?, KL_DATPR = ? WHERE KL_DATUM = ?"
		);
		
		stmt.setString(1, datum);
		stmt.setString(2, broj);
		stmt.setString(3, primenjujeSeOd);
		stmt.setString(4, staraSifra);
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] { "", "", "" });
		
	}

	@Override
	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"DELETE FROM KURSNA_LISTA WHERE KL_DATUM = ?");
		String datum = (String) getValueAt(index, 2);
		stmt.setString(1, datum);
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			removeRow(index);
			fireTableDataChanged();
		}
		
	}

	@Override
	public void open(Column[] sifraColumns) throws SQLException {
		fillData("SELECT KL_DATUM, KL_BROJ, KL_DATPR FROM KURSNA_LISTA ORDER BY KL_DATUM");
		
	}

	private void fillData(String sql) throws SQLException {
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		setRowCount(0);
		while (rset.next()) {
			addRow(new String[] {
				rset.getString("KL_DATUM"),
				rset.getString("KL_BROJ"),
				rset.getString("KL_DATPR")
			});
		}
		
		rset.close();
		stmt.close();
		fireTableDataChanged();
		
	}

	@Override
	protected void checkRow(int index) throws SQLException {
		DBConnection.getConnection().setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection().prepareStatement(
			"SELECT KL_DATUM, KL_BROJ, KL_DATPR" + " WHERE KL_DATUM = ?"
		);

		String sifra = (String) getValueAt(index, 0);
		selectStmt.setString(1, sifra);

		ResultSet rset = selectStmt.executeQuery();

		String datum = "", broj = "", primenjujeSeOd = "";
		boolean postoji = false;
		String errorMsg = "";
		
		while (rset.next()) {
			datum = rset.getString("KL_DATUM").trim();
			broj = rset.getString("KL_BROJ").trim();
			primenjujeSeOd = rset.getString("KL_DATPR");
			postoji = true;
		}
		
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(datum, ((String)getValueAt(index, 0)).trim()) != 0)
				   || (SortUtils.getLatCyrCollator().compare(broj, (String)getValueAt(index, 1)) != 0)
				   || (SortUtils.getLatCyrCollator().compare(primenjujeSeOd, (String)getValueAt(index, 2)) != 0)) {
			setValueAt(datum, index, 0);
			setValueAt(broj, index, 1);
			setValueAt(primenjujeSeOd, index, 2);
			fireTableDataChanged();
		}
		
		rset.close();
		selectStmt.close();
		
		DBConnection.getConnection().setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
		
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
		
	}

}
