package model;

import java.sql.SQLException;

import javax.swing.table.DefaultTableModel;

import util.Column;
import util.SortUtils;

public abstract class GenericTableModel extends DefaultTableModel {

	public GenericTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}

	public boolean isCellEditable(int row, int column) {
		return false;
	}

	protected int sortedInsert(Object[] data) {
		String sifra = (String)data[0];
		int left = 0;
		int right = getRowCount() - 1;
		int mid = (left + right) / 2;
		while (left <= right) {
			mid = (left + right) / 2;
			String aSifra = (String) getValueAt(mid, 0);
			if (SortUtils.getLatCyrCollator().compare(sifra, aSifra) > 0)
				left = mid + 1;
			else if (SortUtils.getLatCyrCollator().compare(sifra, aSifra) < 0)
				right = mid - 1;
			else
				break;
		}
		insertRow(left, data);
		return left;
	}

	public abstract int insertRow(Object[] data) throws SQLException;
	
	public abstract void findData(Object[] data) throws SQLException;
	
	public abstract int updateRow(int index, Object[] data, String staraSifra) throws SQLException;
	
	public abstract void refresh() throws SQLException;

	public abstract void deleteRow(int index) throws SQLException;

	// metoda sluzi da popuni tabelu kada se otvori forma
	// sifraColumns je null ako treba prikazati sve
	// ako se forma otvara preko next-form mehanizma onda se prosledjuje sifraColumns koji odgovara sifri selektovanog reda
	public abstract void open(Column[] sifraColumns) throws SQLException;
	
	// metoda sluzi za proveru i zaključavanje tekućeg sloga u trenutku izmene i brisanja
	protected abstract void checkRow(int index) throws SQLException;
	
}
