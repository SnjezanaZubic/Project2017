package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.Column;
import util.SortUtils;
import db.DBConnection;

public class FizickoLiceTableModel extends GenericTableModel {

	private String basicQuery = "SELECT KLIJENT.SIFRA_KLIJENTA, JMBG, IME, PREZIME, MESTO.PTT_BROJ, MESTO.NAZIV, ADRESA, TELEFON, DELATNOST "
			+ "FROM (KLIJENT JOIN MESTO on KLIJENT.PTT_BROJ = MESTO.PTT_BROJ) "
			+ "JOIN FIZICKO_LICE on KLIJENT.SIFRA_KLIJENTA = FIZICKO_LICE.SIFRA_KLIJENTA";
	private String orderBy = " ORDER BY KLIJENT.SIFRA_KLIJENTA";
	private String whereStmt = "";

	public FizickoLiceTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}

	public void open(Column[] sifraColumns) throws SQLException {
		if (sifraColumns == null)
			fillData(basicQuery + whereStmt + orderBy);
		else if (sifraColumns.length == 1)
			fillData(basicQuery + " WHERE klijent." + sifraColumns[0].getName() + " = " + sifraColumns[0].getValue() + " "  + orderBy);
		else {
			System.out.println("SIFRA IMA VISE OD JEDNE KOLONE, DORADITI DA RADI ZA TAJ SLUCAJ --> (FizickoLiceTableModel.java:31)");
		}
	}

	// Popunjavanje matrice podacima
	public void fillData(String sql) throws SQLException {
		setRowCount(0);
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		while (rset.next()) {
			String sifra = rset.getString("SIFRA_KLIJENTA");
			String jmbg = rset.getString("JMBG");
			String ime = rset.getString("IME");
			String prezime = rset.getString("PREZIME");
			String pttBroj = rset.getString("PTT_BROJ");
			String grad = rset.getString("NAZIV");
			String adresa = rset.getString("ADRESA");
			String telefon = rset.getString("TELEFON");
			String delatnost = rset.getString("DELATNOST");
			addRow(new String[] { sifra, jmbg, ime, prezime, pttBroj, grad,
					adresa, telefon, delatnost });
		}
		rset.close();
		stmt.close();
		fireTableDataChanged();
	}

	@Override
	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		String sifra = (String)data[0];
		String jmbg = (String)data[1];
		String ime = (String)data[2];
		String prezime = (String)data[3];
		String pttBroj = (String)data[4];
		String grad = (String)data[5];
		String adresa = (String)data[6];
		String telefon = (String)data[7];
		String delatnost = (String)data[8];
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"INSERT INTO klijent (sifra_klijenta, ptt_broj, adresa, telefon) VALUES (?, ?, ?, ?)");
		stmt.setString(1, sifra);
		stmt.setString(2, pttBroj);
		stmt.setString(3, adresa);
		stmt.setString(4, telefon);
		int rowsAffected = stmt.executeUpdate();

		stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"INSERT INTO fizicko_lice (sifra_klijenta, jmbg, prezime, ime, delatnost) VALUES (?, ?, ?, ?, ?)");
		stmt.setString(1, sifra);
		stmt.setString(2, jmbg);
		stmt.setString(3, prezime);
		stmt.setString(4, ime);
		stmt.setString(5, delatnost);
		rowsAffected = stmt.executeUpdate();
		stmt.close();

		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i unos u TableModel
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}

		return retVal;
	}

	@Override
	public void findData(Object[] data) throws SQLException {
		setRowCount(0);

		String sifra = (String)data[0];
		String jmbg = (String)data[1];
		String ime = (String)data[2];
		String prezime = (String)data[3];
		String ptt = (String)data[4];
		String grad = (String)data[5];
		String adresa = (String)data[6];
		String telefon = (String)data[7];
		String delatnost = (String)data[8];

		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						basicQuery
								+ " WHERE klijent.sifra_klijenta LIKE ? AND jmbg LIKE ? AND ime LIKE ? AND prezime LIKE ?"
								+ " AND mesto.ptt_broj LIKE ? AND naziv LIKE ? AND adresa LIKE ? AND telefon LIKE ? AND delatnost LIKE ? "
								+ orderBy);

		stmt.setString(1, "%" + sifra + "%");
		stmt.setString(2, "%" + jmbg + "%");
		stmt.setString(3, "%" + ime + "%");
		stmt.setString(4, "%" + prezime + "%");
		stmt.setString(5, "%" + ptt + "%");
		stmt.setString(6, "%" + grad + "%");
		stmt.setString(7, "%" + adresa + "%");
		stmt.setString(8, "%" + telefon + "%");
		stmt.setString(9, "%" + delatnost + "%");

		ResultSet rowsAffected = stmt.executeQuery();
		while (rowsAffected.next()) {
			sifra = rowsAffected.getString("sifra_klijenta");
			jmbg = rowsAffected.getString("jmbg");
			ime = rowsAffected.getString("ime");
			prezime = rowsAffected.getString("prezime");
			ptt = rowsAffected.getString("ptt_broj");
			grad = rowsAffected.getString("naziv");
			adresa = rowsAffected.getString("adresa");
			telefon = rowsAffected.getString("telefon");
			delatnost = rowsAffected.getString("delatnost");
			addRow(new String[] { sifra, jmbg, ime, prezime, ptt, grad, adresa,
					telefon, delatnost });
		}
		stmt.close();
	}

	@Override
	public int updateRow(int index, Object[] data, String staraSifra)
			throws SQLException {
		checkRow(index);

		String sifra = (String)data[0];
		String jmbg = (String)data[1];
		String ime = (String)data[2];
		String prezime = (String)data[3];
		String ptt = (String)data[4];
		String grad = (String)data[5];
		String adresa = (String)data[6];
		String telefon = (String)data[7];
		String delatnost = (String)data[8];
		
		int retVal = 0;
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"UPDATE klijent SET sifra_klijenta = ?, ptt_broj = ?, adresa = ?, telefon = ? WHERE sifra_klijenta = ?");
		stmt.setString(1, sifra);
		stmt.setString(2, ptt);
		stmt.setString(3, adresa);
		stmt.setString(4, telefon);
		stmt.setString(5, staraSifra);

		int rowsAffected = stmt.executeUpdate();
		
		retVal = 0;
		stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"UPDATE fizicko_lice SET sifra_klijenta = ?, jmbg = ?, prezime = ?, ime = ?, delatnost = ? WHERE sifra_klijenta = ?");
		stmt.setString(1, sifra);
		stmt.setString(2, jmbg);
		stmt.setString(3, prezime);
		stmt.setString(4, ime);
		stmt.setString(5, delatnost);
		stmt.setString(6, staraSifra);

		rowsAffected = stmt.executeUpdate();
		
		stmt.close();
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// TableModel update
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] { "", "", "", "", "", "", "", "", "" });
	}

	@Override
	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"DELETE FROM fizicko_lice WHERE sifra_klijenta = ?");
		String sifra = (String) getValueAt(index, 0);
		stmt.setString(1, sifra);
		// Brisanje iz baze
		int rowsAffected = stmt.executeUpdate();
		
		stmt = DBConnection.getConnection().prepareStatement(
				"DELETE FROM klijent WHERE sifra_klijenta = ?");
		sifra = (String) getValueAt(index, 0);
		stmt.setString(1, sifra);
		// Brisanje iz baze
		rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i brisanje iz TableModel-a
			removeRow(index);
			fireTableDataChanged();
		}
	}

	@Override
	protected void checkRow(int index) throws SQLException {

		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection()
				.prepareStatement(
						basicQuery + " WHERE klijent.sifra_klijenta = ?");

		String sifra = (String) getValueAt(index, 0);
		selectStmt.setString(1, sifra);

		ResultSet rset = selectStmt.executeQuery();

		String sifraKlijenta = "", jmbg = "", ime = "", prezime = "", ptt = "", grad = "", adresa = "", telefon = "", delatnost = "";
		Boolean postoji = false;
		String errorMsg = "";
		while (rset.next()) {
			sifraKlijenta = rset.getString("sifra_klijenta");
			jmbg = rset.getString("jmbg");
			ime = rset.getString("ime");
			prezime = rset.getString("prezime");
			ptt = rset.getString("ptt_broj");
			grad = rset.getString("naziv");
			adresa = rset.getString("adresa");
			telefon = rset.getString("telefon");
			delatnost = rset.getString("delatnost");
			postoji = true;
		}
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(sifraKlijenta,
				((String) getValueAt(index, 0)).trim()) != 0)
				|| (SortUtils.getLatCyrCollator().compare(jmbg,
						(String) getValueAt(index, 1)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(ime,
						(String) getValueAt(index, 2)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(prezime,
						(String) getValueAt(index, 3)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(ptt,
						(String) getValueAt(index, 4)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(grad,
						(String) getValueAt(index, 5)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(adresa,
						(String) getValueAt(index, 6)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(telefon,
						(String) getValueAt(index, 7)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(delatnost,
						(String) getValueAt(index, 8)) != 0)) {
			setValueAt(sifraKlijenta, index, 0);
			setValueAt(jmbg, index, 1);
			setValueAt(ime, index, 2);
			setValueAt(prezime, index, 3);
			setValueAt(ptt, index, 4);
			setValueAt(grad, index, 5);
			setValueAt(adresa, index, 6);
			setValueAt(telefon, index, 7);
			setValueAt(delatnost, index, 8);
			fireTableDataChanged();
		}
		rset.close();
		selectStmt.close();
		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_READ_COMMITTED);
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
	}

}
