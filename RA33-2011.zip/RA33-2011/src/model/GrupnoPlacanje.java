package model;

import java.util.Date;
import java.util.List;

public class GrupnoPlacanje {
	private String IDPoruke;
	private String SWIFTkodBankeDuznika;
	private String obracunskiRacunBankeDuznika;
	private String SWIFTkodBankePoverioca;
	private Double ukupanIznos;
	private String obracunskiRacunBankePoverioca;
	private Date datumValute;
	private String sifraValute;
	private Date datum;
	private List<PojedinacnoPlacanje> pojedinacnaPlacanja;
	
	public String getIDPoruke() {
		return IDPoruke;
	}

	public void setIDPoruke(String iDPoruke) {
		IDPoruke = iDPoruke;
	}

	public String getSWIFTkodBankeDuznika() {
		return SWIFTkodBankeDuznika;
	}

	public void setSWIFTkodBankeDuznika(String sWIFTkodBankeDuznika) {
		SWIFTkodBankeDuznika = sWIFTkodBankeDuznika;
	}

	public String getObracunskiRacunBankeDuznika() {
		return obracunskiRacunBankeDuznika;
	}

	public void setObracunskiRacunBankeDuznika(
			String obracunskiRacunBankeDuznika) {
		this.obracunskiRacunBankeDuznika = obracunskiRacunBankeDuznika;
	}

	public String getSWIFTkodBankePoverioca() {
		return SWIFTkodBankePoverioca;
	}

	public void setSWIFTkodBankePoverioca(String sWIFTkodBankePoverioca) {
		SWIFTkodBankePoverioca = sWIFTkodBankePoverioca;
	}

	public Double getUkupanIznos() {
		return ukupanIznos;
	}

	public void setUkupanIznos(Double ukupanIznos) {
		this.ukupanIznos = ukupanIznos;
	}

	public String getObracunskiRacunBankePoverioca() {
		return obracunskiRacunBankePoverioca;
	}

	public void setObracunskiRacunBankePoverioca(
			String obracunskiRacunBankePoverioca) {
		this.obracunskiRacunBankePoverioca = obracunskiRacunBankePoverioca;
	}

	public Date getDatumValute() {
		return datumValute;
	}

	public void setDatumValute(Date datumValute) {
		this.datumValute = datumValute;
	}

	public String getSifraValute() {
		return sifraValute;
	}

	public void setSifraValute(String sifraValute) {
		this.sifraValute = sifraValute;
	}

	public Date getDatum() {
		return datum;
	}

	public void setDatum(Date datum) {
		this.datum = datum;
	}

	public List<PojedinacnoPlacanje> getPojedinacnaPlacanja() {
		return pojedinacnaPlacanja;
	}

	public void setPojedinacnaPlacanja(
			List<PojedinacnoPlacanje> pojedinacnaPlacanja) {
		this.pojedinacnaPlacanja = pojedinacnaPlacanja;
	}
}
