package model;

public class PojedinacnoPlacanje {
	private String IDNalogZaPlacanje;
	private TDeoUplatnice deoUplatnice;
	private String sifraValute;

	public String getIDNalogZaPlacanje() {
		return IDNalogZaPlacanje;
	}

	public void setIDNalogZaPlacanje(String iDNalogZaPlacanje) {
		IDNalogZaPlacanje = iDNalogZaPlacanje;
	}

	public TDeoUplatnice getDeoUplatnice() {
		return deoUplatnice;
	}

	public void setDeoUplatnice(TDeoUplatnice deoUplatnice) {
		this.deoUplatnice = deoUplatnice;
	}

	public String getSifraValute() {
		return sifraValute;
	}

	public void setSifraValute(String sifraValute) {
		this.sifraValute = sifraValute;
	}

}
