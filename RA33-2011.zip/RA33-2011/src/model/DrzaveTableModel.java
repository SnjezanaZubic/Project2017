package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.Column;
import util.SortUtils;
import db.DBConnection;

public class DrzaveTableModel extends GenericTableModel {

	private String basicQuery = "SELECT dr_sifra, dr_naziv FROM drzava";
	private String orderBy = " ORDER BY dr_sifra";
	private String whereStmt = "";

	public DrzaveTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}

	// Otvaranje upita
	public void open(Column[] sifraColumns) throws SQLException {
		fillData(basicQuery + whereStmt + orderBy);
	}

	// Popunjavanje matrice podacima

	public void fillData(String sql) throws SQLException {
		setRowCount(0);
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		while (rset.next()) {
			String sifra = rset.getString("DR_SIFRA");
			String naziv = rset.getString("DR_NAZIV");
			addRow(new String[] { sifra, naziv });
		}
		rset.close();
		stmt.close();
		fireTableDataChanged();
	}

	public void findData(Object[] data) throws SQLException {
		setRowCount(0);
		String sifra = (String) data[0];
		String naziv = (String) data[1];
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"SELECT dr_sifra, dr_naziv FROM DRZAVA WHERE dr_sifra LIKE ? AND dr_naziv LIKE ?");

		stmt.setString(1, "%" + sifra + "%");
		stmt.setString(2, "%" + naziv + "%");
		ResultSet rowsAffected = stmt.executeQuery();
		while (rowsAffected.next()) {
			sifra = rowsAffected.getString("DR_SIFRA");
			naziv = rowsAffected.getString("DR_NAZIV");
			addRow(new String[] { sifra, naziv });
		}
		stmt.close();
		// Unos sloga u bazu
		// DBConnection.getConnection().commit();

	}

	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		String sifra = (String) data[0];
		String naziv = (String) data[1];
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"INSERT INTO drzava (dr_sifra, dr_naziv) VALUES (? ,?)");
		stmt.setString(1, sifra);
		stmt.setString(2, naziv);
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i unos u TableModel
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"DELETE FROM drzava WHERE dr_sifra=?");
		String sifra = (String) getValueAt(index, 0);
		stmt.setString(1, sifra);
		// Brisanje iz baze
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i brisanje iz TableModel-a
			removeRow(index);
			fireTableDataChanged();
		}
	}

	protected void checkRow(int index) throws SQLException {

		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection()
				.prepareStatement(basicQuery + " where DR_SIFRA =?");

		String sifra = (String) getValueAt(index, 0);
		selectStmt.setString(1, sifra);

		ResultSet rset = selectStmt.executeQuery();

		String sifraDr = "", naziv = "";
		Boolean postoji = false;
		String errorMsg = "";
		while (rset.next()) {
			sifraDr = rset.getString("DR_SIFRA").trim();
			naziv = rset.getString("DR_NAZIV").trim();
			postoji = true;
		}
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(sifraDr,
				((String) getValueAt(index, 0)).trim()) != 0)
				|| (SortUtils.getLatCyrCollator().compare(naziv,
						(String) getValueAt(index, 1)) != 0)) {
			setValueAt(sifraDr, index, 0);
			setValueAt(naziv, index, 1);
			fireTableDataChanged();
		}
		rset.close();
		selectStmt.close();
		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_READ_COMMITTED);
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
	}

	public int updateRow(int index, Object[] data, String staraSifra)
			throws SQLException {
		checkRow(index);
		String sifra = (String) data[0];
		String naziv = (String) data[1];
		int retVal = 0;
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"UPDATE drzava SET dr_sifra = ?, dr_naziv = ? WHERE dr_sifra = ?");
		stmt.setString(1, sifra);
		stmt.setString(2, naziv);
		stmt.setString(3, staraSifra);

		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// TableModel update
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] { "", "" });
	}
}
