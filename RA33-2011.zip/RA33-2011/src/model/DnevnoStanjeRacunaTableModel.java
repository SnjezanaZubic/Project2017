package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.Column;
import util.SortUtils;
import db.DBConnection;

public class DnevnoStanjeRacunaTableModel extends GenericTableModel {

	private String basicQuery = "SELECT broj_racuna, datum, prethodno_stanje, promet_na_teret, promet_u_korist, novo_stanje FROM dnevno_stanje_racuna";
	private String orderBy = " ORDER BY datum";
	private String whereStmt = "";

	public DnevnoStanjeRacunaTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}

	public void open(Column[] sifraColumns) throws SQLException {
		fillData(basicQuery + whereStmt + orderBy);
	}

	public void fillData(String sql) throws SQLException {
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		setRowCount(0);
		
		while (rset.next()) {
			addRow(new String[] {
				rset.getString("broj_racuna"),
				rset.getString("datum"),
				rset.getString("prethodno_stanje"),
				rset.getString("promet_na_teret"),
				rset.getString("promet_u_korist"),
				rset.getString("novo_stanje")
			});
		}
		
		rset.close();
		stmt.close();
		fireTableDataChanged();
	}

	public void findData(Object[] data) throws SQLException {
		String brojRacuna = (String)data[0];
		String datum = (String)data[1];
		String prethodnoStanje = (String)data[2];
		String prometNaTeret = (String)data[3];
		String prometUKorist = (String)data[4];
		String novoStanje = (String)data[5];
		
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			basicQuery
			+ " WHERE broj_racuna LIKE ? AND datum LIKE ? AND prethodno_stanje LIKE ?"
			+ " AND promet_na_teret LIKE ? AND promet_u_korist LIKE ? AND novo_stanje LIKE ?"
		);

		stmt.setString(1, "%" + brojRacuna + "%");
		stmt.setString(2, "%" + datum + "%");
		stmt.setString(3, "%" + prethodnoStanje + "%");
		stmt.setString(4, "%" + prometNaTeret + "%");
		stmt.setString(5, "%" + prometUKorist + "%");
		stmt.setString(6, "%" + novoStanje + "%");
		
		ResultSet rowsAffected = stmt.executeQuery();
		setRowCount(0);
		
		while (rowsAffected.next()) {
			addRow(new String[] {
				rowsAffected.getString("broj_racuna"),
				rowsAffected.getString("datum"),
				rowsAffected.getString("prethodno_stanje"),
				rowsAffected.getString("promet_na_teret"),
				rowsAffected.getString("promet_u_korist"),
				rowsAffected.getString("novo_stanje")
			});
		}
		
		stmt.close();
	}

	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		String brojRacuna = (String)data[0];
		String datum = (String)data[1];
		String prethodnoStanje = (String)data[2];
		String prometNaTeret = (String)data[3];
		String prometUKorist = (String)data[4];
		String novoStanje = (String)data[5];
		
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"INSERT INTO dnevno_stanje_racuna"
			+ " (broj_racuna, datum, prethodno_stanje, promet_na_teret, promet_u_korist, novo_stanje)"
			+ " VALUES (?, ?, ?, ?, ?, ?)"
		);
		
		stmt.setString(1, brojRacuna);
		stmt.setString(2, datum);
		stmt.setString(3, prethodnoStanje);
		stmt.setString(4, prometNaTeret);
		stmt.setString(5, prometUKorist);
		stmt.setString(6, novoStanje);
		
		int rowsAffected = stmt.executeUpdate();
		stmt.close();

		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		
		return retVal;
	}

	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"DELETE FROM dnevno_stanje_racuna WHERE broj_racuna = ?"
		);
		
		stmt.setString(1, (String)getValueAt(index, 0));
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			removeRow(index);
			fireTableDataChanged();
		}
	}

	protected void checkRow(int index) throws SQLException {
		DBConnection.getConnection().setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection().prepareStatement(
			basicQuery + " WHERE broj_racuna = ?"
		);

		String sifra = (String) getValueAt(index, 0);
		selectStmt.setString(1, sifra);

		ResultSet rset = selectStmt.executeQuery();

		String brojRacuna = "", datum = "", prethodnoStanje = "", prometNaTeret = "", prometUKorist = "", novoStanje = "";
		boolean postoji = false;
		String errorMsg = "";
		
		while (rset.next()) {
			brojRacuna = rset.getString("broj_racuna").trim();
			datum = rset.getString("datum").trim();
			prethodnoStanje = rset.getString("prethodno_stanje").trim();
			prometNaTeret = rset.getString("promet_na_teret").trim();
			prometUKorist = rset.getString("promet_u_korist").trim();
			novoStanje = rset.getString("novo_stanje").trim();
			postoji = true;
		}
		
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(brojRacuna, ((String)getValueAt(index, 0)).trim()) != 0)
				   || (SortUtils.getLatCyrCollator().compare(datum, (String)getValueAt(index, 1)) != 0)
				   || (SortUtils.getLatCyrCollator().compare(prethodnoStanje, (String)getValueAt(index, 2)) != 0)
				   || (SortUtils.getLatCyrCollator().compare(prometNaTeret, ((String)getValueAt(index, 3)).trim()) != 0)
				   || (SortUtils.getLatCyrCollator().compare(prometUKorist, (String)getValueAt(index, 4)) != 0)
				   || (SortUtils.getLatCyrCollator().compare(novoStanje, (String)getValueAt(index, 5)) != 0)) {
			setValueAt(brojRacuna, index, 0);
			setValueAt(datum, index, 1);
			setValueAt(prethodnoStanje, index, 2);
			setValueAt(prometNaTeret, index, 3);
			setValueAt(prometUKorist, index, 4);
			setValueAt(novoStanje, index, 5);
			fireTableDataChanged();
		}
		
		rset.close();
		selectStmt.close();
		
		DBConnection.getConnection().setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
		
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
	}

	public int updateRow(int index, Object[] data, String stariBrojRacuna) throws SQLException {
		checkRow(index);
		String brojRacuna = (String)data[0];
		String datum = (String)data[1];
		String prethodnoStanje = (String)data[2];
		String prometNaTeret = (String)data[3];
		String prometUKorist = (String)data[4];
		String novoStanje = (String)data[5];
		
		int retVal = 0;
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"UPDATE dnevno_stanje_racuna SET broj_racuna = ?, datum = ?, prethodno_stanje = ?"
			+ " promet_na_teret = ? promet_u_korist = ? novo_stanje = ? WHERE broj_racuna = ?"
		);
		
		stmt.setString(1, brojRacuna);
		stmt.setString(2, datum);
		stmt.setString(3, prethodnoStanje);
		stmt.setString(4, prometNaTeret);
		stmt.setString(5, prometUKorist);
		stmt.setString(6, novoStanje);
		stmt.setString(7, stariBrojRacuna);
		
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] { "", "", "", "", "", "" });
	}
}
