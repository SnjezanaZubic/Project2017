package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.Column;
import util.SortUtils;
import db.DBConnection;

public class GasenjeRacunaTableModel extends GenericTableModel {

	private String basicQuery = "SELECT datum_gasenja, broj_racuna, prebaceno_na_racun FROM gasenje_racuna";
	private String orderBy = " ORDER BY datum_gasenja";
	private String whereStmt = "";

	public GasenjeRacunaTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}

	public void open(Column[] sifraColumns) throws SQLException {
		fillData(basicQuery + whereStmt + orderBy);
	}

	public void fillData(String sql) throws SQLException {
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		setRowCount(0);
		
		while (rset.next()) {
			addRow(new String[] {
				rset.getString("datum_gasenja"),
				rset.getString("broj_racuna"),
				rset.getString("prebaceno_na_racun")
			});
		}
		
		rset.close();
		stmt.close();
		fireTableDataChanged();
	}

	public void findData(Object[] data) throws SQLException {
		String datum = (String)data[0];
		String broj = (String)data[1];
		String prebacenoNa = (String)data[2];
		
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"SELECT datum_gasenja, broj_racuna, prebaceno_na_racun " +
			"FROM gasenje_racuna " + 
			"WHERE datum_gasenja LIKE ? AND broj_racuna LIKE ? AND prebaceno_na_racun LIKE ?"
		);

		stmt.setString(1, "%" + datum + "%");
		stmt.setString(2, "%" + broj + "%");
		stmt.setString(3, "%" + prebacenoNa + "%");
		
		ResultSet rowsAffected = stmt.executeQuery();
		setRowCount(0);
		
		while (rowsAffected.next()) {
			addRow(new String[] {
				rowsAffected.getString("datum_gasenja"),
				rowsAffected.getString("broj_racuna"),
				rowsAffected.getString("prebaceno_na_racun")
			});
		}
		
		stmt.close();
	}

	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		String datum = (String)data[0];
		String broj = (String)data[1];
		String prebacenoNa = (String)data[2];
		
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"INSERT INTO gasenje_racuna (datum_gasenja, broj_racuna, prebaceno_na_racun) VALUES (?, ?, ?)"
		);
		
		stmt.setString(1, datum);
		stmt.setString(2, broj);
		stmt.setString(3, prebacenoNa);
		
		int rowsAffected = stmt.executeUpdate();
		stmt.close();

		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		
		return retVal;
	}

	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"DELETE FROM gasenje_racuna WHERE datum_gasenja = ?"
		);
		
		stmt.setString(1, (String)getValueAt(index, 0));
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			removeRow(index);
			fireTableDataChanged();
		}
	}

	protected void checkRow(int index) throws SQLException {
		DBConnection.getConnection().setTransactionIsolation(Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection().prepareStatement(
			basicQuery + " WHERE datum_gasenja = ?"
		);

		String sifra = (String) getValueAt(index, 0);
		selectStmt.setString(1, sifra);

		ResultSet rset = selectStmt.executeQuery();

		String datum = "", broj = "", prebacenoNa = "";
		boolean postoji = false;
		String errorMsg = "";
		
		while (rset.next()) {
			datum = rset.getString("datum_gasenja").trim();
			broj = rset.getString("broj_racuna").trim();
			prebacenoNa = rset.getString("prebaceno_na_racun").trim();
			postoji = true;
		}
		
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(datum, ((String)getValueAt(index, 0)).trim()) != 0)
				   || (SortUtils.getLatCyrCollator().compare(broj, (String)getValueAt(index, 1)) != 0)
				   || (SortUtils.getLatCyrCollator().compare(prebacenoNa, (String)getValueAt(index, 2)) != 0)) {
			setValueAt(datum, index, 0);
			setValueAt(broj, index, 1);
			fireTableDataChanged();
		}
		
		rset.close();
		selectStmt.close();
		
		DBConnection.getConnection().setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
		
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
	}

	public int updateRow(int index, Object[] data, String stariDatumGasenja) throws SQLException {
		checkRow(index);
		String datumGasenja = (String)data[0];
		String brojRacuna = (String)data[1];
		String prebacenoNaRacun = (String)data[2];
		
		int retVal = 0;
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
			"UPDATE gasenje_racuna SET datum_gasenja = ?, broj_racuna = ?, prebaceno_na_racun = ? WHERE datum_gasenja = ?"
		);
		
		stmt.setString(1, datumGasenja);
		stmt.setString(2, brojRacuna);
		stmt.setString(3, prebacenoNaRacun);
		stmt.setString(4, stariDatumGasenja);
		
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		DBConnection.getConnection().commit();
		
		if (rowsAffected > 0) {
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] { "", "" });
	}
}
