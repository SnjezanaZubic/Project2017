package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import util.Column;
import util.SortUtils;
import db.DBConnection;

public class PravnoLiceTableModel extends GenericTableModel {

	private String basicQuery = "SELECT KLIJENT.SIFRA_KLIJENTA, PIB, NAZIV_ORGANIZACIJE, MESTO.PTT_BROJ, MESTO.NAZIV, ADRESA, TELEFON "
			+ "FROM (KLIJENT JOIN MESTO on KLIJENT.PTT_BROJ = MESTO.PTT_BROJ) "
			+ "JOIN PRAVNO_LICE on KLIJENT.SIFRA_KLIJENTA = PRAVNO_LICE.SIFRA_KLIJENTA";
	private String orderBy = " ORDER BY KLIJENT.SIFRA_KLIJENTA";
	private String whereStmt = "";

	public PravnoLiceTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}

	public void open(Column[] sifraColumns) throws SQLException {
		if (sifraColumns == null)
			fillData(basicQuery + whereStmt + orderBy);
		else if (sifraColumns.length == 1)
			fillData(basicQuery + " WHERE klijent." + sifraColumns[0].getName() + " = " + sifraColumns[0].getValue() + " "  + orderBy);
		else {
			System.out.println("SIFRA IMA VISE OD JEDNE KOLONE, DORADITI DA RADI ZA TAJ SLUCAJ --> (PravnoLiceTableModel.java:31)");
		}
	}

	// Popunjavanje matrice podacima
	public void fillData(String sql) throws SQLException {
		setRowCount(0);
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		while (rset.next()) {
			String sifra = rset.getString("SIFRA_KLIJENTA");
			String pib = rset.getString("PIB");
			String naziv = rset.getString("NAZIV");
			String pttBroj = rset.getString("PTT_BROJ");
			String grad = rset.getString("NAZIV");
			String adresa = rset.getString("ADRESA");
			String telefon = rset.getString("TELEFON");
			addRow(new String[] { sifra, pib, naziv, pttBroj, grad,
					adresa, telefon });
		}
		rset.close();
		stmt.close();
		fireTableDataChanged();
	}

	@Override
	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		String sifra = (String)data[0];
		String pib = (String)data[1];
		String naziv = (String)data[2];
		String pttBroj = (String)data[3];
		String grad = (String)data[4];
		String adresa = (String)data[5];
		String telefon = (String)data[6];
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"INSERT INTO klijent (sifra_klijenta, ptt_broj, adresa, telefon) VALUES (?, ?, ?, ?)");
		stmt.setString(1, sifra);
		stmt.setString(2, pttBroj);
		stmt.setString(3, adresa);
		stmt.setString(4, telefon);
		int rowsAffected = stmt.executeUpdate();

		stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"INSERT INTO pravno_lice (sifra_klijenta, pib, naziv) VALUES (?, ?, ?)");
		stmt.setString(1, sifra);
		stmt.setString(2, pib);
		stmt.setString(3, naziv);
		rowsAffected = stmt.executeUpdate();
		stmt.close();

		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i unos u TableModel
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}

		return retVal;
	}

	@Override
	public void findData(Object[] data) throws SQLException {
		setRowCount(0);

		String sifra = (String)data[0];
		String pib = (String)data[1];
		String naziv = (String)data[2];
		String ptt = (String)data[3];
		String grad = (String)data[4];
		String adresa = (String)data[5];
		String telefon = (String)data[6];

		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						basicQuery
								+ " WHERE klijent.sifra_klijenta LIKE ? AND pib LIKE ? AND naziv_organizacije LIKE ?"
								+ " AND mesto.ptt_broj LIKE ? AND naziv LIKE ? AND adresa LIKE ? AND telefon LIKE ? "
								+ orderBy);

		stmt.setString(1, "%" + sifra + "%");
		stmt.setString(2, "%" + pib + "%");
		stmt.setString(3, "%" + naziv + "%");
		stmt.setString(4, "%" + ptt + "%");
		stmt.setString(5, "%" + grad + "%");
		stmt.setString(6, "%" + adresa + "%");
		stmt.setString(7, "%" + telefon + "%");

		ResultSet rowsAffected = stmt.executeQuery();
		while (rowsAffected.next()) {
			sifra = rowsAffected.getString("sifra_klijenta");
			pib = rowsAffected.getString("pib");
			naziv = rowsAffected.getString("naziv");
			ptt = rowsAffected.getString("ptt_broj");
			grad = rowsAffected.getString("naziv");
			adresa = rowsAffected.getString("adresa");
			telefon = rowsAffected.getString("telefon");
			addRow(new String[] { sifra, pib, naziv, ptt, grad, adresa,
					telefon });
		}
		stmt.close();
	}

	@Override
	public int updateRow(int index, Object[] data, String staraSifra)
			throws SQLException {
		checkRow(index);

		String sifra = (String)data[0];
		String pib = (String)data[1];
		String naziv = (String)data[2];
		String ptt = (String)data[3];
		String grad = (String)data[4];
		String adresa = (String)data[5];
		String telefon = (String)data[6];
		
		int retVal = 0;
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"UPDATE klijent SET sifra_klijenta = ?, ptt_broj = ?, adresa = ?, telefon = ? WHERE sifra_klijenta = ?");
		stmt.setString(1, sifra);
		stmt.setString(2, ptt);
		stmt.setString(3, adresa);
		stmt.setString(4, telefon);
		stmt.setString(5, staraSifra);

		int rowsAffected = stmt.executeUpdate();
		
		retVal = 0;
		stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"UPDATE pravno_lice SET sifra_klijenta = ?, pib = ?, naziv_organizacije = ?, WHERE sifra_klijenta = ?");
		stmt.setString(1, sifra);
		stmt.setString(2, pib);
		stmt.setString(3, naziv);
		stmt.setString(4, staraSifra);

		rowsAffected = stmt.executeUpdate();
		
		stmt.close();
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// TableModel update
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] { "", "", "", "", "", "", "" });
	}

	@Override
	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"DELETE FROM pravno_lice WHERE sifra_klijenta = ?");
		String sifra = (String) getValueAt(index, 0);
		stmt.setString(1, sifra);
		// Brisanje iz baze
		int rowsAffected = stmt.executeUpdate();
		
		stmt = DBConnection.getConnection().prepareStatement(
				"DELETE FROM klijent WHERE sifra_klijenta = ?");
		sifra = (String) getValueAt(index, 0);
		stmt.setString(1, sifra);
		// Brisanje iz baze
		rowsAffected = stmt.executeUpdate();
		stmt.close();
		
		
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i brisanje iz TableModel-a
			removeRow(index);
			fireTableDataChanged();
		}
	}

	@Override
	protected void checkRow(int index) throws SQLException {

		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection()
				.prepareStatement(
						basicQuery + " WHERE klijent.sifra_klijenta = ?");

		String sifra = (String) getValueAt(index, 0);
		selectStmt.setString(1, sifra);

		ResultSet rset = selectStmt.executeQuery();

		String sifraKlijenta = "", pib = "", naziv = "", ptt = "", grad = "", adresa = "", telefon = "";
		Boolean postoji = false;
		String errorMsg = "";
		while (rset.next()) {
			sifraKlijenta = rset.getString("sifra_klijenta");
			pib = rset.getString("pib");
			naziv = rset.getString("naziv_organizacije");
			ptt = rset.getString("ptt_broj");
			grad = rset.getString("naziv");
			adresa = rset.getString("adresa");
			telefon = rset.getString("telefon");
			postoji = true;
		}
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(sifraKlijenta,
				((String) getValueAt(index, 0)).trim()) != 0)
				|| (SortUtils.getLatCyrCollator().compare(pib,
						(String) getValueAt(index, 1)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(naziv,
						(String) getValueAt(index, 2)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(ptt,
						(String) getValueAt(index, 3)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(grad,
						(String) getValueAt(index, 4)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(adresa,
						(String) getValueAt(index, 5)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(telefon,
						(String) getValueAt(index, 6)) != 0)) {
			setValueAt(sifraKlijenta, index, 0);
			setValueAt(pib, index, 1);
			setValueAt(naziv, index, 2);
			setValueAt(ptt, index, 3);
			setValueAt(grad, index, 4);
			setValueAt(adresa, index, 5);
			setValueAt(telefon, index, 6);
			fireTableDataChanged();
		}
		rset.close();
		selectStmt.close();
		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_READ_COMMITTED);
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
	}

}
