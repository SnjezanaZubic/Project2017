package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import db.DBConnection;

import util.Column;
import util.SortUtils;

public class KursUValutiTableModel extends GenericTableModel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String basicQuery = "SELECT KLS_RBR, KLS_KUPOVNI, kls_srednji, kls_prodajni, KURS_U_VALUTI.KL_DATUM, VALUTE.VA_SIFRA FROM ((VALUTE JOIN KURS_U_VALUTI on VALUTE.VA_SIFRA = KURS_U_VALUTI.VA_SIFRA) JOIN KURSNA_LISTA on KURS_U_VALUTI.KL_DATUM = KURSNA_LISTA.KL_DATUM)";
	private String orderBy = "ORDER BY kls_rbr";
	private String whereStmt = "";

	public KursUValutiTableModel(Object[] colNames, int rowCount) {
		super(colNames, rowCount);
	}
	
	@Override
	public int insertRow(Object[] data) throws SQLException {
		int retVal = 0;
		String redniBr = (String)data[0];
		String kupovni = (String)data[1];
		String srednji = (String)data[2];
		String prodajni = (String) data[3];
		String datum = (String) data[4];
		String sifra = (String) data[5];
		System.out.println("akcija1");
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"INSERT INTO KURS_U_VALUTI (kls_rbr, kls_kupovni, kls_srednji, kls_prodajni, KURSNA_LISTA.KL_DATUM, KURSNA_LISTA.va_sifra) VALUES (?, ?, ?, ?, ?, ?)");
		stmt.setString(1, redniBr);
		stmt.setString(2, kupovni);
		stmt.setString(3, srednji);
		stmt.setString(4, prodajni);
		stmt.setString(5, datum);
		stmt.setString(6, sifra);
		System.out.println("akcija2");
		int rowsAffected = stmt.executeUpdate();
		System.out.println("akcija3");
		stmt.close();
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i unos u TableModel
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void findData(Object[] data) throws SQLException {
		setRowCount(0);
		String redniBr = (String)data[0];
		String kupovni = (String)data[1];
		String srednji = (String)data[2];
		String prodajni = (String)data[3];
		String datum = (String) data[4];
		String sifra = (String) data[5];
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement("SELECT * FROM ((KURS_U_VALUTI JOIN VALUTE on KURS_U_VALUTI.VA_SIFRA = VALUTE.VA_SIFRA) JOIN KURSNA_LISTA on KURS_U_VALUTI.KL_DATUM = KURSNA_LISTA.KL_DATUM) WHERE kls_rbr LIKE ? AND kls_kupovni LIKE ? AND kls_srednji LIKE ? AND kls_prodajni LIKE ? AND kurs_u_valuti.KL_DATUM LIKE ? AND kurs_u_valuti.va_sifra LIKE ? ORDER BY kls_rbr");

		stmt.setString(1, "%" + redniBr + "%");
		stmt.setString(2, "%" + kupovni + "%");
		stmt.setString(3, "%" + srednji + "%");
		stmt.setString(4, "%" + prodajni + "%");
		stmt.setString(5, "%" + datum + "%");
		stmt.setString(6, "%" + sifra + "%");
		ResultSet rowsAffected = stmt.executeQuery();
		while (rowsAffected.next()) {
			redniBr = rowsAffected.getString("kls_rbr");
			kupovni = rowsAffected.getString("kls_kupovni");
			srednji = rowsAffected.getString("kls_srednji");
			prodajni = rowsAffected.getString("kls_prodajni");
			datum = rowsAffected.getString("KL_DATUM");
			sifra = rowsAffected.getString("va_sifra");
			addRow(new String[] { redniBr, kupovni, srednji, prodajni, datum, sifra});
		}
		stmt.close();
	}

	@Override
	public int updateRow(int index, Object[] data, String staraSifra)
			throws SQLException {
		checkRow(index); // Provera i zakljucavanje tekuceg sloga pre izmene
		String redniBr = (String)data[0];
		String kupovni = (String)data[1];
		String srednji = (String)data[2];
		String prodajni = (String) data[3];
		String datum = (String) data[4];
		String sifra = (String) data[5];
		int retVal = 0;
		PreparedStatement stmt = DBConnection
				.getConnection()
				.prepareStatement(
						"UPDATE KURS_U_VALUTI SET kls_rbr = ?, kls_kupovni = ?, kls_srednji = ?, kls_prodajni = ?, KL_DATUM = ?, va_sifra = ? WHERE kls_rbr = ?");
		stmt.setString(1, redniBr);
		stmt.setString(2, kupovni);
		stmt.setString(3, srednji);
		stmt.setString(4, prodajni);
		stmt.setString(5, datum);
		stmt.setString(6, sifra);

		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		// Unos sloga u bazu
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// TableModel update
			removeRow(index);
			retVal = sortedInsert(data);
			fireTableDataChanged();
		}
		return retVal;
	}

	@Override
	public void refresh() throws SQLException {
		findData(new String[] { "", "", "", "", "", ""});
	}

	@Override
	public void deleteRow(int index) throws SQLException {
		checkRow(index);
		PreparedStatement stmt = DBConnection.getConnection().prepareStatement(
				"DELETE FROM KURS_U_VALUTI WHERE kls_rbr = ?");
		String redniBr = (String) getValueAt(index, 0);
		stmt.setString(1, redniBr);
		// Brisanje iz baze
		int rowsAffected = stmt.executeUpdate();
		stmt.close();
		DBConnection.getConnection().commit();
		if (rowsAffected > 0) {
			// i brisanje iz TableModel-a
			removeRow(index);
			fireTableDataChanged();
		}
	}

	@Override
	public void open(Column[] sifraColumns) throws SQLException {
		if (sifraColumns == null)
			fillData("SELECT kls_rbr, kls_kupovni, kls_srednji, kls_prodajni, kurs_u_valuti.KL_DATUM, kurs_u_valuti.va_sifra FROM ((KURS_U_VALUTI JOIN VALUTE on KURS_U_VALUTI.VA_SIFRA = VALUTE.VA_SIFRA) JOIN KURSNA_LISTA on KURS_U_VALUTI.KL_DATUM = KURSNA_LISTA.KL_DATUM) ORDER BY kls_rbr");
		else {
			fillData("SELECT kls_rbr, kls_kupovni, kls_srednji, kls_prodajni, kurs_u_valuti.KL_DATUM, kurs_u_valuti.va_sifra FROM ((KURS_U_VALUTI JOIN VALUTE on KURS_U_VALUTI.VA_SIFRA = VALUTE.VA_SIFRA) JOIN KURSNA_LISTA on KURS_U_VALUTI.KL_DATUM = KURSNA_LISTA.KL_DATUM) WHERE kurs_u_valuti." + sifraColumns[0].getName() + " = '" + sifraColumns[0].getValue() + "' "  + orderBy);
		}
	}

	private void fillData(String sql) throws SQLException {
		setRowCount(0);
		Statement stmt = DBConnection.getConnection().createStatement();
		ResultSet rset = stmt.executeQuery(sql);
		while (rset.next()) {
			addRow(new String[]{
					rset.getString("KLS_RBR"),
					rset.getString("KLS_KUPOVNI"),
					rset.getString("KLS_SREDNJI"),
					rset.getString("KLS_PRODAJNI"),
					rset.getString("KL_DATUM"),
					rset.getString("VA_SIFRA")
			});
		}
		rset.close();
		stmt.close();
		fireTableDataChanged();
		
	}

	@Override
	protected void checkRow(int index) throws SQLException {
		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_REPEATABLE_READ);
		PreparedStatement selectStmt = DBConnection.getConnection()
				.prepareStatement("SELECT kls_rbr, kls_kupovni, kls_srednji, kls_prodajni, kurs_u_valuti.KL_DATUM, kurs_u_valuti.va_sifra FROM ((KURS_U_VALUTI JOIN VALUTE on KURS_U_VALUTI.VA_SIFRA = VALUTE.VA_SIFRA) JOIN KURSNA_LISTA on KURS_U_VALUTI.KL_DATUM = KURSNA_LISTA.KL_DATUM) where KLS_RBR = ?");

		String redniBr = (String) getValueAt(index, 0);
		selectStmt.setString(1, redniBr);

		ResultSet rset = selectStmt.executeQuery();

		String redniBroj = "", kupovni = "", srednji = "", prodajni = "", datum = "", sifra = "";
		Boolean postoji = false;
		String errorMsg = "";
		while (rset.next()) {
			redniBroj = rset.getString("KLS_RBR").trim();
			kupovni = rset.getString("KLS_KUPOVNI").trim();
			srednji = rset.getString("KLS_SREDNJI").trim();
			prodajni = rset.getString("KLS_PRODAJNI").trim();
			datum = rset.getString("KL_DATUM");
			sifra = rset.getString("VA_SIFRA").trim();
			postoji = true;
		}
		if (!postoji) {
			removeRow(index);
			fireTableDataChanged();
		} else if ((SortUtils.getLatCyrCollator().compare(redniBroj,
				((String) getValueAt(index, 0)).trim()) != 0)
				|| (SortUtils.getLatCyrCollator().compare(kupovni,
						(String) getValueAt(index, 1)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(srednji,
						(String) getValueAt(index, 2)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(prodajni, 
						(String)getValueAt(index, 3)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(datum, 
						(String)getValueAt(index, 4)) != 0)
				|| (SortUtils.getLatCyrCollator().compare(sifra, 
						(String)getValueAt(index, 5)) != 0)) {
			setValueAt(redniBroj, index, 0);
			setValueAt(kupovni, index, 1);
			setValueAt(srednji, index, 2);
			setValueAt(prodajni, index, 3);
			setValueAt(datum, index, 4);
			setValueAt(sifra, index, 5);
			fireTableDataChanged();
		}
		rset.close();
		selectStmt.close();
		DBConnection.getConnection().setTransactionIsolation(
				Connection.TRANSACTION_READ_COMMITTED);
		if (errorMsg != "") {
			DBConnection.getConnection().commit();
			throw new SQLException(errorMsg, "");
		}
	}
	
	public double convertValuteToDouble (String kupovni, String srednji, String prodajni, int index) {
		//kupovni = "";
		//srednji = "";
		//prodajni = "";
		try {
		//	DBConnection.getConnection().setTransactionIsolation(
		//			Connection.TRANSACTION_REPEATABLE_READ);
		
		String redniBr = (String)getValueAt(index, 0);
	
		PreparedStatement stm = null;
		
			stm = DBConnection.getConnection().prepareStatement("SELECT KLS_KUPOVNI, KLS_SREDNJI, KLS_PRODAJNI FROM KURS_U_VALUTI");
			stm.setString(1, redniBr);
			ResultSet result = stm.executeQuery();
			
			kupovni = result.getString("KLS_KUPOVNI").trim();
			String kupovniString = kupovni;
			
			if(kupovniString.equals(kupovni)){
				
			double kupovniDouble = Double.parseDouble(kupovniString);
			
			return kupovniDouble;
			
			}
			
			srednji = result.getString("KLS_SREDNJI").trim();
			String srednjiString = srednji;
			
			if(srednjiString.equals(srednji)) {
				
			double srednjiDouble = Double.parseDouble(srednjiString);
			
			return srednjiDouble;
			}
			
			prodajni = result.getString("KLS_PRODAJNI");
			String prodajniString = prodajni;
			
			if(prodajniString.equals(prodajni)){
				
			double prodajniDouble = Double.parseDouble(prodajniString);
			
			return prodajniDouble;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
		}
	
}
